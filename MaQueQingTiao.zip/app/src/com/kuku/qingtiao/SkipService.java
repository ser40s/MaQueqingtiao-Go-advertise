package com.kuku.qingtiao;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.content.Context;
import android.graphics.Path;
import android.graphics.Rect;
import android.os.Build;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.os.Handler;
import android.os.Looper;
import android.util.DisplayMetrics;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.accessibility.AccessibilityWindowInfo;

import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

public class SkipService extends AccessibilityService {

    private static String sCurrentPkg = "";
    private static String sMode = "";

    public static void setRecordingMode(boolean on) {
        sMode = on ? "录制模式" : "";
        SkipService svc = get();
        if (svc != null) svc.setNotifyText(null);
    }

    public static String currentPkg() {
        return sCurrentPkg;
    }

    /** 从无障碍窗口列表取当前前台应用包名，跳过自身悬浮窗 */
    public String activeAppPkg() {
        try {
            java.util.List<android.view.accessibility.AccessibilityWindowInfo> ws = getWindows();
            if (ws != null) {
                for (int i = 0; i < ws.size(); i++) {
                    android.view.accessibility.AccessibilityWindowInfo w = ws.get(i);
                    if (w == null) continue;
                    if (w.getType() != android.view.accessibility.AccessibilityWindowInfo.TYPE_APPLICATION) continue;
                    AccessibilityNodeInfo r = null;
                    try {
                        r = w.getRoot();
                    } catch (Exception ignored) {
                    }
                    if (r == null) continue;
                    CharSequence p = null;
                    try {
                        p = r.getPackageName();
                    } catch (Exception ignored) {
                    }
                    if (p == null || p.length() == 0) continue;
                    if (getPackageName().contentEquals(p)) continue;
                    return p.toString();
                }
            }
        } catch (Exception ignored) {
        }
        return sCurrentPkg;
    }

    private static WeakReference<SkipService> sRef;

    private final Map<String, Long> lastTrigger = new HashMap<String, Long>();
    private String foregroundPkg = "";
    private long foregroundSince = 0L;
    private long lastGenericClick = 0L;
    private long lastEventAt = 0L;
    private String lastClickSig = "";
    private long lastClickSigTime = 0L;
    private int sameSigHits = 0;
    private Set<String> customKw = new HashSet<String>();

    private static final String[] KW_SKIP = {"跳过", "跳過", "略過", "skip", "skipad"};
    private static final String[] KW_HEAD = {"点击", "快速", "立即", "关闭", "自动"};
    private static final String[] KW_CTA = {"下载", "安装", "查看", "详情", "领取", "免费",
            "打开", "进入", "跳转", "体验", "预约", "购买", "试玩", "咨询", "不感兴趣", "反馈"};
    private static final String[] AD_CONTAINERS = {"ad_container", "splash_container", "splash_root",
            "ad_root", "welcome_ad_view", "ksad_container", "advertising_container", "adcontainer",
            "splash_ad_view", "ad_view_layout", "splash_layout"};
    private static final String[] PAGE_BLOCK = {"搜索历史", "热门搜索", "相关搜索", "青少年模式",
            "历史记录", "跳过片头", "跳过片尾"};
    private final Map<String, Long> clickMarks = new HashMap<String, Long>();
    private final java.util.concurrent.ExecutorService worker =
            java.util.concurrent.Executors.newSingleThreadExecutor();
    private volatile boolean busy = false;
    private volatile long lastInteractAt = 0L;
    private final Handler ui = new Handler(Looper.getMainLooper());

    public static SkipService get() {
        return sRef == null ? null : sRef.get();
    }

    public static boolean isRunning() {
        return get() != null;
    }

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        sRef = new WeakReference<SkipService>(this);
        updateKeepNotify();
    }

    public void updateKeepNotify() {
        setNotifyText(null);
    }

    private String notifyText = "";

    private void setNotifyText(String text) {
        try {
            NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            if (nm == null) return;
            if (!RuleStore.get(this).keepNotify()) {
                nm.cancel(1001);
                return;
            }
            if (Build.VERSION.SDK_INT >= 26) {
                NotificationChannel ch = new NotificationChannel("qt_run", "运行状态",
                        NotificationManager.IMPORTANCE_LOW);
                ch.setShowBadge(false);
                nm.createNotificationChannel(ch);
            }
            Intent i = new Intent(this, MainActivity.class);
            i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
            int pf = PendingIntent.FLAG_UPDATE_CURRENT;
            if (Build.VERSION.SDK_INT >= 23) pf |= PendingIntent.FLAG_IMMUTABLE;
            PendingIntent pi = PendingIntent.getActivity(this, 0, i, pf);
            RuleStore s = RuleStore.get(this);
            String body;
            if (text != null) body = text;
            else if (sMode != null && sMode.length() > 0) body = sMode;
            else if (s.hitsTotal() >= 1000L) body = "正在拾掉广告";
            else body = "正在运行";
            notifyText = body;
            Notification.Builder b = Build.VERSION.SDK_INT >= 26
                    ? new Notification.Builder(this, "qt_run")
                    : new Notification.Builder(this);
            b.setSmallIcon(android.R.drawable.ic_menu_view)
                    .setContentTitle("麻雀轻跳")
                    .setContentText(body)
                    .setOngoing(true)
                    .setContentIntent(pi);
            nm.notify(1001, b.build());
        } catch (Exception ignored) {
        }
    }

    @Override
    public boolean onUnbind(android.content.Intent intent) {
        sRef = null;
        return super.onUnbind(intent);
    }

    @Override
    public void onDestroy() {
        sRef = null;
        super.onDestroy();
    }

    @Override
    public void onInterrupt() {
    }

    public AccessibilityNodeInfo root() {
        try {
            return getRootInActiveWindow();
        } catch (Exception e) {
            return null;
        }
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event == null) return;
        CharSequence cs = event.getPackageName();
        if (cs == null) return;
        final String pkg = cs.toString();
        if (pkg.length() == 0 || pkg.equals(getPackageName())) return;
        sCurrentPkg = pkg;

        final long now = System.currentTimeMillis();
        int et = event.getEventType();
        if (et == AccessibilityEvent.TYPE_VIEW_SCROLLED
                || et == AccessibilityEvent.TYPE_TOUCH_INTERACTION_START
                || et == AccessibilityEvent.TYPE_TOUCH_INTERACTION_END) {
            lastInteractAt = now;
        }

        if (event.getEventType() == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
            if (!pkg.equals(foregroundPkg)) {
                foregroundPkg = pkg;
                foregroundSince = now;
                // 回到应用时清掉通用引擎的冷却，保证开屏广告能被跳过
                lastClickSig = "";
                sameSigHits = 0;
                lastGenericClick = 0L;
            }
        }

        RuleStore store = RuleStore.get(this);
        if (!store.isEngineOn()) return;
        if (store.isWhitelisted(pkg)) return;
        customKw = store.customKeywords();

        if (now - lastEventAt < 70L) return;
        lastEventAt = now;
        if (busy) return;
        busy = true;
        worker.execute(new Runnable() {
            public void run() {
                try {
                    handleEvent(pkg, now);
                } catch (Throwable ignored) {
                } finally {
                    busy = false;
                }
            }
        });
    }

    /** 节点遍历与点击放在后台线程，避免阻塞悬浮窗拖动 */
    private void handleEvent(String pkg, long now) {
        RuleStore store = RuleStore.get(this);
        AccessibilityNodeInfo root = root();
        if (root == null) return;
        // 事件来自后台应用时，活动窗口的根节点不是该应用，直接跳过
        CharSequence rootPkg = null;
        try {
            rootPkg = root.getPackageName();
        } catch (Exception ignored) {
        }
        if (rootPkg == null || !pkg.contentEquals(rootPkg)) return;

        // 页面正在滑动或用户正在触摸，先不点，避免点在滚动过程中
        if (now - lastInteractAt < 350L) return;

        boolean inFirstWindow = foregroundSince > 0L && (now - foregroundSince) <= 6000L;

        // 严格模式：只在首屏窗口内校验页面控件总数
        if (inFirstWindow && store.isStrict(pkg)) {
            int[] sp = store.strictParams(pkg);
            if (sp[0] > 0) {
                int total = countNodes(root, 0);
                if (Math.abs(total - sp[0]) > sp[1]) return;
            }
        }

        List<Rule> rules = store.forPackage(pkg);

        boolean hasFirstScreenRule = false;
        boolean hasInAppRule = false;
        for (int i = 0; i < rules.size(); i++) {
            Rule r = rules.get(i);
            if (!r.enabled || r.conditions.size() < 1) continue;
            if (r.mode == Rule.MODE_POINT && (r.x < 0 || r.y < 0)) continue;
            if (r.type == Rule.TYPE_FIRST_SCREEN) hasFirstScreenRule = true;
            else hasInAppRule = true;
        }
        // 1) 脚本规则优先执行
        for (int i = 0; i < rules.size(); i++) {
            Rule r = rules.get(i);
            if (!r.enabled) continue;
            if (r.conditions.size() < 1) continue;
            if (r.mode == Rule.MODE_POINT && (r.x < 0 || r.y < 0)) continue;
            if (r.mode == Rule.MODE_WIDGET && r.targetIds.isEmpty()) continue;
            if (r.mode == Rule.MODE_ANCHOR && r.anchorW <= 0) continue;
            if (r.type == Rule.TYPE_FIRST_SCREEN && !inFirstWindow) continue;
            Long last = lastTrigger.get(r.id);
            if (last != null && now - last.longValue() < Math.max(600L, r.cooldownMs)) continue;
            if (!allPresentAnyWindow(r)) continue;
            boolean ok = execRule(root, r);
            if (!ok && r.mode != Rule.MODE_POINT) ok = execRuleAnyWindow(r);
            if (ok) {
                scheduleFollow(r);
                lastTrigger.put(r.id, Long.valueOf(now));
                verifyAndCount(r);
                return;
            }
        }

        // 2) 通用引擎：只在该场景没有脚本规则接管时运行
        //    首屏窗口内看有没有首屏规则；首屏之后看有没有应用内规则
        // 首屏：脚本规则先执行，没命中时通用引擎兜底（首页广告形态多）
        // 应用内：有脚本规则时通用引擎不接管，避免误点
        boolean genericAllowed = inFirstWindow ? true : !hasInAppRule;
        if (!genericAllowed) return;
        if (now - lastGenericClick < 800L) return;
        if (hasSearchHistory(root, 0, 0)) return;
        long gdelay = store.genDelay(pkg);
        if (gdelay <= 0L) gdelay = store.genDelayGlobal();
        if (gdelay > 0L && foregroundSince > 0L && now - foregroundSince < gdelay) return;
        // 首屏严格模式：文本过多说明是正常内容页，不执行关键词点击
        if (inFirstWindow && store.genericStrict()) {
            int texts = countTextNodes(root, 0);
            if (texts > store.genericStrictMax()) return;
        }
        AccessibilityNodeInfo focus = null;
        try {
            focus = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT);
        } catch (Exception ignored) {
        }
        if (focus != null) {
            boolean editable = false;
            try {
                editable = focus.isEditable();
            } catch (Exception ignored) {
            }
            if (editable) return;
        }
        AccessibilityNodeInfo hit = findSkipNode(root, 0, 0);
        if (hit == null) hit = findEmptyAdButton(root, 0, 0);
        if (hit == null) return;
        Rect b = new Rect();
        hit.getBoundsInScreen(b);

        // 同一目标防重复点击：3 秒内不重复，反复出现 3 次后进入 30 秒冷却
        String hitText = "";
        CharSequence hc = hit.getText();
        if (hc == null) hc = hit.getContentDescription();
        if (hc != null) hitText = hc.toString();
        String sig = pkg + "|" + hitText;
        String rectSig = "R|" + pkg + "|" + b.left + "," + b.top + "," + b.right + "," + b.bottom;
        Long rectMark = clickMarks.get(rectSig);
        if (rectMark != null && now - rectMark.longValue() < 3000L) return;
        Long gmark = clickMarks.get("G|" + sig);
        if (gmark != null && now - gmark.longValue() < 600000L) return;
        long sigGap = now - lastClickSigTime;
        if (sig.equals(lastClickSig)) {
            if (sigGap < 3000L) return;
            sameSigHits++;
            if (sameSigHits >= 3 && sigGap < 30000L) return;
        } else {
            lastClickSig = sig;
            sameSigHits = 0;
        }

        boolean ok = false;
        try {
            ok = hit.performAction(AccessibilityNodeInfo.ACTION_CLICK);
        } catch (Exception ignored) {
        }
        if (!ok && b.width() > 0 && b.height() > 0) {
            ok = tap(b.centerX(), b.centerY());
        }
        if (ok) {
            clickMarks.put("G|" + sig, Long.valueOf(now));
            clickMarks.put(rectSig, Long.valueOf(now));
            lastGenericClick = now;
            lastClickSigTime = now;
            store.addHit();
        }
    }

    private void verifyAndCount(final Rule r) {
        ui.postDelayed(new Runnable() {
            public void run() {
                try {
                    if (!allPresentAnyWindow(r)) {
                        RuleStore.get(SkipService.this).bumpHits(r.id);
                        RuleStore.get(SkipService.this).addHit();
                    } else {
                        // 条件仍在，说明没点中：在坐标附近补一次
                        if (clickNearPoint(r)) {
                            ui.postDelayed(new Runnable() {
                                public void run() {
                                    try {
                                        if (!allPresentAnyWindow(r)) {
                                            RuleStore.get(SkipService.this).bumpHits(r.id);
                                            RuleStore.get(SkipService.this).addHit();
                                        }
                                    } catch (Exception ignored) {
                                    }
                                }
                            }, 500L);
                        }
                    }
                } catch (Exception ignored) {
                }
            }
        }, 500L);
    }

    private boolean clickNearPoint(Rule r) {
        int radius = (int) (150 * getResources().getDisplayMetrics().density);
        List<AccessibilityNodeInfo> nodes = new ArrayList<AccessibilityNodeInfo>();
        AccessibilityNodeInfo active = root();
        collectClickable(active, 0, nodes);
        try {
            List<AccessibilityWindowInfo> wins = getWindows();
            if (wins != null) {
                for (int i = 0; i < wins.size(); i++) {
                    AccessibilityNodeInfo wr = null;
                    try {
                        wr = wins.get(i).getRoot();
                    } catch (Exception ignored) {
                    }
                    collectClickable(wr, 0, nodes);
                }
            }
        } catch (Exception ignored) {
        }

        AccessibilityNodeInfo best = null;
        long bestScore = Long.MAX_VALUE;
        Rect bestRect = new Rect();
        for (int i = 0; i < nodes.size(); i++) {
            AccessibilityNodeInfo n = nodes.get(i);
            Rect b = new Rect();
            try {
                n.getBoundsInScreen(b);
            } catch (Exception ignored) {
            }
            if (b.width() <= 0 || b.height() <= 0) continue;
            long dx = b.centerX() - r.x;
            long dy = b.centerY() - r.y;
            long d = dx * dx + dy * dy;
            boolean contains = b.contains(r.x, r.y);
            // 坐标落在控件内优先；否则取半径内最近的
            long score = contains ? d / 4 : d;
            if (d > (long) radius * radius && !contains) continue;
            if (score < bestScore) {
                bestScore = score;
                best = n;
                bestRect = b;
            }
        }
        if (best == null) return false;
        return tap(bestRect.centerX(), bestRect.centerY());
    }

    private void collectClickable(AccessibilityNodeInfo node, int depth, List<AccessibilityNodeInfo> out) {
        if (node == null || depth > 20 || out.size() >= 40) return;
        try {
            if (node.isVisibleToUser() && node.isClickable()) out.add(node);
        } catch (Exception ignored) {
        }
        int n = 0;
        try {
            n = Math.min(node.getChildCount(), 40);
        } catch (Exception ignored) {
        }
        for (int i = 0; i < n; i++) {
            AccessibilityNodeInfo c = null;
            try {
                c = node.getChild(i);
            } catch (Exception ignored) {
            }
            collectClickable(c, depth + 1, out);
        }
    }

    private boolean allPresentAnyWindow(Rule r) {
        AccessibilityNodeInfo active = root();
        if (active != null && allPresent(active, r)) return true;
        try {
            List<AccessibilityWindowInfo> wins = getWindows();
            if (wins != null) {
                for (int i = 0; i < wins.size(); i++) {
                    AccessibilityWindowInfo w = wins.get(i);
                    if (w == null) continue;
                    AccessibilityNodeInfo wr = null;
                    try {
                        wr = w.getRoot();
                    } catch (Exception ignored) {
                    }
                    if (wr == null) continue;
                    if (allPresent(wr, r)) return true;
                }
            }
        } catch (Exception ignored) {
        }
        return false;
    }

    private boolean allPresent(AccessibilityNodeInfo root, Rule r) {
        for (int i = 0; i < r.conditions.size(); i++) {
            String cond = r.conditions.get(i);
            if (cond == null || cond.length() == 0) return false;
            if (cond.startsWith("text:")) {
                String t = cond.substring(5);
                List<AccessibilityNodeInfo> list = null;
                try {
                    list = root.findAccessibilityNodeInfosByText(t);
                } catch (Exception ignored) {
                }
                if (list == null || list.isEmpty()) return false;
            } else if (cond.startsWith("desc:")) {
                if (findByDesc(root, cond.substring(5), 0) == null) return false;
            } else {
                List<AccessibilityNodeInfo> list = null;
                try {
                    list = root.findAccessibilityNodeInfosByViewId(cond);
                } catch (Exception ignored) {
                }
                if (list == null || list.isEmpty()) return false;
            }
        }
        return true;
    }

    private int countTextNodes(AccessibilityNodeInfo node, int depth) {
        if (node == null || depth > 20) return 0;
        int n = 0;
        try {
            CharSequence t = node.getText();
            if (t != null && t.length() > 0) n++;
        } catch (Exception ignored) {
        }
        int c = 0;
        try {
            c = Math.min(node.getChildCount(), 60);
        } catch (Exception ignored) {
        }
        for (int i = 0; i < c; i++) {
            AccessibilityNodeInfo ch = null;
            try {
                ch = node.getChild(i);
            } catch (Exception ignored) {
            }
            if (ch != null) n += countTextNodes(ch, depth + 1);
        }
        return n;
    }

    private int countNodes(AccessibilityNodeInfo node, int depth) {
        if (node == null || depth > 30) return 0;
        int n = 1;
        int c = 0;
        try {
            c = Math.min(node.getChildCount(), 60);
        } catch (Exception ignored) {
        }
        for (int i = 0; i < c; i++) {
            AccessibilityNodeInfo ch = null;
            try {
                ch = node.getChild(i);
            } catch (Exception ignored) {
            }
            if (ch != null) n += countNodes(ch, depth + 1);
        }
        return n;
    }

    private AccessibilityNodeInfo findByDesc(AccessibilityNodeInfo node, String desc, int depth) {
        if (node == null || depth > 18) return null;
        CharSequence cd = node.getContentDescription();
        if (cd != null && desc.equals(cd.toString())) return node;
        int n = Math.min(node.getChildCount(), 40);
        for (int i = 0; i < n; i++) {
            AccessibilityNodeInfo c = null;
            try {
                c = node.getChild(i);
            } catch (Exception ignored) {
            }
            AccessibilityNodeInfo hit = findByDesc(c, desc, depth + 1);
            if (hit != null) return hit;
        }
        return null;
    }

    private AccessibilityNodeInfo findSkipNode(AccessibilityNodeInfo node, int depth, int budget) {
        if (node == null || depth > 16 || budget > 600) return null;
        String txt = null;
        String desc = null;
        try {
            CharSequence t = node.getText();
            if (t != null) txt = t.toString();
            CharSequence d = node.getContentDescription();
            if (d != null) desc = d.toString();
        } catch (Exception ignored) {
        }
        if (isSkipText(txt) || isSkipText(desc)) {
            if (isOnScreen(node) && !isSearchOrEditable(node) && !isInListContainer(node)) {
                AccessibilityNodeInfo clickable = climbClickable(node, 3);
                if (clickable != null) return clickable;
            }
        }
        int n = Math.min(node.getChildCount(), 40);
        for (int i = 0; i < n; i++) {
            AccessibilityNodeInfo c = null;
            try {
                c = node.getChild(i);
            } catch (Exception ignored) {
            }
            if (c == null) continue;
            AccessibilityNodeInfo hit = findSkipNode(c, depth + 1, budget + 1);
            if (hit != null) return hit;
        }
        return null;
    }

    private AccessibilityNodeInfo climbClickable(AccessibilityNodeInfo node, int up) {
        AccessibilityNodeInfo cur = node;
        for (int i = 0; i < up && cur != null; i++) {
            if (cur.isClickable()) return cur;
            try {
                cur = cur.getParent();
            } catch (Exception e) {
                return null;
            }
        }
        return null;
    }

    private boolean hasSearchHistory(AccessibilityNodeInfo n, int depth, int count) {
        if (n == null || depth > 10 || count > 300) return false;
        try {
            CharSequence t = n.getText();
            if (t != null) {
                String s = t.toString();
                for (int i = 0; i < PAGE_BLOCK.length; i++) {
                    if (s.contains(PAGE_BLOCK[i])) return true;
                }
            }
        } catch (Exception ignored) {
        }
        int c = 0;
        try {
            c = Math.min(n.getChildCount(), 40);
        } catch (Exception ignored) {
        }
        for (int i = 0; i < c; i++) {
            AccessibilityNodeInfo ch = null;
            try {
                ch = n.getChild(i);
            } catch (Exception ignored) {
            }
            if (hasSearchHistory(ch, depth + 1, count + 1)) return true;
        }
        return false;
    }

    private boolean isInputMethodNode(AccessibilityNodeInfo n) {
        AccessibilityNodeInfo cur = n;
        for (int i = 0; i < 4 && cur != null; i++) {
            try {
                CharSequence cn = cur.getClassName();
                if (cn != null) {
                    String c = cn.toString().toLowerCase(Locale.ROOT);
                    if (c.contains("keyboard") || c.contains("inputmethod")
                            || c.contains("candidate") || c.contains("ime")) return true;
                }
            } catch (Exception ignored) {
            }
            try {
                CharSequence pk = cur.getPackageName();
                if (pk != null) {
                    String p = pk.toString().toLowerCase(Locale.ROOT);
                    if (p.contains("inputmethod") || p.contains("keyboard")
                            || p.contains("ime.") || p.endsWith(".ime")) return true;
                }
            } catch (Exception ignored) {
            }
            try {
                cur = cur.getParent();
            } catch (Exception ignored) {
                cur = null;
            }
        }
        return false;
    }

    private boolean isInListContainer(AccessibilityNodeInfo n) {
        AccessibilityNodeInfo cur = n;
        for (int i = 0; i < 4 && cur != null; i++) {
            try {
                CharSequence cn = cur.getClassName();
                if (cn != null) {
                    String c = cn.toString().toLowerCase(Locale.ROOT);
                    if (c.contains("listview") || c.contains("recyclerview")
                            || c.contains("gridview") || c.contains("abslistview")) return true;
                }
            } catch (Exception ignored) {
            }
            try {
                cur = cur.getParent();
            } catch (Exception ignored) {
                cur = null;
            }
        }
        return false;
    }

    /** 自绘开屏：广告容器里找无文字、可点击、尺寸不大的按钮 */
    private AccessibilityNodeInfo findEmptyAdButton(AccessibilityNodeInfo node, int depth, int count) {
        if (node == null || depth > 20 || count > 600) return null;
        try {
            String vid = node.getViewIdResourceName();
            if (vid != null) {
                String v = vid.toLowerCase(Locale.ROOT);
                for (int i = 0; i < AD_CONTAINERS.length; i++) {
                    if (v.contains(AD_CONTAINERS[i])) {
                        AccessibilityNodeInfo b = firstEmptyClickable(node, 0);
                        if (b != null) return b;
                    }
                }
            }
        } catch (Exception ignored) {
        }
        int n = 0;
        try {
            n = Math.min(node.getChildCount(), 40);
        } catch (Exception ignored) {
        }
        for (int i = 0; i < n; i++) {
            AccessibilityNodeInfo ch = null;
            try {
                ch = node.getChild(i);
            } catch (Exception ignored) {
            }
            AccessibilityNodeInfo r = findEmptyAdButton(ch, depth + 1, count + 1);
            if (r != null) return r;
        }
        return null;
    }

    private AccessibilityNodeInfo firstEmptyClickable(AccessibilityNodeInfo node, int depth) {
        if (node == null || depth > 8) return null;
        try {
            if (node.isClickable() && node.isVisibleToUser()) {
                CharSequence t = node.getText();
                CharSequence d = node.getContentDescription();
                boolean empty = (t == null || t.length() == 0) && (d == null || d.length() == 0);
                if (empty) {
                    Rect b = new Rect();
                    node.getBoundsInScreen(b);
                    float dp = getResources().getDisplayMetrics().density;
                    int lim = (int) (220 * dp);
                    if (b.width() > 0 && b.height() > 0 && b.width() < lim && b.height() < lim
                            && b.right > 0 && b.bottom > 0) {
                        return node;
                    }
                }
            }
        } catch (Exception ignored) {
        }
        int n = 0;
        try {
            n = Math.min(node.getChildCount(), 20);
        } catch (Exception ignored) {
        }
        for (int i = 0; i < n; i++) {
            AccessibilityNodeInfo ch = null;
            try {
                ch = node.getChild(i);
            } catch (Exception ignored) {
            }
            AccessibilityNodeInfo r = firstEmptyClickable(ch, depth + 1);
            if (r != null) return r;
        }
        return null;
    }

    /** 节点必须真正可见且在屏幕内，避免点到隐藏页/折叠弹窗里的同名文本 */
    private boolean isOnScreen(AccessibilityNodeInfo n) {
        if (n == null) return false;
        try {
            if (!n.isVisibleToUser()) return false;
        } catch (Exception ignored) {
            return false;
        }
        try {
            Rect b = new Rect();
            n.getBoundsInScreen(b);
            if (b.width() <= 0 || b.height() <= 0) return false;
            DisplayMetrics dm = getResources().getDisplayMetrics();
            return b.right > 0 && b.bottom > 0 && b.left < dm.widthPixels && b.top < dm.heightPixels;
        } catch (Exception ignored) {
            return true;
        }
    }

    private boolean isSearchOrEditable(AccessibilityNodeInfo n) {
        AccessibilityNodeInfo cur = n;
        for (int i = 0; i < 4 && cur != null; i++) {
            try {
                if (cur.isEditable()) return true;
            } catch (Exception ignored) {
            }
            try {
                CharSequence cn = cur.getClassName();
                if (cn != null) {
                    String c = cn.toString().toLowerCase(Locale.ROOT);
                    if (c.contains("edittext") || c.contains("search")) return true;
                }
            } catch (Exception ignored) {
            }
            try {
                String vid = cur.getViewIdResourceName();
                if (vid != null && vid.toLowerCase(Locale.ROOT).contains("search")) return true;
            } catch (Exception ignored) {
            }
            try {
                cur = cur.getParent();
            } catch (Exception ignored) {
                cur = null;
            }
        }
        return false;
    }

    private boolean isSkipText(String raw) {
        if (raw == null) return false;
        String s = raw.trim().toLowerCase(Locale.ROOT)
                .replace(" ", "").replace("\u00a0", "").replace("\n", "");
        if (s.length() == 0 || s.length() > 10) return false;
        if (customKw != null && customKw.contains(s)) return true;
        if (s.equals("关闭广告") || s.equals("关闭开屏广告") || s.equals("关闭此广告")) return true;
        for (int i = 0; i < KW_SKIP.length; i++) {
            String k = KW_SKIP[i];
            if (s.equals(k)) return true;
            if (s.startsWith(k) && skipTailOk(s.substring(k.length()))) return true;
            if (s.endsWith(k) && skipHeadOk(s.substring(0, s.length() - k.length()))) return true;
        }
        return false;
    }

    private boolean skipTailOk(String r) {
        if (r.length() == 0) return true;
        if (r.equals("广告") || r.equals("廣告") || r.equals("进入") || r.equals("进入首页")) return true;
        return r.matches("[s秒后广告|>》】\\]()（）:：,，.。·\\d]*");
    }

    private boolean skipHeadOk(String r) {
        if (r.length() == 0) return true;
        for (int i = 0; i < KW_HEAD.length; i++) {
            if (r.equals(KW_HEAD[i])) return true;
        }
        return r.matches("[\\d s秒|>》：:]*");
    }

    /** 按规则模式执行点击 */
    private boolean execRule(AccessibilityNodeInfo root, Rule r) {
        if (root == null) return false;
        if (r.mode == Rule.MODE_WIDGET) return clickTargetIds(root, r);
        if (r.mode == Rule.MODE_ANCHOR) {
            String anchor = r.conditions.isEmpty() ? null : r.conditions.get(0);
            Rect ar = condRect(root, anchor);
            if (ar == null) return false;
            float sx = r.anchorW > 0 ? (float) ar.width() / (float) r.anchorW : 1f;
            float sy = r.anchorH > 0 ? (float) ar.height() / (float) r.anchorH : 1f;
            int ax = ar.left;
            int ay = ar.top;
            if (r.corner == 1) {
                ax = ar.right;
                ay = ar.top;
            } else if (r.corner == 2) {
                ax = ar.left;
                ay = ar.bottom;
            } else if (r.corner == 3) {
                ax = ar.right;
                ay = ar.bottom;
            }
            int cx = ax + Math.round(r.relX * sx);
            int cy = ay + Math.round(r.relY * sy);
            // 锚点异常漂移时宁可不点，避免误触
            DisplayMetrics dm = getResources().getDisplayMetrics();
            if (cx < 0 || cy < 0 || cx > dm.widthPixels || cy > dm.heightPixels) return false;
            if (r.x >= 0 && r.y >= 0
                    && (Math.abs(cx - r.x) > dm.widthPixels / 2 || Math.abs(cy - r.y) > dm.heightPixels / 2)) {
                return false;
            }
            return tap(cx, cy);
        }
        DisplayMetrics dm = getResources().getDisplayMetrics();
        if (r.x < 0 || r.y < 0 || r.x >= dm.widthPixels || r.y >= dm.heightPixels) return false;
        return tap(r.x, r.y);
    }

    private boolean execRuleAnyWindow(Rule r) {
        try {
            List<AccessibilityWindowInfo> ws = getWindows();
            for (int i = 0; i < ws.size(); i++) {
                AccessibilityWindowInfo w = ws.get(i);
                if (w == null) continue;
                AccessibilityNodeInfo wr = null;
                try {
                    wr = w.getRoot();
                } catch (Exception ignored) {
                }
                if (wr == null) continue;
                if (execRule(wr, r)) return true;
            }
        } catch (Exception ignored) {
        }
        return false;
    }

    /** 点控件模式：按 id 找控件，点中心 */
    private boolean clickTargetIds(AccessibilityNodeInfo root, Rule r) {
        for (int i = 0; i < r.targetIds.size(); i++) {
            String tid = r.targetIds.get(i);
            if (tid == null || tid.length() == 0) continue;
            List<AccessibilityNodeInfo> list = null;
            try {
                list = root.findAccessibilityNodeInfosByViewId(tid);
            } catch (Exception ignored) {
            }
            if (list == null || list.isEmpty()) continue;
            for (int k = 0; k < list.size(); k++) {
                AccessibilityNodeInfo t = list.get(k);
                if (t == null) continue;
                Rect b = new Rect();
                try {
                    t.getBoundsInScreen(b);
                } catch (Exception ignored) {
                    continue;
                }
                if (b.width() <= 0 || b.height() <= 0) continue;
                DisplayMetrics dm2 = getResources().getDisplayMetrics();
                if (b.centerX() < 0 || b.centerY() < 0
                        || b.centerX() >= dm2.widthPixels || b.centerY() >= dm2.heightPixels) continue;
                try {
                    if (!t.isVisibleToUser()) continue;
                } catch (Exception ignored) {
                }
                boolean ok = false;
                try {
                    ok = t.performAction(AccessibilityNodeInfo.ACTION_CLICK);
                } catch (Exception ignored) {
                }
                if (!ok) ok = tap(b.centerX(), b.centerY());
                if (ok) return true;
            }
        }
        return false;
    }

    /** 按条件找控件矩形 */
    private Rect condRect(AccessibilityNodeInfo root, String cond) {
        if (root == null || cond == null || cond.length() == 0) return null;
        List<AccessibilityNodeInfo> list = null;
        try {
            if (cond.startsWith("text:")) {
                list = root.findAccessibilityNodeInfosByText(cond.substring(5));
            } else if (cond.startsWith("desc:")) {
                AccessibilityNodeInfo n = findByDesc(root, cond.substring(5), 0);
                if (n == null) return null;
                Rect b = new Rect();
                n.getBoundsInScreen(b);
                return b.width() > 0 && b.height() > 0 ? b : null;
            } else {
                list = root.findAccessibilityNodeInfosByViewId(cond);
            }
        } catch (Exception ignored) {
        }
        if (list == null || list.isEmpty()) return null;
        for (int i = 0; i < list.size(); i++) {
            AccessibilityNodeInfo n = list.get(i);
            if (n == null) continue;
            Rect b = new Rect();
            try {
                n.getBoundsInScreen(b);
            } catch (Exception ignored) {
                continue;
            }
            if (b.width() > 0 && b.height() > 0) return b;
        }
        return null;
    }

    private void scheduleFollow(final Rule r) {
        if (!r.followOn || r.followPts == null || r.followPts.isEmpty()) return;
        long acc = 0;
        for (int i = 0; i < r.followPts.size(); i++) {
            final int[] p = r.followPts.get(i);
            acc += Math.max(120, p[2]);
            ui.postDelayed(new Runnable() {
                public void run() {
                    tap(p[0], p[1]);
                }
            }, acc);
        }
    }

    private boolean hasCta(String raw) {
        if (raw == null) return false;
        // 跳过文案优先，避免「立即跳过」被 CTA 黑名单误伤
        if (raw.contains("跳过") || raw.contains("跳過") || raw.toLowerCase(Locale.ROOT).contains("skip")) {
            return false;
        }
        for (int i = 0; i < KW_CTA.length; i++) {
            if (raw.contains(KW_CTA[i])) return true;
        }
        return false;
    }

    public boolean tap(int x, int y) {
        if (Build.VERSION.SDK_INT < 24) return false;
        try {
            Path p = new Path();
            p.moveTo(x, y);
            GestureDescription.StrokeDescription stroke =
                    new GestureDescription.StrokeDescription(p, 0, 100);
            GestureDescription g = new GestureDescription.Builder().addStroke(stroke).build();
            // 点击瞬间让悬浮窗不拦截触摸，避免悬浮球/准心挡住目标
            OverlayService.setTouchable(false);
            final boolean ok = dispatchGesture(g, null, null);
            ui.postDelayed(new Runnable() {
                public void run() {
                    OverlayService.setTouchable(true);
                }
            }, 280L);
            return ok;
        } catch (Exception e) {
            OverlayService.setTouchable(true);
            return false;
        }
    }

    public int[] screenSize() {
        DisplayMetrics dm = new DisplayMetrics();
        try {
            WindowManager wm = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
            if (Build.VERSION.SDK_INT >= 30) {
                getDisplay().getRealMetrics(dm);
            } else if (wm != null) {
                wm.getDefaultDisplay().getRealMetrics(dm);
            }
        } catch (Exception ignored) {
        }
        if (dm.widthPixels == 0) {
            dm = getResources().getDisplayMetrics();
        }
        return new int[]{dm.widthPixels, dm.heightPixels};
    }
}
