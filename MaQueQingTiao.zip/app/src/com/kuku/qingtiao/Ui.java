package com.kuku.qingtiao;

import android.app.Activity;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.RippleDrawable;
import android.os.Build;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.LinearLayout;
import android.widget.TextView;

public final class Ui {

    public static final int PRIMARY = 0xFF4C6FFF;
    public static final int OK = 0xFF17B26A;
    public static final int WARN = 0xFFF79009;
    public static final int DANGER = 0xFFF04438;

    public static int BG = 0xFFF4F5F9;
    public static int CARD = 0xFFFFFFFF;
    public static int INPUT_BG = 0xFFF5F6FA;
    public static int PRIMARY_SOFT = 0xFFF0F3FF;
    public static int TEXT = 0xFF141824;
    public static int SUB = 0xFF8B90A0;
    public static int LINE = 0xFFEDEFF4;
    public static int OK_SOFT = 0xFFE8F8F0;
    public static int WARN_SOFT = 0xFFFFF4E5;
    public static int DANGER_SOFT = 0xFFFEECEB;
    public static boolean DARK = false;

    private Ui() {}

    public static void applyTheme(Context c) {
        boolean dark = RuleStore.get(c).isDark();
        DARK = dark;
        if (dark) {
            BG = 0xFF0F1218;
            CARD = 0xFF1A1E26;
            INPUT_BG = 0xFF232833;
            PRIMARY_SOFT = 0xFF222A42;
            TEXT = 0xFFE9ECF3;
            SUB = 0xFF8F96A6;
            LINE = 0xFF272C36;
            OK_SOFT = 0xFF14302A;
            WARN_SOFT = 0xFF33260E;
            DANGER_SOFT = 0xFF3A1C1A;
        } else {
            BG = 0xFFF4F5F9;
            CARD = 0xFFFFFFFF;
            INPUT_BG = 0xFFF5F6FA;
            PRIMARY_SOFT = 0xFFF0F3FF;
            TEXT = 0xFF141824;
            SUB = 0xFF8B90A0;
            LINE = 0xFFEDEFF4;
            OK_SOFT = 0xFFE8F8F0;
            WARN_SOFT = 0xFFFFF4E5;
            DANGER_SOFT = 0xFFFEECEB;
        }
    }

    public static void applyPage(Activity a) {
        if (a == null) return;
        try {
            View root = a.findViewById(R.id.root);
            if (root != null) root.setBackgroundColor(BG);
            View bar = a.findViewById(R.id.bottomBar);
            if (bar != null) bar.setBackgroundColor(CARD);
            View list = a.findViewById(R.id.list);
            if (list != null) {
                list.setBackground(bg(CARD, a, 18f));
                if (list instanceof android.widget.ListView) {
                    ((android.widget.ListView) list).setDivider(new ColorDrawable(LINE));
                    ((android.widget.ListView) list).setDividerHeight(1);
                }
            }
        } catch (Exception ignored) {
        }
        try {
            Window w = a.getWindow();
            if (w != null) {
                w.setStatusBarColor(BG);
                w.setNavigationBarColor(CARD);
                if (Build.VERSION.SDK_INT >= 23) {
                    View dv = w.getDecorView();
                    int flags = dv.getSystemUiVisibility();
                    if (DARK) flags &= ~View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
                    else flags |= View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
                    dv.setSystemUiVisibility(flags);
                }
            }
        } catch (Exception ignored) {
        }
    }

    public static int dp(Context c, float v) {
        return (int) (v * c.getResources().getDisplayMetrics().density + 0.5f);
    }

    public static GradientDrawable bg(int color, Context c, float radiusDp) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(c, radiusDp));
        return d;
    }

    public static GradientDrawable bgStroke(int color, int strokeColor, Context c, float radiusDp, float strokeDp) {
        GradientDrawable d = bg(color, c, radiusDp);
        d.setStroke(dp(c, strokeDp), strokeColor);
        return d;
    }

    public static RippleDrawable ripple(int color, Context c, float radiusDp) {
        return new RippleDrawable(ColorStateList.valueOf(0x224C6FFF), bg(color, c, radiusDp), null);
    }

    public static TextView text(Context c, CharSequence s, float sp, int color, boolean bold) {
        TextView t = new TextView(c);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) {
            t.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        }
        return t;
    }

    public static TextView label(Context c, CharSequence s) {
        TextView t = text(c, s, 13f, SUB, false);
        t.setPadding(0, dp(c, 2), 0, dp(c, 8));
        return t;
    }

    public static LinearLayout card(Context c) {
        LinearLayout v = new LinearLayout(c);
        v.setOrientation(LinearLayout.VERTICAL);
        v.setBackground(bg(CARD, c, 18f));
        v.setPadding(dp(c, 18), dp(c, 16), dp(c, 18), dp(c, 16));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.bottomMargin = dp(c, 12);
        v.setLayoutParams(lp);
        v.setElevation(dp(c, 1));
        return v;
    }

    public static LinearLayout row(Context c) {
        LinearLayout v = new LinearLayout(c);
        v.setOrientation(LinearLayout.HORIZONTAL);
        v.setGravity(android.view.Gravity.CENTER_VERTICAL);
        v.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        return v;
    }

    public static View space(Context c, int hDp) {
        View v = new View(c);
        v.setLayoutParams(new LinearLayout.LayoutParams(1, dp(c, hDp)));
        return v;
    }

    public static View flex(Context c) {
        View v = new View(c);
        v.setLayoutParams(new LinearLayout.LayoutParams(0, 1, 1f));
        return v;
    }

    public static View divider(Context c) {
        View v = new View(c);
        v.setBackgroundColor(LINE);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, Math.max(1, dp(c, 0.7f)));
        lp.topMargin = dp(c, 10);
        lp.bottomMargin = dp(c, 10);
        v.setLayoutParams(lp);
        return v;
    }

    public static TextView pill(Context c, CharSequence s, int textColor, int bgColor) {
        TextView t = text(c, s, 11f, textColor, true);
        t.setBackground(bg(bgColor, c, 20f));
        t.setPadding(dp(c, 9), dp(c, 4), dp(c, 9), dp(c, 4));
        return t;
    }

    public static TextView button(Context c, CharSequence s, boolean primary) {
        TextView t = text(c, s, 13f, primary ? 0xFFFFFFFF : PRIMARY, true);
        t.setGravity(android.view.Gravity.CENTER);
        t.setBackground(ripple(primary ? PRIMARY : PRIMARY_SOFT, c, 12f));
        t.setPadding(dp(c, 16), dp(c, 10), dp(c, 16), dp(c, 10));
        t.setClickable(true);
        return t;
    }

    public static TextView buttonSmall(Context c, CharSequence s) {
        TextView t = text(c, s, 12f, PRIMARY, true);
        t.setGravity(android.view.Gravity.CENTER);
        t.setBackground(ripple(PRIMARY_SOFT, c, 10f));
        t.setPadding(dp(c, 12), dp(c, 7), dp(c, 12), dp(c, 7));
        t.setClickable(true);
        return t;
    }
}
