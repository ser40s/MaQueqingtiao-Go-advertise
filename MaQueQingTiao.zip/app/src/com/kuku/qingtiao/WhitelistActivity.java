package com.kuku.qingtiao;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

public class WhitelistActivity extends Activity {

    private static class Entry {
        String pkg;
        String label;
        boolean system;
        String cat = "其他";
    }

    private static class Row {
        boolean header;
        String cat;
        int count;
        Entry entry;
    }

    private static class Holder {
        CheckBox check;
        ImageView icon;
        TextView name;
        TextView pkg;
        TextView sysTag;
    }

    private ListView listView;
    private Adapter adapter;
    private final List<Entry> all = new ArrayList<Entry>();
    private final List<Row> shown = new ArrayList<Row>();
    private final Map<String, Drawable> icons = new HashMap<String, Drawable>();
    private final Set<String> selected = new HashSet<String>();
    private String keyword = "";
    private Handler ui;
    private Drawable defIcon;
    private TextView countView;
    private LinearLayout catBar;
    private boolean showSystem = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Ui.applyTheme(this);
        if (Ui.DARK) setTheme(R.style.AppThemeDark);
        setContentView(R.layout.activity_picker);
        Ui.applyPage(this);
        ui = new Handler(Looper.getMainLooper());
        defIcon = getPackageManager().getDefaultActivityIcon();
        selected.clear();
        selected.addAll(RuleStore.get(this).whitelist());

        buildHeader();

        listView = (ListView) findViewById(R.id.list);
        adapter = new Adapter();
        listView.setAdapter(adapter);

        loadApps();
    }

    private void buildHeader() {
        LinearLayout header = (LinearLayout) findViewById(R.id.header);

        TextView back = Ui.text(this, "‹  返回", 14f, Ui.PRIMARY, true);
        back.setPadding(0, 0, 0, Ui.dp(this, 14));
        back.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                finish();
            }
        });
        header.addView(back);

        header.addView(Ui.text(this, "应用白名单", 26f, Ui.TEXT, true));
        TextView sub = Ui.text(this, "勾选的应用不会被自动点击。系统应用默认已勾选，可取消。", 12f, Ui.SUB, false);
        sub.setPadding(0, Ui.dp(this, 5), 0, Ui.dp(this, 10));
        header.addView(sub);

        countView = Ui.text(this, "", 11f, Ui.PRIMARY, true);
        countView.setPadding(0, 0, 0, Ui.dp(this, 10));
        header.addView(countView);

        EditText search = new EditText(this);
        search.setHint("搜索应用名");
        search.setTextSize(14f);
        search.setTextColor(Ui.TEXT);
        search.setHintTextColor(0xFFB4B9C6);
        search.setSingleLine(true);
        search.setBackground(Ui.bg(Ui.CARD, this, 12f));
        search.setPadding(Ui.dp(this, 14), Ui.dp(this, 10), Ui.dp(this, 14), Ui.dp(this, 10));
        search.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int a, int b, int c) {
            }

            public void onTextChanged(CharSequence s, int a, int b, int c) {
                keyword = s == null ? "" : s.toString().trim().toLowerCase(Locale.ROOT);
                applyFilter();
            }

            public void afterTextChanged(Editable s) {
            }
        });
        header.addView(search);

        android.widget.HorizontalScrollView hs = new android.widget.HorizontalScrollView(this);
        hs.setHorizontalScrollBarEnabled(false);
        hs.setPadding(0, Ui.dp(this, 10), 0, 0);
        catBar = new LinearLayout(this);
        catBar.setOrientation(LinearLayout.HORIZONTAL);
        hs.addView(catBar);
        header.addView(hs);

        showSystem = !RuleStore.get(this).hideSystemApps();
        CheckBox cb = new CheckBox(this);
        cb.setText("显示系统应用");
        cb.setTextSize(11.5f);
        cb.setTextColor(Ui.SUB);
        cb.setChecked(showSystem);
        cb.setPadding(0, Ui.dp(this, 8), 0, 0);
        cb.setOnCheckedChangeListener(new android.widget.CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(android.widget.CompoundButton b, boolean checked) {
                showSystem = checked;
                RuleStore.get(WhitelistActivity.this).setHideSystemApps(!checked);
                applyFilter();
            }
        });
        header.addView(cb);
    }

    private void rebuildCatBar() {
        if (catBar == null) return;
        catBar.removeAllViews();
        for (int i = 0; i < shown.size(); i++) {
            final Row r = shown.get(i);
            if (!r.header) continue;
            final int pos = i;
            TextView chip = Ui.pill(this, r.cat + " " + r.count, Ui.PRIMARY, Ui.PRIMARY_SOFT);
            chip.setPadding(Ui.dp(this, 12), Ui.dp(this, 6), Ui.dp(this, 12), Ui.dp(this, 6));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            lp.rightMargin = Ui.dp(this, 8);
            chip.setLayoutParams(lp);
            chip.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    listView.setSelectionFromTop(pos, 0);
                }
            });
            catBar.addView(chip);
        }
    }

    private void updateCount() {
        if (countView != null) {
            countView.setText("已选 " + selected.size() + " 个应用");
        }
    }

    private void loadApps() {
        new Thread(new Runnable() {
            public void run() {
                final List<Entry> out = new ArrayList<Entry>();
                try {
                    PackageManager pm = getPackageManager();
                    Intent main = new Intent(Intent.ACTION_MAIN);
                    main.addCategory(Intent.CATEGORY_LAUNCHER);
                    List<ResolveInfo> list = pm.queryIntentActivities(main, 0);
                    Set<String> seen = new HashSet<String>();
                    for (int i = 0; i < list.size(); i++) {
                        ResolveInfo ri = list.get(i);
                        if (ri.activityInfo == null) continue;
                        String pkg = ri.activityInfo.packageName;
                        if (pkg == null || seen.contains(pkg)) continue;
                        seen.add(pkg);
                        Entry e = new Entry();
                        e.pkg = pkg;
                        try {
                            e.label = ri.loadLabel(pm).toString();
                        } catch (Exception ex) {
                            e.label = pkg;
                        }
                        try {
                            ApplicationInfo ai = pm.getApplicationInfo(pkg, 0);
                            e.system = (ai.flags & ApplicationInfo.FLAG_SYSTEM) != 0;
                            e.cat = classify(ai, e.label, pkg);
                        } catch (Exception ex) {
                            e.system = false;
                            e.cat = "其他";
                        }
                        out.add(e);
                    }
                    Collections.sort(out, new Comparator<Entry>() {
                        public int compare(Entry a, Entry b) {
                            return a.label.compareToIgnoreCase(b.label);
                        }
                    });
                } catch (Exception ignored) {
                }
                ui.post(new Runnable() {
                    public void run() {
                        all.clear();
                        all.addAll(out);
                        applyFilter();
                    }
                });
                for (int i = 0; i < out.size(); i++) {
                    final String pkg = out.get(i).pkg;
                    try {
                        final Drawable d = getPackageManager().getApplicationIcon(pkg);
                        ui.post(new Runnable() {
                            public void run() {
                                icons.put(pkg, d);
                            }
                        });
                    } catch (Exception ignored) {
                    }
                    if (i % 20 == 0) {
                        ui.post(new Runnable() {
                            public void run() {
                                if (adapter != null) adapter.notifyDataSetChanged();
                            }
                        });
                    }
                }
                ui.post(new Runnable() {
                    public void run() {
                        if (adapter != null) adapter.notifyDataSetChanged();
                    }
                });
            }
        }).start();
    }

    private void applyFilter() {
        shown.clear();
        String[] order = {"资金", "游戏", "其他", "系统"};
        for (int k = 0; k < order.length; k++) {
            String cat = order[k];
            int count = 0;
            for (int i = 0; i < all.size(); i++) {
                Entry e = all.get(i);
                if (!cat.equals(e.cat)) continue;
                if (!showSystem && e.system) continue;
                if (keyword.length() > 0
                        && !e.label.toLowerCase(Locale.ROOT).contains(keyword)
                        && !e.pkg.toLowerCase(Locale.ROOT).contains(keyword)) continue;
                count++;
            }
            if (count == 0) continue;
            Row head = new Row();
            head.header = true;
            head.cat = cat;
            head.count = count;
            shown.add(head);
            for (int i = 0; i < all.size(); i++) {
                Entry e = all.get(i);
                if (!cat.equals(e.cat)) continue;
                if (!showSystem && e.system) continue;
                if (keyword.length() > 0
                        && !e.label.toLowerCase(Locale.ROOT).contains(keyword)
                        && !e.pkg.toLowerCase(Locale.ROOT).contains(keyword)) continue;
                Row r = new Row();
                r.entry = e;
                shown.add(r);
            }
        }
        if (adapter != null) adapter.notifyDataSetChanged();
        rebuildCatBar();
        updateCount();
    }

    private String classify(ApplicationInfo ai, String label, String pkg) {
        if ((ai.flags & ApplicationInfo.FLAG_SYSTEM) != 0) return "系统";
        if (Build.VERSION.SDK_INT >= 26 && ai.category == ApplicationInfo.CATEGORY_GAME) return "游戏";
        String s = (label + " " + pkg).toLowerCase(Locale.ROOT);
        if (isFinance(s)) return "资金";
        return "其他";
    }

    private boolean isFinance(String s) {
        String[] kw = {"bank", "pay", "alipay", "tenpay", "wallet", "fund", "stock",
                "securities", "credit", "loan", "finance", "insurance", "licai",
                "taobao", "tmall", "jingdong", "pinduoduo", "meituan", "suning",
                "gome", "dewu", "xianyu", "vipshop",
                "银行", "支付", "理财", "基金", "证券", "保险", "信用卡", "钱包",
                "借贷", "贷款", "分期", "购物", "商城", "超市", "淘宝", "天猫",
                "京东", "拼多多", "美团", "饿了么", "苏宁", "国美", "唯品会", "闲鱼", "得物"};
        for (int i = 0; i < kw.length; i++) {
            if (s.contains(kw[i])) return true;
        }
        return false;
    }

    private void toggleCat(String cat) {
        List<String> pkgs = new ArrayList<String>();
        for (int i = 0; i < all.size(); i++) {
            Entry e = all.get(i);
            if (cat.equals(e.cat)) pkgs.add(e.pkg);
        }
        boolean allOn = true;
        for (int i = 0; i < pkgs.size(); i++) {
            if (!selected.contains(pkgs.get(i))) {
                allOn = false;
                break;
            }
        }
        for (int i = 0; i < pkgs.size(); i++) {
            if (allOn) selected.remove(pkgs.get(i));
            else selected.add(pkgs.get(i));
        }
        RuleStore.get(this).saveWhitelist(selected);
        applyFilter();
    }

    private class Adapter extends BaseAdapter {

        public int getViewTypeCount() {
            return 2;
        }

        public int getItemViewType(int position) {
            return shown.get(position).header ? 0 : 1;
        }

        public int getCount() {
            return shown.size();
        }

        public Object getItem(int position) {
            return shown.get(position);
        }

        public long getItemId(int position) {
            return position;
        }

        public View getView(int position, View convertView, ViewGroup parent) {
            final Row r0 = shown.get(position);
            if (r0.header) {
                LinearLayout hrow = new LinearLayout(WhitelistActivity.this);
                hrow.setOrientation(LinearLayout.HORIZONTAL);
                hrow.setGravity(Gravity.CENTER_VERTICAL);
                hrow.setPadding(Ui.dp(WhitelistActivity.this, 12), Ui.dp(WhitelistActivity.this, 14),
                        Ui.dp(WhitelistActivity.this, 14), Ui.dp(WhitelistActivity.this, 6));
                TextView t = Ui.text(WhitelistActivity.this, r0.cat + " · " + r0.count, 13f, Ui.SUB, true);
                hrow.addView(t, new LinearLayout.LayoutParams(0,
                        ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
                boolean allOn = true;
                for (int i = 0; i < all.size(); i++) {
                    Entry e = all.get(i);
                    if (r0.cat.equals(e.cat) && !selected.contains(e.pkg)) {
                        allOn = false;
                        break;
                    }
                }
                TextView btn = Ui.text(WhitelistActivity.this, allOn ? "取消全选" : "全选",
                        11.5f, Ui.PRIMARY, true);
                btn.setPadding(Ui.dp(WhitelistActivity.this, 10), Ui.dp(WhitelistActivity.this, 4),
                        Ui.dp(WhitelistActivity.this, 2), Ui.dp(WhitelistActivity.this, 4));
                final String cat = r0.cat;
                btn.setOnClickListener(new View.OnClickListener() {
                    public void onClick(View v) {
                        toggleCat(cat);
                    }
                });
                hrow.addView(btn);
                return hrow;
            }
            Holder h;
            if (convertView == null) {
                LinearLayout row = new LinearLayout(WhitelistActivity.this);
                row.setOrientation(LinearLayout.HORIZONTAL);
                row.setGravity(Gravity.CENTER_VERTICAL);
                row.setPadding(Ui.dp(WhitelistActivity.this, 10), Ui.dp(WhitelistActivity.this, 8),
                        Ui.dp(WhitelistActivity.this, 14), Ui.dp(WhitelistActivity.this, 8));

                h = new Holder();
                h.check = new CheckBox(WhitelistActivity.this);
                h.check.setClickable(false);
                h.check.setFocusable(false);
                row.addView(h.check, new LinearLayout.LayoutParams(
                        Ui.dp(WhitelistActivity.this, 34), Ui.dp(WhitelistActivity.this, 34)));

                h.icon = new ImageView(WhitelistActivity.this);
                LinearLayout.LayoutParams ilp = new LinearLayout.LayoutParams(
                        Ui.dp(WhitelistActivity.this, 34), Ui.dp(WhitelistActivity.this, 34));
                ilp.leftMargin = Ui.dp(WhitelistActivity.this, 6);
                ilp.rightMargin = Ui.dp(WhitelistActivity.this, 10);
                h.icon.setLayoutParams(ilp);
                row.addView(h.icon);

                LinearLayout mid = new LinearLayout(WhitelistActivity.this);
                mid.setOrientation(LinearLayout.VERTICAL);
                LinearLayout nameRow = new LinearLayout(WhitelistActivity.this);
                nameRow.setOrientation(LinearLayout.HORIZONTAL);
                nameRow.setGravity(Gravity.CENTER_VERTICAL);
                h.name = Ui.text(WhitelistActivity.this, "", 14f, Ui.TEXT, true);
                nameRow.addView(h.name);
                h.sysTag = Ui.pill(WhitelistActivity.this, "系统", 0xFF6B7280, 0xFFF0F1F5);
                LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                slp.leftMargin = Ui.dp(WhitelistActivity.this, 6);
                h.sysTag.setLayoutParams(slp);
                nameRow.addView(h.sysTag);
                mid.addView(nameRow);
                h.pkg = Ui.text(WhitelistActivity.this, "", 10f, Ui.SUB, false);
                h.pkg.setPadding(0, Ui.dp(WhitelistActivity.this, 2), 0, 0);
                mid.addView(h.pkg);
                row.addView(mid, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

                convertView = row;
                convertView.setTag(h);
            } else {
                h = (Holder) convertView.getTag();
            }

            final Entry e = r0.entry;
            h.name.setText(e.label);
            h.pkg.setText(e.pkg);
            boolean isSelf = e.pkg.equals(getPackageName());
            if (isSelf) {
                h.sysTag.setVisibility(View.VISIBLE);
                h.sysTag.setText("本应用");
            } else if (e.system) {
                h.sysTag.setVisibility(View.VISIBLE);
                h.sysTag.setText("系统");
            } else {
                h.sysTag.setVisibility(View.GONE);
            }
            Drawable d = icons.get(e.pkg);
            h.icon.setImageDrawable(d != null ? d : defIcon);
            h.check.setChecked(selected.contains(e.pkg));
            h.check.setEnabled(true);
            h.check.setAlpha(1f);

            convertView.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    boolean nowOn = !selected.contains(e.pkg);
                    if (nowOn) selected.add(e.pkg);
                    else selected.remove(e.pkg);
                    RuleStore.get(WhitelistActivity.this).setWhitelisted(e.pkg, nowOn);
                    notifyDataSetChanged();
                    updateCount();
                }
            });
            return convertView;
        }
    }
}
