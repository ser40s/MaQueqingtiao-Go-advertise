package com.kuku.qingtiao;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.List;
import java.util.Locale;

public class RuleStore {

    private static final String SP = "qingtiao";
    private static final String KEY_RULES = "rules";
    private static RuleStore sInstance;

    private final Context ctx;
    private final SharedPreferences sp;
    private volatile Set<String> wlCache;
    private volatile JSONObject strictCache;
    private volatile Set<String> kwCache;

    private RuleStore(Context c) {
        ctx = c.getApplicationContext();
        sp = ctx.getSharedPreferences(SP, Context.MODE_PRIVATE);
    }

    public static synchronized RuleStore get(Context c) {
        if (sInstance == null) sInstance = new RuleStore(c);
        return sInstance;
    }

    public synchronized List<Rule> all() {
        List<Rule> out = new ArrayList<Rule>();
        String raw = sp.getString(KEY_RULES, "");
        if (raw == null || raw.length() == 0) return out;
        try {
            JSONArray arr = new JSONArray(raw);
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.optJSONObject(i);
                if (o != null) out.add(Rule.from(o));
            }
        } catch (Exception ignored) {
        }
        return out;
    }

    private void persist(List<Rule> list) {
        JSONArray arr = new JSONArray();
        for (int i = 0; i < list.size(); i++) arr.put(list.get(i).toJson());
        sp.edit().putString(KEY_RULES, arr.toString()).apply();
    }

    public synchronized List<Rule> forPackage(String pkg) {
        List<Rule> out = new ArrayList<Rule>();
        if (pkg == null) return out;
        List<Rule> all = all();
        for (int i = 0; i < all.size(); i++) {
            Rule r = all.get(i);
            if (pkg.equals(r.pkg)) out.add(r);
        }
        return out;
    }

    public synchronized int countFor(String pkg) {
        return forPackage(pkg).size();
    }

    public synchronized Rule find(String id) {
        if (id == null) return null;
        List<Rule> all = all();
        for (int i = 0; i < all.size(); i++) {
            if (id.equals(all.get(i).id)) return all.get(i);
        }
        return null;
    }

    public synchronized void save(Rule rule) {
        if (rule == null) return;
        List<Rule> all = all();
        boolean replaced = false;
        for (int i = 0; i < all.size(); i++) {
            if (all.get(i).id.equals(rule.id)) {
                all.set(i, rule);
                replaced = true;
                break;
            }
        }
        if (!replaced) all.add(rule);
        persist(all);
    }

    public synchronized int purgeInvalid() {
        List<Rule> list = all();
        int n = 0;
        for (int i = 0; i < list.size(); i++) {
            Rule r = list.get(i);
            if (r.conditions.isEmpty() && r.x < 0) {
                remove(r.id);
                n++;
            }
        }
        return n;
    }

    public synchronized int purgeEmptyDrafts() {
        List<Rule> list = all();
        int n = 0;
        for (int i = 0; i < list.size(); i++) {
            Rule r = list.get(i);
            if (r.draft && (r.x < 0 || r.conditions.isEmpty())) {
                remove(r.id);
                n++;
            }
        }
        return n;
    }

    public synchronized void setFollowOn(String ruleId, boolean on) {
        Rule r = find(ruleId);
        if (r == null) return;
        r.followOn = on;
        save(r);
    }

    public synchronized void addFollowPoint(String ruleId, int x, int y, int delay) {
        Rule r = find(ruleId);
        if (r == null) return;
        r.followOn = true;
        r.followPts.add(new int[]{x, y, delay});
        save(r);
    }

    public synchronized void removeFollowPoint(String ruleId, int idx) {
        Rule r = find(ruleId);
        if (r == null || idx < 0 || idx >= r.followPts.size()) return;
        r.followPts.remove(idx);
        save(r);
    }

    public synchronized void setFollowPointDelay(String ruleId, int idx, int delay) {
        Rule r = find(ruleId);
        if (r == null || idx < 0 || idx >= r.followPts.size()) return;
        int[] p = r.followPts.get(idx);
        r.followPts.set(idx, new int[]{p[0], p[1], delay});
        save(r);
    }

    public synchronized int setEnabledAll(String pkg, boolean on) {
        List<Rule> list = all();
        int n = 0;
        for (int i = 0; i < list.size(); i++) {
            Rule r = list.get(i);
            if (pkg.equals(r.pkg) && r.enabled != on) {
                r.enabled = on;
                save(r);
                n++;
            }
        }
        return n;
    }

    public synchronized int removeAll(String pkg) {
        List<Rule> list = all();
        int n = 0;
        for (int i = 0; i < list.size(); i++) {
            Rule r = list.get(i);
            if (pkg.equals(r.pkg)) {
                remove(r.id);
                n++;
            }
        }
        return n;
    }

    public synchronized void remove(String id) {
        List<Rule> all = all();
        for (int i = 0; i < all.size(); i++) {
            if (all.get(i).id.equals(id)) {
                all.remove(i);
                break;
            }
        }
        persist(all);
    }

    public synchronized void bumpHits(String ruleId) {
        List<Rule> all = all();
        for (int i = 0; i < all.size(); i++) {
            if (all.get(i).id.equals(ruleId)) {
                all.get(i).hits = all.get(i).hits + 1;
                persist(all);
                return;
            }
        }
    }

    public boolean isEngineOn() {
        return sp.getBoolean("engine_on", true);
    }

    public void setEngineOn(boolean on) {
        sp.edit().putBoolean("engine_on", on).apply();
    }

    public void addHit() {
        String today = new SimpleDateFormat("yyyyMMdd", Locale.CHINA).format(new Date());
        String savedDay = sp.getString("hit_day", "");
        long todayCount = sp.getLong("hit_today", 0);
        if (!today.equals(savedDay)) {
            todayCount = 0;
            savedDay = today;
        }
        sp.edit()
                .putLong("hit_total", sp.getLong("hit_total", 0) + 1)
                .putLong("hit_today", todayCount + 1)
                .putString("hit_day", savedDay)
                .apply();
    }

    public long hitsToday() {
        String today = new SimpleDateFormat("yyyyMMdd", Locale.CHINA).format(new Date());
        if (!today.equals(sp.getString("hit_day", ""))) return 0;
        return sp.getLong("hit_today", 0);
    }

    public void resetHits() {
        sp.edit().putLong("hit_total", 0).putLong("hit_today", 0).putString("hit_day", "").apply();
    }

    public long hitsTotal() {
        return sp.getLong("hit_total", 0);
    }

    // ---------- 悬浮窗拾取暂存 ----------

    public void setActiveDraft(String ruleId) {
        sp.edit().putString("active_draft", ruleId == null ? "" : ruleId).apply();
    }

    public String activeDraft() {
        String s = sp.getString("active_draft", "");
        return s == null || s.length() == 0 ? null : s;
    }

    private JSONObject draft(String ruleId) {
        JSONObject o = null;
        try {
            String raw = sp.getString("draft_" + ruleId, "");
            if (raw != null && raw.length() > 0) o = new JSONObject(raw);
        } catch (Exception ignored) {
        }
        if (o == null) o = new JSONObject();
        return o;
    }

    private void saveDraft(String ruleId, JSONObject o) {
        sp.edit().putString("draft_" + ruleId, o.toString()).apply();
    }

    public synchronized void addDraftCondition(String ruleId, String cond) {
        if (ruleId == null || cond == null) return;
        JSONObject o = draft(ruleId);
        try {
            JSONArray a = o.optJSONArray("conds");
            if (a == null) a = new JSONArray();
            for (int i = 0; i < a.length(); i++) {
                if (cond.equals(a.optString(i))) return;
            }
            a.put(cond);
            o.put("conds", a);
            saveDraft(ruleId, o);
        } catch (Exception ignored) {
        }
    }

    public synchronized void clearDraftConditions(String ruleId) {
        if (ruleId == null) return;
        JSONObject o = draft(ruleId);
        try {
            o.put("conds", new JSONArray());
            saveDraft(ruleId, o);
        } catch (Exception ignored) {
        }
    }

    public synchronized void removeDraftCondition(String ruleId, String cond) {
        JSONObject o = draft(ruleId);
        try {
            JSONArray a = o.optJSONArray("conds");
            if (a == null) return;
            JSONArray n = new JSONArray();
            for (int i = 0; i < a.length(); i++) {
                String s = a.optString(i);
                if (!s.equals(cond)) n.put(s);
            }
            o.put("conds", n);
            saveDraft(ruleId, o);
        } catch (Exception ignored) {
        }
    }

    public synchronized List<String> draftConditions(String ruleId) {
        List<String> out = new ArrayList<String>();
        if (ruleId == null) return out;
        try {
            JSONArray a = draft(ruleId).optJSONArray("conds");
            if (a != null) {
                for (int i = 0; i < a.length(); i++) out.add(a.optString(i));
            }
        } catch (Exception ignored) {
        }
        return out;
    }

    public synchronized void setDraftPoint(String ruleId, int x, int y, int sw, int sh) {
        JSONObject o = draft(ruleId);
        try {
            o.put("x", x);
            o.put("y", y);
            o.put("sw", sw);
            o.put("sh", sh);
            o.put("stamp", System.currentTimeMillis());
            saveDraft(ruleId, o);
        } catch (Exception ignored) {
        }
    }

    public synchronized long draftStamp(String ruleId) {
        if (ruleId == null) return 0L;
        return draft(ruleId).optLong("stamp", 0L);
    }

    public synchronized int[] draftPoint(String ruleId) {
        if (ruleId == null) return null;
        JSONObject o = draft(ruleId);
        if (!o.has("x")) return null;
        return new int[]{o.optInt("x", -1), o.optInt("y", -1), o.optInt("sw", 0), o.optInt("sh", 0)};
    }

    public synchronized void clearDraft(String ruleId) {
        if (ruleId == null) return;
        sp.edit().remove("draft_" + ruleId).apply();
    }

    // ---------- 应用白名单 ----------

    public synchronized Set<String> whitelist() {
        Set<String> out = new HashSet<String>();
        try {
            String raw = sp.getString("whitelist", "");
            if (raw != null && raw.length() > 0) {
                JSONArray a = new JSONArray(raw);
                for (int i = 0; i < a.length(); i++) {
                    String p = a.optString(i, "");
                    if (p.length() > 0) out.add(p);
                }
            }
        } catch (Exception ignored) {
        }
        return out;
    }

    public synchronized void saveWhitelist(Set<String> set) {
        JSONArray a = new JSONArray();
        if (set != null) {
            for (String s : set) a.put(s);
        }
        sp.edit().putString("whitelist", a.toString()).apply();
        wlCache = null;
    }

    public boolean isWhitelisted(String pkg) {
        if (pkg != null && pkg.equals(ctx.getPackageName())) return true;
        if (pkg == null) return false;
        Set<String> c = wlCache;
        if (c == null) {
            c = whitelist();
            wlCache = c;
        }
        return c.contains(pkg);
    }

    public synchronized void setWhitelisted(String pkg, boolean on) {
        if (pkg == null) return;
        Set<String> set = whitelist();
        if (on) set.add(pkg);
        else set.remove(pkg);
        saveWhitelist(set);
    }

    public boolean isSelfWlDone() {
        return sp.getBoolean("self_wl_once", false);
    }

    public void markSelfWlDone() {
        sp.edit().putBoolean("self_wl_once", true).apply();
    }

    /** 系统应用 + 所有桌面启动器 + 自己，强制进白名单；可重复调用补齐新装应用 */
    public synchronized void ensureSystemWhitelist() {
        try {
            android.content.pm.PackageManager pm = ctx.getPackageManager();
            Set<String> wl = whitelist();
            boolean changed = false;
            java.util.List<android.content.pm.ApplicationInfo> apps =
                    pm.getInstalledApplications(0);
            for (int i = 0; i < apps.size(); i++) {
                android.content.pm.ApplicationInfo ai = apps.get(i);
                if ((ai.flags & android.content.pm.ApplicationInfo.FLAG_SYSTEM) != 0) {
                    if (wl.add(ai.packageName)) changed = true;
                }
            }
            android.content.Intent home = new android.content.Intent(android.content.Intent.ACTION_MAIN);
            home.addCategory(android.content.Intent.CATEGORY_HOME);
            java.util.List<android.content.pm.ResolveInfo> homes =
                    pm.queryIntentActivities(home, 0);
            for (int i = 0; i < homes.size(); i++) {
                android.content.pm.ResolveInfo ri = homes.get(i);
                if (ri.activityInfo != null && ri.activityInfo.packageName != null) {
                    if (wl.add(ri.activityInfo.packageName)) changed = true;
                }
            }
            if (wl.add(ctx.getPackageName())) changed = true;
            // 已知桌面包名，装了就默认进白名单，用户可自行取消
            String[] launchers = {
                    "com.miui.home", "com.huawei.android.launcher", "com.android.launcher",
                    "com.android.launcher3", "com.google.android.apps.nexuslauncher",
                    "com.oppo.launcher", "com.coloros.launcher", "com.vivo.launcher",
                    "com.bbk.launcher2", "com.sec.android.app.launcher",
                    "com.teslacoilsw.launcher", "com.microsoft.launcher",
                    "com.treydev.launcher", "com.apex.launcher", "com.oneplus.launcher",
                    "com.nothing.launcher"
            };
            for (int i = 0; i < launchers.length; i++) {
                try {
                    pm.getPackageInfo(launchers[i], 0);
                    if (wl.add(launchers[i])) changed = true;
                } catch (Exception ignored) {
                }
            }
            if (changed) saveWhitelist(wl);
            markWhitelistInit();
        } catch (Exception ignored) {
        }
    }

    public synchronized void setMode(String ruleId, int mode) {
        Rule r = find(ruleId);
        if (r == null) return;
        r.mode = mode;
        save(r);
    }

    public int recordMode() {
        return sp.getInt("rec_mode", Rule.MODE_POINT);
    }

    public void setRecordMode(int m) {
        sp.edit().putInt("rec_mode", m).apply();
    }

    public synchronized void setDraftAnchor(String ruleId, int l, int t, int r, int b) {
        sp.edit().putString("draft_anchor_" + ruleId, l + "," + t + "," + r + "," + b).apply();
    }

    public synchronized int[] draftAnchor(String ruleId) {
        String s = sp.getString("draft_anchor_" + ruleId, "");
        if (s == null || s.length() == 0) return null;
        String[] a = s.split(",");
        if (a.length != 4) return null;
        try {
            return new int[]{Integer.parseInt(a[0]), Integer.parseInt(a[1]),
                    Integer.parseInt(a[2]), Integer.parseInt(a[3])};
        } catch (Exception e) {
            return null;
        }
    }

    public synchronized void clearDraftAnchor(String ruleId) {
        sp.edit().remove("draft_anchor_" + ruleId).apply();
    }

    public boolean edgeSnap() {
        return sp.getBoolean("edge_snap", true);
    }

    public void setEdgeSnap(boolean v) {
        sp.edit().putBoolean("edge_snap", v).apply();
    }

    public boolean hideSystemApps() {
        return sp.getBoolean("wl_hide_sys", false);
    }

    public void setHideSystemApps(boolean v) {
        sp.edit().putBoolean("wl_hide_sys", v).apply();
    }

    /** 老版本升级：把可能的桌面补进白名单一次，之后用户自行调整 */
    public synchronized void migrateLaunchersToWhitelist() {
        if (sp.getBoolean("wl_launcher_migrated", false)) return;
        try {
            android.content.pm.PackageManager pm = ctx.getPackageManager();
            Set<String> wl = whitelist();
            android.content.Intent home = new android.content.Intent(android.content.Intent.ACTION_MAIN);
            home.addCategory(android.content.Intent.CATEGORY_HOME);
            java.util.List<android.content.pm.ResolveInfo> homes = pm.queryIntentActivities(home, 0);
            for (int i = 0; i < homes.size(); i++) {
                android.content.pm.ResolveInfo ri = homes.get(i);
                if (ri.activityInfo != null && ri.activityInfo.packageName != null) {
                    wl.add(ri.activityInfo.packageName);
                }
            }
            String[] launchers = {
                    "com.miui.home", "com.huawei.android.launcher", "com.android.launcher",
                    "com.android.launcher3", "com.google.android.apps.nexuslauncher",
                    "com.oppo.launcher", "com.coloros.launcher", "com.vivo.launcher",
                    "com.bbk.launcher2", "com.sec.android.app.launcher",
                    "com.teslacoilsw.launcher", "com.microsoft.launcher",
                    "com.treydev.launcher", "com.apex.launcher", "com.oneplus.launcher",
                    "com.nothing.launcher"
            };
            for (int i = 0; i < launchers.length; i++) {
                try {
                    pm.getPackageInfo(launchers[i], 0);
                    wl.add(launchers[i]);
                } catch (Exception ignored) {
                }
            }
            saveWhitelist(wl);
        } catch (Exception ignored) {
        }
        sp.edit().putBoolean("wl_launcher_migrated", true).apply();
    }

    /** 1.0.42 默认隐藏系统应用，升级后恢复显示一次 */
    public void migrateWhitelistDisplay() {
        if (sp.getBoolean("wl_show_migrated", false)) return;
        sp.edit().putBoolean("wl_hide_sys", false)
                .putBoolean("wl_show_migrated", true).apply();
    }

    public boolean isWhitelistInit() {
        return sp.getBoolean("whitelist_init", false);
    }

    public void markWhitelistInit() {
        sp.edit().putBoolean("whitelist_init", true).apply();
    }

    // ---------- 严格模式（按应用） ----------

    private JSONObject strictAll() {
        JSONObject c = strictCache;
        if (c == null) {
            c = new JSONObject();
            try {
                String raw = sp.getString("strict", "");
                if (raw != null && raw.length() > 0) c = new JSONObject(raw);
            } catch (Exception ignored) {
            }
            strictCache = c;
        }
        return c;
    }

    public boolean isStrict(String pkg) {
        if (pkg == null) return false;
        try {
            JSONObject o = strictAll().optJSONObject(pkg);
            return o != null && o.optBoolean("on", false);
        } catch (Exception e) {
            return false;
        }
    }

    public int[] strictParams(String pkg) {
        if (pkg == null) return new int[]{0, 0};
        try {
            JSONObject o = strictAll().optJSONObject(pkg);
            if (o == null) return new int[]{0, 0};
            return new int[]{o.optInt("base", 0), o.optInt("tol", 0)};
        } catch (Exception e) {
            return new int[]{0, 0};
        }
    }

    public synchronized void setStrict(String pkg, boolean on, int base, int tol) {
        if (pkg == null) return;
        try {
            JSONObject all = strictAll();
            JSONObject o = new JSONObject();
            o.put("on", on);
            o.put("base", base);
            o.put("tol", tol);
            all.put(pkg, o);
            sp.edit().putString("strict", all.toString()).apply();
            strictCache = null;
        } catch (Exception ignored) {
        }
    }

    // ---------- 自定义跳过关键词 ----------

    public String customKeywordsRaw() {
        return sp.getString("custom_kw", "");
    }

    public void setCustomKeywordsRaw(String raw) {
        sp.edit().putString("custom_kw", raw == null ? "" : raw).apply();
        kwCache = null;
    }

    public Set<String> customKeywords() {
        Set<String> c = kwCache;
        if (c == null) {
            c = new HashSet<String>();
            String raw = customKeywordsRaw();
            if (raw != null && raw.length() > 0) {
                String[] lines = raw.split("\n");
                for (int i = 0; i < lines.length; i++) {
                    String t = lines[i].trim().toLowerCase(java.util.Locale.ROOT);
                    if (t.length() > 0) c.add(t);
                }
            }
            kwCache = c;
        }
        return c;
    }

    // ---------- 录制提示 ----------

    public boolean hideRecordTip() {
        return sp.getBoolean("hide_record_tip", false);
    }

    public void setHideRecordTip(boolean v) {
        sp.edit().putBoolean("hide_record_tip", v).apply();
    }

    // ---------- 补齐状态栏 ----------

    public boolean padStatusBar() {
        return sp.getBoolean("pad_status_bar", false);
    }

    public void setPadStatusBar(boolean pad) {
        sp.edit().putBoolean("pad_status_bar", pad).apply();
    }

    // ---------- 通用引擎严格模式 ----------

    public boolean genericStrict() {
        return sp.getBoolean("gen_strict", false);
    }

    public void setGenericStrict(boolean v) {
        sp.edit().putBoolean("gen_strict", v).apply();
    }

    public int genericStrictMax() {
        return sp.getInt("gen_strict_max", 30);
    }

    public void setGenericStrictMax(int v) {
        sp.edit().putInt("gen_strict_max", v).apply();
    }

    // ---------- 单应用通用引擎延迟 ----------

    public long genDelay(String pkg) {
        if (pkg == null) return 0L;
        return sp.getLong("gen_delay_" + pkg, 0L);
    }

    public long genDelayGlobal() {
        return sp.getLong("gen_delay_all", 0L);
    }

    public void setGenDelayGlobal(long ms) {
        sp.edit().putLong("gen_delay_all", ms).apply();
    }

    public void setGenDelay(String pkg, long ms) {
        if (pkg == null) return;
        sp.edit().putLong("gen_delay_" + pkg, ms).apply();
    }

    // ---------- 常驻通知 / 后台卡片 ----------

    public boolean keepNotify() {
        return sp.getBoolean("keep_notify", false);
    }

    public void setKeepNotify(boolean v) {
        sp.edit().putBoolean("keep_notify", v).apply();
    }

    public boolean hideRecents() {
        return sp.getBoolean("hide_recents", false);
    }

    public void setHideRecents(boolean v) {
        sp.edit().putBoolean("hide_recents", v).apply();
    }

    // ---------- 深色模式 ----------

    public boolean isDark() {
        return sp.getBoolean("dark_mode", false);
    }

    public void setDark(boolean v) {
        sp.edit().putBoolean("dark_mode", v).apply();
    }

    // ---------- 备份与恢复（不含白名单） ----------

    public synchronized String exportJson() {
        JSONObject o = new JSONObject();
        try {
            o.put("app", "qingtiao");
            o.put("version", 1);
            o.put("exportedAt", System.currentTimeMillis());
            JSONArray arr = new JSONArray();
            List<Rule> list = all();
            for (int i = 0; i < list.size(); i++) arr.put(list.get(i).toJson());
            o.put("rules", arr);
            o.put("strict", strictAll());
            o.put("custom_kw", customKeywordsRaw());
            o.put("engine_on", isEngineOn());
            o.put("hide_record_tip", hideRecordTip());
        } catch (Exception ignored) {
        }
        return o.toString();
    }

    public synchronized int importJson(String json) {
        if (json == null || json.trim().length() == 0) return -1;
        try {
            JSONObject o = new JSONObject(json.trim());
            if (!"qingtiao".equals(o.optString("app", ""))) return -1;

            int n = 0;
            JSONArray arr = o.optJSONArray("rules");
            if (arr != null) {
                List<Rule> existing = all();
                Map<String, Integer> idx = new HashMap<String, Integer>();
                for (int i = 0; i < existing.size(); i++) idx.put(existing.get(i).id, Integer.valueOf(i));
                for (int i = 0; i < arr.length(); i++) {
                    JSONObject ro = arr.optJSONObject(i);
                    if (ro == null) continue;
                    Rule r = Rule.from(ro);
                    if (r.pkg == null || r.pkg.length() == 0) continue;
                    Integer pos = idx.get(r.id);
                    if (pos != null) {
                        existing.set(pos.intValue(), r);
                    } else {
                        existing.add(r);
                        idx.put(r.id, Integer.valueOf(existing.size() - 1));
                    }
                    n++;
                }
                persist(existing);
            }

            JSONObject st = o.optJSONObject("strict");
            if (st != null) {
                sp.edit().putString("strict", st.toString()).apply();
                strictCache = null;
            }
            if (o.has("custom_kw")) setCustomKeywordsRaw(o.optString("custom_kw", ""));
            if (o.has("engine_on")) setEngineOn(o.optBoolean("engine_on", true));
            if (o.has("hide_record_tip")) setHideRecordTip(o.optBoolean("hide_record_tip", false));
            return n;
        } catch (Exception e) {
            return -1;
        }
    }
}
