package com.kuku.qingtiao;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.app.ActivityManager;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.text.InputType;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.TextView;
import android.widget.Toast;

import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class OverlayService extends Service implements View.OnTouchListener {

    public static boolean alive = false;
    private static WeakReference<OverlayService> sRef;

    public static void setTouchable(boolean touchable) {
        OverlayService s = sRef == null ? null : sRef.get();
        if (s == null) return;
        try {
            s.applyTouchable(touchable);
        } catch (Exception ignored) {
        }
    }

    private WindowManager wm;
    private FrameLayout panel;
    private WindowManager.LayoutParams panelLp;
    private FrameLayout layer;
    private TextView hintView;
    private View cursor;
    private WindowManager.LayoutParams cursorLp;
    private View exitChip;
    private LinearLayout inputBox;
    private EditText seqInput;
    private List<Box> lastBoxes = new ArrayList<Box>();
    private String targetRuleId;
    private boolean followPick = false;
    private boolean pickTarget = false;
    private CheckBox dynamicCheck;
    private EditText targetInput;
    private int cornerSel = 0;
    private LinearLayout panelBox;
    private TextView miniBtn;
    private TextView titleLabel;
    private boolean collapsed = false;
    private CheckBox[] cornerBoxes = new CheckBox[4];
    private TextView saveBtn;
    private int lastTotalNodes = 0;
    private int cursorSize = 0;
    private WindowManager.LayoutParams layerLp;
    private TextView wcStatus;
    private final Handler uiHandler = new Handler(Looper.getMainLooper());
    private String inspectPkg = "";
    private boolean fromEdit = false;
    private int sw = 1080;
    private int sh = 1920;

    private float downRawX, downRawY;
    private int downX, downY;

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        alive = true;
        sRef = new WeakReference<OverlayService>(this);
        wm = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
        startAsForeground();
        computeSize();
        SkipService.setRecordingMode(true);
        setRecentsVisible(true);
        addPanel();
        uiHandler.post(new Runnable() {
            public void run() {
                if (wcStatus != null) {
                    boolean ok = SkipService.get() != null;
                    wcStatus.setVisibility(ok ? View.GONE : View.VISIBLE);
                    if (!ok) wcStatus.setText("无障碍未连接 · 请到系统设置重新开启轻跳");
                }
                uiHandler.postDelayed(this, 2000L);
            }
        });
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null) {
            fromEdit = intent.getBooleanExtra("fromEdit", false);
            followPick = false;
            pickTarget = intent.getBooleanExtra("pickTarget", false);
            String rid = intent.getStringExtra("ruleId");
            if (rid != null && rid.length() > 0) {
                targetRuleId = rid;
                followPick = intent.getBooleanExtra("followPick", false);
                RuleStore.get(this).setActiveDraft(rid);
                Rule r = RuleStore.get(this).find(rid);
                boolean followMode = r != null && r.followOn;
                if (saveBtn != null) saveBtn.setText("保存坐标");
                if (hintView != null) hintView.setText(followMode
                        ? "续点模式：拖准心到要点的位置，点「保存坐标」"
                        : "拖动准心到目标位置，点「保存坐标」");
                int cx = sw / 2;
                int cy = sh / 2;
                if (!followMode && r != null && r.x >= 0 && r.y >= 0) {
                    cx = r.x;
                    cy = r.y;
                }
                if (!pickTarget) openCursorAt(cx, cy);
            }
        }
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        alive = false;
        SkipService.setRecordingMode(false);
        setRecentsVisible(!RuleStore.get(this).hideRecents());
        try {
            uiHandler.removeCallbacksAndMessages(null);
        } catch (Exception ignored) {
        }
        sRef = null;
        try {
            if (exitChip != null) wm.removeView(exitChip);
        } catch (Exception ignored) {
        }
        try {
            if (layer != null) wm.removeView(layer);
        } catch (Exception ignored) {
        }
        try {
            if (cursor != null) wm.removeView(cursor);
        } catch (Exception ignored) {
        }
        try {
            if (panel != null) wm.removeView(panel);
        } catch (Exception ignored) {
        }
        layer = null;
        exitChip = null;
        cursor = null;
        panel = null;
        super.onDestroy();
    }

    private void applyTouchable(boolean touchable) {
        int flag = WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;
        if (panel != null && panelLp != null) {
            panelLp.flags = touchable ? (panelLp.flags & ~flag) : (panelLp.flags | flag);
            try {
                wm.updateViewLayout(panel, panelLp);
            } catch (Exception ignored) {
            }
        }
        if (cursor != null && cursorLp != null) {
            cursorLp.flags = touchable ? (cursorLp.flags & ~flag) : (cursorLp.flags | flag);
            try {
                wm.updateViewLayout(cursor, cursorLp);
            } catch (Exception ignored) {
            }
        }
    }

    private void startAsForeground() {
        String ch = "qingtiao_overlay";
        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= 26 && nm != null) {
            NotificationChannel c = new NotificationChannel(ch, "悬浮窗工具", NotificationManager.IMPORTANCE_LOW);
            c.setShowBadge(false);
            nm.createNotificationChannel(c);
        }
        Intent i = new Intent(this, MainActivity.class);
        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= 23) flags |= PendingIntent.FLAG_IMMUTABLE;
        PendingIntent pi = PendingIntent.getActivity(this, 0, i, flags);
        Notification.Builder b;
        if (Build.VERSION.SDK_INT >= 26) {
            b = new Notification.Builder(this, ch);
        } else {
            b = new Notification.Builder(this);
        }
        b.setContentTitle("轻跳 · 拾取工具运行中")
                .setContentText("点悬浮球可检视控件、拾取坐标")
                .setSmallIcon(android.R.drawable.ic_menu_edit)
                .setOngoing(true)
                .setContentIntent(pi);
        startForeground(1001, b.build());
    }

    private void computeSize() {
        try {
            DisplayMetrics dm = new DisplayMetrics();
            wm.getDefaultDisplay().getRealMetrics(dm);
            if (dm.widthPixels > 0) {
                sw = dm.widthPixels;
                sh = dm.heightPixels;
            }
        } catch (Exception ignored) {
        }
    }

    private int overlayType() {
        if (Build.VERSION.SDK_INT >= 26) return WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY;
        return WindowManager.LayoutParams.TYPE_PHONE;
    }

    private int dp(float v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }

    private GradientDrawable box(int stroke, int fill) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(fill);
        d.setCornerRadius(dp(6));
        d.setStroke(dp(1.6f), stroke);
        return d;
    }

    private void addPanel() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(12), dp(9), dp(12), dp(11));

        LinearLayout titleRow = new LinearLayout(this);
        titleRow.setOrientation(LinearLayout.HORIZONTAL);
        titleRow.setGravity(Gravity.CENTER_VERTICAL);
        TextView t = new TextView(this);
        t.setText("轻跳");
        t.setTextColor(0xFFFFFFFF);
        t.setTextSize(13f);
        t.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        titleLabel = t;
        titleRow.addView(t);
        View flex = new View(this);
        titleRow.addView(flex, new LinearLayout.LayoutParams(0, 1, 1f));
        TextView close = new TextView(this);
        close.setText("×");
        close.setTextColor(0xFFB9BECC);
        close.setTextSize(16f);
        close.setPadding(dp(8), 0, dp(2), dp(2));
        close.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                stopSelf();
            }
        });
        titleRow.addView(close);
        box.addView(titleRow, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        wcStatus = new TextView(this);
        wcStatus.setTextSize(10f);
        wcStatus.setTextColor(0xFFFF6B6B);
        wcStatus.setPadding(0, dp(2), 0, dp(4));
        wcStatus.setVisibility(View.GONE);
        box.addView(wcStatus);

        box.addView(action("① 检视控件", new View.OnClickListener() {
            public void onClick(View v) {
                startInspect();
            }
        }));
        box.addView(action("② 准心坐标", new View.OnClickListener() {
            public void onClick(View v) {
                toggleCursor();
            }
        }));

        CheckBox padCheck = new CheckBox(this);
        padCheck.setText("补齐状态栏");
        padCheck.setTextSize(11f);
        padCheck.setTextColor(0xFFDDE3FF);
        padCheck.setChecked(RuleStore.get(this).padStatusBar());
        padCheck.setPadding(0, dp(3), 0, dp(1));
        try {
            padCheck.setButtonTintList(ColorStateList.valueOf(0xFF4C6FFF));
        } catch (Exception ignored) {
        }
        padCheck.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton b, boolean checked) {
                RuleStore.get(OverlayService.this).setPadStatusBar(checked);
                refreshInspectLayer();
                toast(checked ? "已补齐状态栏高度" : "不补齐状态栏");
            }
        });
        box.addView(padCheck);

        dynamicCheck = new CheckBox(this);
        dynamicCheck.setText("动态坐标");
        dynamicCheck.setTextSize(11f);
        dynamicCheck.setTextColor(0xFFDDE3FF);
        dynamicCheck.setChecked(false);
        dynamicCheck.setPadding(0, dp(1), 0, dp(3));
        if (Build.VERSION.SDK_INT >= 21) {
            dynamicCheck.setButtonTintList(ColorStateList.valueOf(0xFF4C6FFF));
        }
        box.addView(dynamicCheck);

        LinearLayout cornerRow = new LinearLayout(this);
        cornerRow.setOrientation(LinearLayout.HORIZONTAL);
        final String[] cornerNames = {"左上", "右上", "左下", "右下"};
        for (int ci = 0; ci < 4; ci++) {
            CheckBox cb = new CheckBox(this);
            cb.setText(cornerNames[ci]);
            cb.setTextSize(10.5f);
            cb.setTextColor(0xFFDDE3FF);
            cb.setChecked(ci == 0);
            cb.setPadding(0, dp(1), dp(4), dp(2));
            if (Build.VERSION.SDK_INT >= 21) {
                cb.setButtonTintList(ColorStateList.valueOf(0xFF4C6FFF));
            }
            final int idx = ci;
            cb.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                public void onCheckedChanged(CompoundButton b, boolean checked) {
                    if (checked) {
                        cornerSel = idx;
                        for (int k = 0; k < cornerBoxes.length; k++) {
                            if (k != idx && cornerBoxes[k] != null && cornerBoxes[k].isChecked()) {
                                cornerBoxes[k].setChecked(false);
                            }
                        }
                    } else if (cornerSel == idx) {
                        b.setChecked(true);
                    }
                }
            });
            cornerBoxes[ci] = cb;
            cornerRow.addView(cb, new LinearLayout.LayoutParams(0,
                    LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        }
        box.addView(cornerRow);
        saveBtn = actionPrimary("保存规则", new View.OnClickListener() {
            public void onClick(View v) {
                onSave();
            }
        });
        box.addView(saveBtn);

        inputBox = new LinearLayout(this);
        inputBox.setOrientation(LinearLayout.VERTICAL);
        inputBox.setVisibility(View.GONE);

        seqInput = new EditText(this);
        seqInput.setHint("序号，如 3,7");
        seqInput.setTextSize(12f);
        seqInput.setTextColor(0xFFFFFFFF);
        seqInput.setHintTextColor(0xFF8B90A0);
        seqInput.setSingleLine(true);
        seqInput.setInputType(InputType.TYPE_CLASS_TEXT);
        GradientDrawable ibg = new GradientDrawable();
        ibg.setColor(0x33FFFFFF);
        ibg.setCornerRadius(dp(9));
        seqInput.setBackground(ibg);
        seqInput.setPadding(dp(9), dp(7), dp(9), dp(7));
        inputBox.addView(seqInput, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        targetInput = new EditText(this);
        targetInput.setHint("目标控件序号，如 5（留空则按坐标）");
        targetInput.setTextSize(12f);
        targetInput.setTextColor(0xFFFFFFFF);
        targetInput.setHintTextColor(0xFF8B90A0);
        targetInput.setSingleLine(true);
        targetInput.setInputType(InputType.TYPE_CLASS_TEXT);
        GradientDrawable tbg = new GradientDrawable();
        tbg.setColor(0x33FFFFFF);
        tbg.setCornerRadius(dp(9));
        targetInput.setBackground(tbg);
        targetInput.setPadding(dp(9), dp(7), dp(9), dp(7));
        LinearLayout.LayoutParams tlp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        tlp.topMargin = dp(6);
        inputBox.addView(targetInput, tlp);

        LinearLayout btnRow = new LinearLayout(this);
        btnRow.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams brp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        brp.topMargin = dp(6);
        TextView cancel = action("取消", new View.OnClickListener() {
            public void onClick(View v) {
                hideInput();
            }
        });
        LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        clp.rightMargin = dp(6);
        cancel.setLayoutParams(clp);
        TextView ok = actionPrimary("确定", new View.OnClickListener() {
            public void onClick(View v) {
                confirmInput();
            }
        });
        ok.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        btnRow.addView(cancel);
        btnRow.addView(ok);
        inputBox.addView(btnRow, brp);

        LinearLayout.LayoutParams ilp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        ilp.topMargin = dp(6);
        box.addView(inputBox, ilp);

        hintView = new TextView(this);
        hintView.setText("检视 → 准心定位 → 保存规则");
        hintView.setTextColor(0xFF9AA0B0);
        hintView.setTextSize(10f);
        hintView.setPadding(0, dp(6), 0, 0);
        hintView.setMaxWidth(dp(200));
        box.addView(hintView);

        panel = new FrameLayout(this);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(0xF21B1F2A);
        bg.setCornerRadius(dp(16));
        panel.setBackground(bg);
        panel.setElevation(dp(8));
        panelBox = box;
        panel.addView(box, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT));

        miniBtn = new TextView(this);
        miniBtn.setText("轻");
        miniBtn.setTextSize(14f);
        miniBtn.setTextColor(0xFFFFFFFF);
        miniBtn.setGravity(Gravity.CENTER);
        GradientDrawable mbg = new GradientDrawable();
        mbg.setShape(GradientDrawable.OVAL);
        mbg.setColor(0xF21B1F2A);
        miniBtn.setBackground(mbg);
        miniBtn.setVisibility(View.GONE);
        miniBtn.setOnTouchListener(new View.OnTouchListener() {
            public boolean onTouch(View v, MotionEvent e) {
                if (panelLp == null) return false;
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        downRawX = e.getRawX();
                        downRawY = e.getRawY();
                        downX = panelLp.x;
                        downY = panelLp.y;
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        panelLp.x = (int) (downX + (e.getRawX() - downRawX));
                        panelLp.y = (int) (downY + (e.getRawY() - downRawY));
                        try {
                            wm.updateViewLayout(panel, panelLp);
                        } catch (Exception ignored) {
                        }
                        return true;
                    case MotionEvent.ACTION_UP:
                        float dx = Math.abs(e.getRawX() - downRawX);
                        float dy = Math.abs(e.getRawY() - downRawY);
                        if (dx < dp(6) && dy < dp(6)) {
                            expandPanel();
                            return true;
                        }
                        // 松手吸附最近的左右边
                        int mid = sw / 2;
                        panelLp.x = (panelLp.x + dp(22)) < mid ? 0 : Math.max(0, sw - dp(44));
                        if (panelLp.y < 0) panelLp.y = 0;
                        if (panelLp.y > sh - dp(44)) panelLp.y = Math.max(0, sh - dp(44));
                        try {
                            wm.updateViewLayout(panel, panelLp);
                        } catch (Exception ignored) {
                        }
                        return true;
                }
                return false;
            }
        });
        FrameLayout.LayoutParams mlp = new FrameLayout.LayoutParams(dp(44), dp(44));
        mlp.gravity = Gravity.CENTER;
        panel.addView(miniBtn, mlp);

        panelLp = new WindowManager.LayoutParams(
                dp(228),
                WindowManager.LayoutParams.WRAP_CONTENT,
                overlayType(),
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        panelLp.gravity = Gravity.TOP | Gravity.START;
        panelLp.x = dp(10);
        panelLp.y = dp(120);

        titleRow.setOnTouchListener(new View.OnTouchListener() {
            public boolean onTouch(View v, MotionEvent e) {
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        downRawX = e.getRawX();
                        downRawY = e.getRawY();
                        downX = panelLp.x;
                        downY = panelLp.y;
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        panelLp.x = (int) (downX + (e.getRawX() - downRawX));
                        panelLp.y = (int) (downY + (e.getRawY() - downRawY));
                        try {
                            wm.updateViewLayout(panel, panelLp);
                        } catch (Exception ignored) {
                        }
                        return true;
                    case MotionEvent.ACTION_UP:
                        float pdx = Math.abs(e.getRawX() - downRawX);
                        float pdy = Math.abs(e.getRawY() - downRawY);
                        if (pdx < dp(6) && pdy < dp(6)
                                && RuleStore.get(OverlayService.this).edgeSnap()
                                && hitTitle(e.getRawX(), e.getRawY())) {
                            collapsePanel();
                        }
                        return true;
                }
                return false;
            }
        });

        wm.addView(panel, panelLp);
    }

    private TextView actionPrimary(String text, View.OnClickListener l) {
        TextView v = new TextView(this);
        v.setText(text);
        v.setTextSize(12f);
        v.setTextColor(0xFFFFFFFF);
        v.setGravity(Gravity.CENTER);
        GradientDrawable d = new GradientDrawable();
        d.setColor(0xFF4C6FFF);
        d.setCornerRadius(dp(9));
        v.setBackground(d);
        v.setPadding(dp(8), dp(7), dp(8), dp(7));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.topMargin = dp(6);
        v.setLayoutParams(lp);
        v.setOnClickListener(l);
        return v;
    }

    private TextView action(String text, View.OnClickListener l) {
        TextView v = new TextView(this);
        v.setText(text);
        v.setTextSize(12f);
        v.setTextColor(0xFFDDE3FF);
        v.setGravity(Gravity.CENTER);
        GradientDrawable d = new GradientDrawable();
        d.setColor(0x33FFFFFF);
        d.setCornerRadius(dp(9));
        v.setBackground(d);
        v.setPadding(dp(8), dp(7), dp(8), dp(7));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.topMargin = dp(6);
        v.setLayoutParams(lp);
        v.setOnClickListener(l);
        return v;
    }

    // ---------------- 检视控件 ----------------

    private static class Box {
        String cond;
        Rect rect;
        int index;
    }

    private void startInspect() {
        SkipService svc = SkipService.get();
        if (svc == null) {
            toast("无障碍未连接，请到系统设置 → 无障碍 → 轻跳 重新开启");
            return;
        }
        if (layer != null) {
            removeLayer();
            return;
        }
        AccessibilityNodeInfo root = svc.root();
        if (root == null) {
            toast("读不到当前界面，请切到目标应用后再试");
            return;
        }
        String fg = svc.activeAppPkg();
        if (fg != null && fg.length() > 0 && !getPackageName().equals(fg)) {
            inspectPkg = fg;
        }
        List<Box> boxes = new ArrayList<Box>();
        Set<String> seen = new HashSet<String>();
        collect(root, boxes, seen, 0);
        lastBoxes = boxes;
        lastTotalNodes = countNodes(root, 0);
        if (boxes.isEmpty()) {
            toast("当前界面没有可拾取的控件");
            return;
        }
        buildLayer(boxes);
        if (hintView != null) {
            String nm = appLabel(inspectPkg);
            hintView.setText(nm == null ? "点蓝色框拾取控件 ID"
                    : "点蓝色框拾取 · " + nm);
        }
    }

    private int countNodes(AccessibilityNodeInfo node, int depth) {
        if (node == null || depth > 30) return 0;
        int n = 1;
        int c = 0;
        try {
            c = Math.min(node.getChildCount(), 60);
        } catch (Exception ignored) {
        }
        for (int i = 0; i < c; i++) {
            AccessibilityNodeInfo ch = null;
            try {
                ch = node.getChild(i);
            } catch (Exception ignored) {
            }
            if (ch != null) n += countNodes(ch, depth + 1);
        }
        return n;
    }

    private void collect(AccessibilityNodeInfo node, List<Box> out, Set<String> seen, int depth) {
        if (node == null || depth > 26 || out.size() >= 40) return;
        try {
            CharSequence npk = node.getPackageName();
            if (npk != null && getPackageName().contentEquals(npk)) return;
        } catch (Exception ignored) {
        }
        try {
            if (node.isVisibleToUser()) {
                Rect r = new Rect();
                node.getBoundsInScreen(r);
                boolean big = r.width() >= sw - dp(4) && r.height() >= sh - dp(4);
                if (!big && r.width() >= dp(6) && r.height() >= dp(6) && r.right > 0 && r.bottom > 0) {
                    String vid = node.getViewIdResourceName();
                    CharSequence txt = node.getText();
                    CharSequence desc = node.getContentDescription();
                    String cond = null;
                    if (vid != null && vid.length() > 0) {
                        cond = vid;
                    } else if (txt != null && txt.length() > 0 && txt.length() <= 24) {
                        cond = "text:" + txt.toString();
                    } else if (desc != null && desc.length() > 0 && desc.length() <= 24) {
                        cond = "desc:" + desc.toString();
                    }
                    if (cond != null) {
                        String key = cond + "@" + r.left + "," + r.top;
                        if (!seen.contains(key)) {
                            seen.add(key);
                            Box b = new Box();
                            b.cond = cond;
                            b.rect = r;
                            b.index = out.size() + 1;
                            out.add(b);
                        }
                    }
                }
            }
        } catch (Exception ignored) {
        }
        int n = 0;
        try {
            n = Math.min(node.getChildCount(), 40);
        } catch (Exception ignored) {
        }
        for (int i = 0; i < n; i++) {
            AccessibilityNodeInfo c = null;
            try {
                c = node.getChild(i);
            } catch (Exception ignored) {
            }
            collect(c, out, seen, depth + 1);
        }
    }

    private void buildLayer(List<Box> boxes) {
        layer = new FrameLayout(this);
        layer.setBackgroundColor(0x00000000);
        layer.setClipChildren(false);
        for (int i = 0; i < boxes.size(); i++) {
            final Box b = boxes.get(i);
            FrameLayout cell = new FrameLayout(this);
            cell.setBackground(outline(0xFF4C6FFF));
            FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(b.rect.width(), b.rect.height());
            lp.leftMargin = b.rect.left - effOffX();
            lp.topMargin = b.rect.top - effOffY();
            cell.setLayoutParams(lp);

            TextView num = new TextView(this);
            num.setText(String.valueOf(b.index));
            num.setTextSize(7.5f);
            num.setTextColor(0xFFFFFFFF);
            num.setGravity(Gravity.CENTER);
            GradientDrawable nb = new GradientDrawable();
            nb.setColor(0xCC4C6FFF);
            nb.setCornerRadius(dp(9));
            num.setBackground(nb);
            FrameLayout.LayoutParams nlp = new FrameLayout.LayoutParams(dp(13), dp(13));
            nlp.leftMargin = dp(1);
            nlp.topMargin = dp(1);
            cell.addView(num, nlp);

            cell.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    pickBox(b, v);
                }
            });
            layer.addView(cell);
        }

        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                overlayType(),
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        layerLp = lp;
        try {
            wm.addView(layer, lp);
        } catch (Exception e) {
            layer = null;
            toast("悬浮层添加失败：" + e.getClass().getSimpleName());
            return;
        }
        // 面板保持可见并置于标注层之上
        try {
            wm.removeView(panel);
            wm.addView(panel, panelLp);
        } catch (Exception ignored) {
        }
        if (hintView != null) hintView.setText("标注 " + boxes.size() + " 个 · 页面共 " + lastTotalNodes + " 个节点");
    }

    private void refreshInspectLayer() {
        if (layer == null) return;
        SkipService svc = SkipService.get();
        if (svc == null) return;
        AccessibilityNodeInfo root = svc.root();
        if (root == null) return;
        List<Box> boxes = new ArrayList<Box>();
        Set<String> seen = new HashSet<String>();
        collect(root, boxes, seen, 0);
        try {
            wm.removeView(layer);
        } catch (Exception ignored) {
        }
        layer = null;
        buildLayer(boxes);
    }

    private GradientDrawable outline(int stroke) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(0x00000000);
        d.setCornerRadius(dp(4));
        d.setStroke(dp(1.6f), stroke);
        return d;
    }

    private GradientDrawable outlineFill(int stroke, int fill) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(fill);
        d.setCornerRadius(dp(4));
        d.setStroke(dp(1.6f), stroke);
        return d;
    }

    private void addExitChip() {
        if (exitChip != null) return;
        TextView chip = new TextView(this);
        chip.setText("退出检视");
        chip.setTextSize(11f);
        chip.setTextColor(0xFFFFFFFF);
        chip.setGravity(Gravity.CENTER);
        GradientDrawable d = new GradientDrawable();
        d.setColor(0xE61B1F2A);
        d.setCornerRadius(dp(16));
        chip.setBackground(d);
        chip.setPadding(dp(12), dp(7), dp(12), dp(7));
        chip.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                removeLayer();
            }
        });
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                overlayType(),
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.END;
        lp.x = dp(8);
        lp.y = dp(36);
        exitChip = chip;
        try {
            wm.addView(exitChip, lp);
        } catch (Exception e) {
            exitChip = null;
        }
    }

    private void removeLayer() {
        if (exitChip != null) {
            try {
                wm.removeView(exitChip);
            } catch (Exception ignored) {
            }
            exitChip = null;
        }
        if (layer != null) {
            try {
                wm.removeView(layer);
            } catch (Exception ignored) {
            }
            layer = null;
        }
        try {
            if (panel != null && panel.getParent() == null) {
                wm.addView(panel, panelLp);
            }
        } catch (Exception ignored) {
        }
        if (hintView != null) hintView.setText("可继续拾取，或回 App 编辑规则");
    }

    private void pickBox(Box b, View v) {
        String draftId = ensureDraft();
        if (draftId == null) {
            toast("先切到目标应用，再点「① 检视控件」");
            return;
        }
        RuleStore.get(this).addDraftCondition(draftId, b.cond);
        v.setBackground(outlineFill(0xFF17B26A, 0x1A17B26A));
        String show = b.cond.length() > 34 ? b.cond.substring(0, 34) + "…" : b.cond;
        toast("已拾取：" + show);
        if (hintView != null) {
            hintView.setText("已拾取 " + RuleStore.get(this).draftConditions(draftId).size() + " 个条件");
        }
    }

    // ---------------- 准心坐标 ----------------

    private void toggleCursor() {
        if (cursor != null) {
            removeCursor();
            if (hintView != null) hintView.setText("准心已关闭");
            return;
        }
        if (targetRuleId == null && ensureDraft() == null) {
            toast("先切到目标应用，再点「① 检视控件」");
            return;
        }
        int cx = sw / 2;
        int cy = sh / 2;
        if (targetRuleId != null) {
            Rule r = RuleStore.get(this).find(targetRuleId);
            if (r != null && r.x >= 0 && r.y >= 0) {
                cx = r.x;
                cy = r.y;
            }
        }
        openCursorAt(cx, cy);
    }

    private void openCursorAt(int cx, int cy) {
        removeCursor();
        int size = dp(104);
        cursorSize = size;
        CursorView cv = new CursorView(this);
        cursorLp = new WindowManager.LayoutParams(size, size, overlayType(),
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        cursorLp.gravity = Gravity.TOP | Gravity.START;
        cursorLp.x = cx - size / 2;
        cursorLp.y = cy - size / 2;
        cursor = cv;
        cv.setOnTouchListener(this);
        try {
            wm.addView(cursor, cursorLp);
        } catch (Exception e) {
            cursor = null;
            toast("准心添加失败");
            return;
        }
        if (hintView != null) hintView.setText("拖准心到目标位置，点「保存坐标」");
    }

    private void removeCursor() {
        if (cursor != null) {
            try {
                wm.removeView(cursor);
            } catch (Exception ignored) {
            }
            cursor = null;
            cursorLp = null;
        }
    }

    private void recordPoint() {
        if (cursor == null || cursorLp == null) {
            toast("请先开启准心");
            return;
        }
        String draftId = ensureDraft();
        if (draftId == null) {
            toast("先切到目标应用，再点「① 检视控件」");
            return;
        }
        int cx = cursorLp.x + cursorSize / 2 + effOffX();
        int cy = cursorLp.y + cursorSize / 2 + effOffY();
        if (cx < 0) cx = 0;
        if (cy < 0) cy = 0;
        RuleStore store = RuleStore.get(this);
        Rule dr = store.find(draftId);
        if (dr != null && dr.followOn) {
            store.addFollowPoint(draftId, cx, cy, 500);
            Rule now = store.find(draftId);
            int n = now == null ? 1 : now.followPts.size();
            toast("已加续点 " + n + " (" + cx + ", " + cy + ")");
            if (hintView != null) hintView.setText("续点 " + n + " (" + cx + ", " + cy + ") 已加");
            return;
        }
        store.setDraftPoint(draftId, cx, cy, sw, sh);
        toast("已记录坐标 (" + cx + ", " + cy + ")");
        if (hintView != null) hintView.setText("坐标 (" + cx + ", " + cy + ") 已记录");
    }

    private void snapCursor() {
        if (cursorLp == null || cursor == null) return;
        if (!RuleStore.get(this).edgeSnap()) return;
        int margin = dp(18);
        int maxX = Math.max(0, sw - cursorSize);
        int maxY = Math.max(0, sh - cursorSize);
        if (cursorLp.x < margin) cursorLp.x = 0;
        else if (cursorLp.x > maxX - margin) cursorLp.x = maxX;
        if (cursorLp.y < margin) cursorLp.y = 0;
        else if (cursorLp.y > maxY - margin) cursorLp.y = maxY;
        try {
            wm.updateViewLayout(cursor, cursorLp);
        } catch (Exception ignored) {
        }
    }

    private boolean hitTitle(float rawX, float rawY) {
        if (titleLabel == null) return false;
        int[] loc = new int[2];
        try {
            titleLabel.getLocationOnScreen(loc);
        } catch (Exception ignored) {
            return false;
        }
        return rawX >= loc[0] - dp(6) && rawX <= loc[0] + titleLabel.getWidth() + dp(6)
                && rawY >= loc[1] - dp(6) && rawY <= loc[1] + titleLabel.getHeight() + dp(6);
    }

    private void snapPanel() {
        if (panelLp == null || panel == null) return;
        if (!RuleStore.get(this).edgeSnap()) return;
        int margin = dp(24);
        int w = panel.getWidth();
        if (w <= 0) w = dp(228);
        boolean nearLeft = panelLp.x < margin;
        boolean nearRight = panelLp.x + w > sw - margin;
        if ((nearLeft || nearRight) && cursor == null && layer == null) {
            collapsePanel();
            return;
        }
        // 没到边框：只保证不出屏
        int maxX = Math.max(0, sw - w);
        if (panelLp.x < 0) panelLp.x = 0;
        if (panelLp.x > maxX) panelLp.x = maxX;
        if (panelLp.y < 0) panelLp.y = 0;
        if (panelLp.y > sh - dp(60)) panelLp.y = Math.max(0, sh - dp(60));
        try {
            wm.updateViewLayout(panel, panelLp);
        } catch (Exception ignored) {
        }
    }

    private void collapsePanel() {
        if (collapsed || panelBox == null) return;
        collapsed = true;
        panelBox.setVisibility(View.GONE);
        if (miniBtn != null) miniBtn.setVisibility(View.VISIBLE);
        panelLp.width = dp(44);
        panelLp.height = dp(44);
        int size = dp(44);
        // 吸附到最近的左右边框，不居中
        int mid = sw / 2;
        if (panelLp.x + size / 2 < mid) panelLp.x = 0;
        else panelLp.x = Math.max(0, sw - size);
        if (panelLp.y < 0) panelLp.y = 0;
        if (panelLp.y > sh - size) panelLp.y = Math.max(0, sh - size);
        try {
            wm.updateViewLayout(panel, panelLp);
        } catch (Exception ignored) {
        }
    }

    private void expandPanel() {
        if (!collapsed) return;
        collapsed = false;
        if (miniBtn != null) miniBtn.setVisibility(View.GONE);
        if (panelBox != null) panelBox.setVisibility(View.VISIBLE);
        panelLp.width = dp(228);
        panelLp.height = WindowManager.LayoutParams.WRAP_CONTENT;
        // 展开时窗口居中
        panelLp.x = Math.max(0, (sw - dp(228)) / 2);
        panelLp.y = Math.max(0, sh / 6);
        try {
            wm.updateViewLayout(panel, panelLp);
        } catch (Exception ignored) {
        }
    }

    @Override
    public boolean onTouch(View v, MotionEvent e) {
        if (cursorLp == null) return false;
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                downRawX = e.getRawX();
                downRawY = e.getRawY();
                downX = cursorLp.x;
                downY = cursorLp.y;
                return true;
            case MotionEvent.ACTION_MOVE:
                cursorLp.x = (int) (downX + (e.getRawX() - downRawX));
                cursorLp.y = (int) (downY + (e.getRawY() - downRawY));
                try {
                    wm.updateViewLayout(cursor, cursorLp);
                } catch (Exception ignored) {
                }
                return true;
            case MotionEvent.ACTION_UP:
                snapCursor();
                return true;
        }
        return false;
    }

    // ---------------- 保存规则（坐标 + 序号条件） ----------------

    private void saveRulePoint() {
        if (cursor == null || cursorLp == null) {
            toast("请先点「② 准心坐标」显示准心");
            return;
        }
        Rule r = RuleStore.get(this).find(targetRuleId);
        if (r == null) {
            toast("规则不存在，可能已被删除");
            targetRuleId = null;
            return;
        }
        int cx = cursorLp.x + cursorSize / 2 + effOffX();
        int cy = cursorLp.y + cursorSize / 2 + effOffY();
        if (cx < 0) cx = 0;
        if (cy < 0) cy = 0;
        RuleStore store = RuleStore.get(this);
        if (followPick) {
            store.addFollowPoint(targetRuleId, cx, cy, 500);
            Rule now = store.find(targetRuleId);
            int n = now == null ? 1 : now.followPts.size();
            toast("已加续点 " + n + " (" + cx + ", " + cy + ")");
            if (hintView != null) hintView.setText("续点 " + n + " 已加，拖动准心可继续加");
            return;
        }
        r.x = cx;
        r.y = cy;
        r.screenW = sw;
        r.screenH = sh;
        store.save(r);
        toast("坐标已更新为 (" + cx + ", " + cy + ")");
        removeCursor();
        targetRuleId = null;
        if (saveBtn != null) saveBtn.setText("保存规则");
        if (hintView != null) hintView.setText("坐标已保存，可关闭悬浮球");
    }

    private void onSave() {
        if (pickTarget) {
            if (lastBoxes == null || lastBoxes.isEmpty()) {
                toast("请先点「① 检视控件」，界面上会标序号");
                return;
            }
            showInput();
            return;
        }
        if (targetRuleId != null) {
            saveRulePoint();
            return;
        }
        RuleStore store = RuleStore.get(this);
        String draftId = store.activeDraft();
        if (draftId != null && store.find(draftId) == null) draftId = null;
        if (draftId == null) {
            String pkg = inspectPkg;
            String label = appLabel(pkg);
            if (label == null) {
                SkipService svc = SkipService.get();
                if (svc != null) pkg = svc.activeAppPkg();
                label = appLabel(pkg);
            }
            if (pkg == null || label == null) {
                toast("识别不到目标应用，请切到目标应用再点「① 检视控件」");
                return;
            }
            Rule r = new Rule();
            r.pkg = pkg;
            r.appLabel = label;
            r.name = "规则 " + (store.countFor(pkg) + 1);
            r.mode = store.recordMode();
            r.draft = true;
            store.save(r);
            store.setActiveDraft(r.id);
            draftId = r.id;
            toast("识别为：" + label);
        }
        if (lastBoxes == null || lastBoxes.isEmpty()) {
            toast("请先点「① 检视控件」标注界面控件");
            return;
        }
        if (cursor == null) {
            toast("请先点「② 准心坐标」，把准心拖到跳过按钮上");
            return;
        }
        showInput();
    }

    private void showInput() {
        if (inputBox == null || panelLp == null) return;
        inputBox.setVisibility(View.VISIBLE);
        if (hintView != null) hintView.setText(pickTarget
                ? "输入要点击的控件序号" : "填控件序号，多个用逗号分隔");
        panelLp.flags = WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
                | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN;
        try {
            wm.updateViewLayout(panel, panelLp);
        } catch (Exception ignored) {
        }
        if (seqInput != null) {
            seqInput.requestFocus();
            try {
                InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                if (imm != null) imm.showSoftInput(seqInput, InputMethodManager.SHOW_IMPLICIT);
            } catch (Exception ignored) {
            }
        }
    }

    private void hideInput() {
        if (inputBox == null) return;
        inputBox.setVisibility(View.GONE);
        try {
            InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            if (imm != null && seqInput != null) {
                imm.hideSoftInputFromWindow(seqInput.getWindowToken(), 0);
            }
        } catch (Exception ignored) {
        }
        if (panelLp != null) {
            panelLp.flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                    | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                    | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
                    | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN;
            try {
                wm.updateViewLayout(panel, panelLp);
            } catch (Exception ignored) {
            }
        }
        if (hintView != null) hintView.setText("检视 → 准心定位 → 保存规则");
    }

    private void confirmInput() {
        String draftId = ensureDraft();
        if (draftId == null) {
            toast("先切到目标应用，再点「① 检视控件」");
            return;
        }
        String raw = seqInput == null ? "" : seqInput.getText().toString().trim();
        if (raw.length() == 0) {
            toast("请填写控件序号");
            return;
        }
        String targetRaw = targetInput == null ? "" : targetInput.getText().toString().trim();
        List<Integer> idxList = parseSeq(raw);
        List<String> picked = new ArrayList<String>();
        Rect anchorRect = null;
        for (int k = 0; k < idxList.size(); k++) {
            int idx = idxList.get(k).intValue();
            for (int i = 0; i < lastBoxes.size(); i++) {
                Box b = lastBoxes.get(i);
                if (b.index == idx && !picked.contains(b.cond)) {
                    picked.add(b.cond);
                    if (anchorRect == null) anchorRect = b.rect;
                    break;
                }
            }
        }
        if (picked.isEmpty()) {
            toast("序号 " + raw + " 没有对应控件");
            return;
        }
        // 目标控件：填了就是点控件模式
        List<String> targets = new ArrayList<String>();
        if (targetRaw.length() > 0) {
            List<Integer> tIdx = parseSeq(targetRaw);
            for (int k = 0; k < tIdx.size(); k++) {
                int idx = tIdx.get(k).intValue();
                for (int i = 0; i < lastBoxes.size(); i++) {
                    Box b = lastBoxes.get(i);
                    if (b.index == idx && !targets.contains(b.cond)) {
                        targets.add(b.cond);
                        break;
                    }
                }
            }
            if (targets.isEmpty()) {
                toast("目标控件序号 " + targetRaw + " 没有对应控件");
                return;
            }
        }
        boolean dynamic = dynamicCheck != null && dynamicCheck.isChecked();

        int cx = 0;
        int cy = 0;
        if (cursor != null && cursorLp != null) {
            cx = cursorLp.x + cursorSize / 2 + effOffX();
            cy = cursorLp.y + cursorSize / 2 + effOffY();
        }
        if (cx < 0) cx = 0;
        if (cy < 0) cy = 0;

        RuleStore store = RuleStore.get(this);
        Rule target = store.find(draftId);
        if (target == null) {
            toast("规则不存在，请重新检视");
            return;
        }
        store.clearDraftConditions(draftId);
        for (int i = 0; i < picked.size(); i++) {
            store.addDraftCondition(draftId, picked.get(i));
        }
        target.conditions = new ArrayList<String>(picked);

        if (!targets.isEmpty()) {
            target.mode = Rule.MODE_WIDGET;
            target.targetIds = targets;
            target.x = -1;
            target.y = -1;
            toast("点控件模式：" + targets.size() + " 个目标");
        } else if (dynamic) {
            if (cursor == null || anchorRect == null) {
                toast("动态坐标需要开准心定位点击位置");
                return;
            }
            target.mode = Rule.MODE_ANCHOR;
            target.corner = cornerSel;
            target.anchorW = anchorRect.width();
            target.anchorH = anchorRect.height();
            int ax = anchorRect.left;
            int ay = anchorRect.top;
            if (cornerSel == 1) {
                ax = anchorRect.right;
                ay = anchorRect.top;
            } else if (cornerSel == 2) {
                ax = anchorRect.left;
                ay = anchorRect.bottom;
            } else if (cornerSel == 3) {
                ax = anchorRect.right;
                ay = anchorRect.bottom;
            }
            target.relX = cx - ax;
            target.relY = cy - ay;
            target.x = cx;
            target.y = cy;
            target.screenW = sw;
            target.screenH = sh;
            store.setDraftPoint(draftId, cx, cy, sw, sh);
            toast("动态坐标：偏移 " + target.relX + "," + target.relY);
        } else {
            target.mode = Rule.MODE_POINT;
            target.x = cx;
            target.y = cy;
            target.screenW = sw;
            target.screenH = sh;
            store.setDraftPoint(draftId, cx, cy, sw, sh);
            toast("已记录坐标 (" + cx + ", " + cy + ")");
        }
        if (anchorRect != null) {
            store.setDraftAnchor(draftId, anchorRect.left, anchorRect.top,
                    anchorRect.right, anchorRect.bottom);
        }
        store.save(target);
        if (targetInput != null) targetInput.setText("");

        hideInput();
        removeLayer();
        if (target != null) {
            Intent it = new Intent(this, RuleEditActivity.class);
            it.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
            it.putExtra("ruleId", draftId);
            it.putExtra("pkg", target.pkg);
            it.putExtra("label", target.appLabel);
            try {
                startActivity(it);
            } catch (Exception e) {
                toast("打开配置页失败");
            }
            return;
        }
        closeAllWindows();
    }

    private void setRecentsVisible(boolean visible) {
        try {
            ActivityManager am = (ActivityManager) getSystemService(ACTIVITY_SERVICE);
            if (am == null) return;
            java.util.List<ActivityManager.AppTask> tasks = am.getAppTasks();
            if (tasks == null) return;
            for (int i = 0; i < tasks.size(); i++) {
                try {
                    tasks.get(i).setExcludeFromRecents(!visible);
                } catch (Exception ignored) {
                }
            }
        } catch (Exception ignored) {
        }
    }

    private void closeAllWindows() {
        try {
            if (layer != null) {
                wm.removeView(layer);
                layer = null;
            }
        } catch (Exception ignored) {
        }
        try {
            if (cursor != null) {
                wm.removeView(cursor);
                cursor = null;
            }
        } catch (Exception ignored) {
        }
        try {
            if (exitChip != null) {
                wm.removeView(exitChip);
                exitChip = null;
            }
        } catch (Exception ignored) {
        }
        try {
            if (panel != null) {
                wm.removeView(panel);
            }
        } catch (Exception ignored) {
        }
    }

    private void openConfigWithDetectedPkg(String draftId) {
        String pkg = null;
        SkipService svc = SkipService.get();
        if (svc != null) pkg = svc.activeAppPkg();
        if (pkg != null && getPackageName().equals(pkg)) pkg = null;
        String label = appLabel(pkg);
        RuleStore store = RuleStore.get(this);
        Rule r = store.find(draftId);
        if (r != null) {
            if (label != null && !pkg.equals(r.pkg)) {
                r.pkg = pkg;
                r.appLabel = label;
                r.name = "规则 " + (store.countFor(pkg) + 1);
                store.save(r);
            }
            Intent it = new Intent(this, RuleEditActivity.class);
            it.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
            it.putExtra("ruleId", draftId);
            it.putExtra("pkg", r.pkg);
            it.putExtra("label", r.appLabel);
            try {
                startActivity(it);
            } catch (Exception e) {
                toast("打开配置页失败，请回 App 点「保存规则」");
            }
        }
        stopSelf();
    }

    private String ensureDraft() {
        RuleStore store = RuleStore.get(this);
        String id = store.activeDraft();
        if (id != null && store.find(id) != null) return id;
        String pkg = inspectPkg;
        if (pkg == null || pkg.length() == 0) {
            SkipService svc = SkipService.get();
            if (svc != null) pkg = svc.activeAppPkg();
        }
        String label = appLabel(pkg);
        if (pkg == null || label == null) return null;
        Rule r = new Rule();
        r.pkg = pkg;
        r.appLabel = label;
        r.name = "规则 " + (store.countFor(pkg) + 1);
        r.mode = store.recordMode();
        r.draft = true;
        store.save(r);
        store.setActiveDraft(r.id);
        return r.id;
    }

    private String appLabel(String pkg) {
        if (pkg == null || pkg.length() == 0) return null;
        try {
            PackageManager pm = getPackageManager();
            return pm.getApplicationInfo(pkg, 0).loadLabel(pm).toString();
        } catch (Exception e) {
            return null;
        }
    }

    private List<Integer> parseSeq(String raw) {
        List<Integer> out = new ArrayList<Integer>();
        String s = raw.replace("，", ",").replace("、", ",").replace("；", ",")
                .replace(";", ",").replace(" ", ",");
        String[] parts = s.split(",");
        for (int i = 0; i < parts.length; i++) {
            String p = parts[i].trim();
            if (p.length() == 0) continue;
            int dash = p.indexOf('-');
            if (dash > 0) {
                try {
                    int a = Integer.parseInt(p.substring(0, dash).trim());
                    int b = Integer.parseInt(p.substring(dash + 1).trim());
                    if (a > b) {
                        int t = a;
                        a = b;
                        b = t;
                    }
                    for (int k = a; k <= b && k - a < 100; k++) out.add(Integer.valueOf(k));
                } catch (Exception ignored) {
                }
            } else {
                try {
                    out.add(Integer.valueOf(Integer.parseInt(p)));
                } catch (Exception ignored) {
                }
            }
        }
        return out;
    }

    // ---------------- 坐标校准 ----------------

    private int effOffX() {
        return 0;
    }

    private int effOffY() {
        return RuleStore.get(this).padStatusBar() ? statusBarHeight() : 0;
    }

    private int statusBarHeight() {
        int id = getResources().getIdentifier("status_bar_height", "dimen", "android");
        if (id > 0) {
            try {
                return getResources().getDimensionPixelSize(id);
            } catch (Exception ignored) {
            }
        }
        return (int) (24 * getResources().getDisplayMetrics().density);
    }

    private class CursorView extends View {
        private final Paint ring = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint cross = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint dot = new Paint(Paint.ANTI_ALIAS_FLAG);

        CursorView(Context c) {
            super(c);
            float d = c.getResources().getDisplayMetrics().density;
            ring.setStyle(Paint.Style.STROKE);
            ring.setStrokeWidth(2.5f * d);
            ring.setColor(0xFF4C6FFF);
            cross.setStrokeWidth(1.4f * d);
            cross.setColor(0xCC4C6FFF);
            dot.setColor(0xFFF04438);
        }

        @Override
        protected void onDraw(Canvas canvas) {
            float cx = getWidth() / 2f;
            float cy = getHeight() / 2f;
            float r = Math.min(cx, cy) - 8f;
            canvas.drawCircle(cx, cy, r, ring);
            canvas.drawLine(cx - r, cy, cx + r, cy, cross);
            canvas.drawLine(cx, cy - r, cx, cy + r, cross);
            canvas.drawCircle(cx, cy, 5f, dot);
        }
    }
}
