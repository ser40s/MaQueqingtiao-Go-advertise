package com.kuku.qingtiao;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class Rule {

    public static final int TYPE_FIRST_SCREEN = 0;
    public static final int TYPE_IN_APP = 1;

    /** 录制模式：默认（条件+固定坐标）/ 点控件 / 动态坐标 */
    public static final int MODE_POINT = 0;
    public static final int MODE_WIDGET = 1;
    public static final int MODE_ANCHOR = 2;

    public String id;
    public String pkg = "";
    public String appLabel = "";
    public String name = "";
    public int type = TYPE_FIRST_SCREEN;
    public List<String> conditions = new ArrayList<String>();
    public int x = -1;
    public int y = -1;
    public int screenW = 0;
    public int screenH = 0;
    public long cooldownMs = 1000L;
    public boolean enabled = true;
    public long hits = 0;
    /** 续点：主点击后按顺序追加点击的点 {x, y, delayMs} */
    public int mode = MODE_POINT;
    /** 点控件模式：要点击的控件 id，可多个 */
    public List<String> targetIds = new ArrayList<String>();
    /** 动态坐标模式：相对锚点左上角的偏移，以及录制时锚点尺寸 */
    public int relX = 0;
    public int relY = 0;
    /** 锚点取控件的哪个角：0 左上 1 右上 2 左下 3 右下 */
    public int corner = 0;
    public int anchorW = 0;
    public int anchorH = 0;
    public boolean draft = false;
    public boolean followOn = false;
    public List<int[]> followPts = new ArrayList<int[]>();

    public Rule() {
        id = UUID.randomUUID().toString();
    }

    public String typeName() {
        return type == TYPE_FIRST_SCREEN ? "首屏广告" : "应用内弹窗";
    }

    public JSONObject toJson() {
        JSONObject o = new JSONObject();
        try {
            o.put("id", id);
            o.put("pkg", pkg);
            o.put("appLabel", appLabel == null ? "" : appLabel);
            o.put("name", name == null ? "" : name);
            o.put("type", type);
            JSONArray a = new JSONArray();
            for (int i = 0; i < conditions.size(); i++) a.put(conditions.get(i));
            o.put("conditions", a);
            o.put("x", x);
            o.put("y", y);
            o.put("sw", screenW);
            o.put("sh", screenH);
            o.put("cd", cooldownMs);
            o.put("enabled", enabled);
            o.put("hits", hits);
            o.put("md", mode);
            JSONArray ti = new JSONArray();
            for (int i = 0; i < targetIds.size(); i++) ti.put(targetIds.get(i));
            o.put("tids", ti);
            o.put("rx", relX);
            o.put("ry", relY);
            o.put("cn", corner);
            o.put("aw", anchorW);
            o.put("ah", anchorH);
            o.put("dr", draft);
            o.put("fo", followOn);
            JSONArray fp = new JSONArray();
            for (int i = 0; i < followPts.size(); i++) {
                int[] p = followPts.get(i);
                JSONArray t = new JSONArray();
                t.put(p[0]);
                t.put(p[1]);
                t.put(p[2]);
                fp.put(t);
            }
            o.put("fp", fp);
        } catch (Exception ignored) {
        }
        return o;
    }

    public static Rule from(JSONObject o) {
        Rule r = new Rule();
        r.id = o.optString("id", r.id);
        r.pkg = o.optString("pkg", "");
        r.appLabel = o.optString("appLabel", "");
        r.name = o.optString("name", "");
        r.type = o.optInt("type", TYPE_FIRST_SCREEN);
        JSONArray a = o.optJSONArray("conditions");
        if (a != null) {
            for (int i = 0; i < a.length(); i++) {
                String s = a.optString(i, "");
                if (s.length() > 0) r.conditions.add(s);
            }
        }
        r.x = o.optInt("x", -1);
        r.y = o.optInt("y", -1);
        r.screenW = o.optInt("sw", 0);
        r.screenH = o.optInt("sh", 0);
        r.cooldownMs = o.optLong("cd", 1000L);
        r.enabled = o.optBoolean("enabled", true);
        r.hits = o.optLong("hits", 0);
        r.mode = o.optInt("md", MODE_POINT);
        JSONArray ti = o.optJSONArray("tids");
        if (ti != null) {
            for (int i = 0; i < ti.length(); i++) {
                String s2 = ti.optString(i, "");
                if (s2.length() > 0) r.targetIds.add(s2);
            }
        }
        r.relX = o.optInt("rx", 0);
        r.relY = o.optInt("ry", 0);
        r.corner = o.optInt("cn", 0);
        r.anchorW = o.optInt("aw", 0);
        r.anchorH = o.optInt("ah", 0);
        r.draft = o.optBoolean("dr", false);
        r.followOn = o.optBoolean("fo", false);
        JSONArray fp = o.optJSONArray("fp");
        if (fp != null) {
            for (int i = 0; i < fp.length(); i++) {
                JSONArray t = fp.optJSONArray(i);
                if (t == null) continue;
                r.followPts.add(new int[]{t.optInt(0), t.optInt(1), t.optInt(2, 500)});
            }
        }
        return r;
    }
}
