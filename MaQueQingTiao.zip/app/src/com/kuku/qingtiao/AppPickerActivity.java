package com.kuku.qingtiao;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

public class AppPickerActivity extends Activity {

    private static class AppEntry {
        String pkg;
        String label;

        AppEntry(String p, String l) {
            pkg = p;
            label = l;
        }
    }

    private static class Holder {
        ImageView icon;
        TextView name;
        TextView pkg;
        TextView badge;
    }

    private ListView listView;
    private AppAdapter adapter;
    private final List<AppEntry> all = new ArrayList<AppEntry>();
    private final List<AppEntry> shown = new ArrayList<AppEntry>();
    private final Map<String, Drawable> icons = new HashMap<String, Drawable>();
    private final Map<String, Integer> counts = new HashMap<String, Integer>();
    private String keyword = "";
    private Handler ui;
    private Drawable defIcon;
    private TextView emptyView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Ui.applyTheme(this);
        if (Ui.DARK) setTheme(R.style.AppThemeDark);
        setContentView(R.layout.activity_picker);
        Ui.applyPage(this);
        ui = new Handler(Looper.getMainLooper());
        defIcon = getPackageManager().getDefaultActivityIcon();

        buildHeader();

        listView = (ListView) findViewById(R.id.list);
        adapter = new AppAdapter();
        listView.setAdapter(adapter);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if (position < 0 || position >= shown.size()) return;
                AppEntry a = shown.get(position);
                if (getIntent().getBooleanExtra("pick", false)) {
                    Intent r = new Intent();
                    r.putExtra("pkg", a.pkg);
                    r.putExtra("label", a.label);
                    setResult(RESULT_OK, r);
                    finish();
                    return;
                }
                Intent i = new Intent(AppPickerActivity.this, RuleListActivity.class);
                i.putExtra("pkg", a.pkg);
                i.putExtra("label", a.label);
                startActivity(i);
            }
        });

        emptyView = Ui.text(this, "正在读取已安装应用…", 13f, Ui.SUB, false);
        emptyView.setPadding(Ui.dp(this, 14), Ui.dp(this, 18), Ui.dp(this, 14), Ui.dp(this, 18));

        loadCounts();
        loadApps();
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadCounts();
        if (adapter != null) adapter.notifyDataSetChanged();
    }

    private void loadCounts() {
        counts.clear();
        List<Rule> rules = RuleStore.get(this).all();
        for (int i = 0; i < rules.size(); i++) {
            String p = rules.get(i).pkg;
            Integer c = counts.get(p);
            counts.put(p, Integer.valueOf(c == null ? 1 : c.intValue() + 1));
        }
    }

    private void buildHeader() {
        LinearLayout header = (LinearLayout) findViewById(R.id.header);

        TextView back = Ui.text(this, "‹  返回", 14f, Ui.PRIMARY, true);
        back.setPadding(0, 0, 0, Ui.dp(this, 14));
        back.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                finish();
            }
        });
        header.addView(back);

        header.addView(Ui.text(this, "选择应用", 26f, Ui.TEXT, true));
        TextView sub = Ui.text(this, "为哪个应用添加跳过规则？", 12.5f, Ui.SUB, false);
        sub.setPadding(0, Ui.dp(this, 5), 0, Ui.dp(this, 14));
        header.addView(sub);

        EditText search = new EditText(this);
        search.setHint("搜索应用名");
        search.setTextSize(14f);
        search.setTextColor(Ui.TEXT);
        search.setHintTextColor(0xFFB4B9C6);
        search.setSingleLine(true);
        search.setBackground(Ui.bg(Ui.CARD, this, 12f));
        search.setPadding(Ui.dp(this, 14), Ui.dp(this, 10), Ui.dp(this, 14), Ui.dp(this, 10));
        search.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int a, int b, int c) {
            }

            public void onTextChanged(CharSequence s, int a, int b, int c) {
                keyword = s == null ? "" : s.toString().trim().toLowerCase(Locale.ROOT);
                applyFilter();
            }

            public void afterTextChanged(Editable s) {
            }
        });
        header.addView(search);
    }

    private void loadApps() {
        new Thread(new Runnable() {
            public void run() {
                final List<AppEntry> out = new ArrayList<AppEntry>();
                try {
                    PackageManager pm = getPackageManager();
                    Intent main = new Intent(Intent.ACTION_MAIN);
                    main.addCategory(Intent.CATEGORY_LAUNCHER);
                    List<ResolveInfo> list = pm.queryIntentActivities(main, 0);
                    Set<String> seen = new HashSet<String>();
                    String self = getPackageName();
                    for (int i = 0; i < list.size(); i++) {
                        ResolveInfo ri = list.get(i);
                        if (ri.activityInfo == null) continue;
                        String pkg = ri.activityInfo.packageName;
                        if (pkg == null || pkg.equals(self) || seen.contains(pkg)) continue;
                        if (RuleStore.get(AppPickerActivity.this).isWhitelisted(pkg)) continue;
                        seen.add(pkg);
                        String label;
                        try {
                            label = ri.loadLabel(pm).toString();
                        } catch (Exception e) {
                            label = pkg;
                        }
                        out.add(new AppEntry(pkg, label));
                    }
                    Collections.sort(out, new Comparator<AppEntry>() {
                        public int compare(AppEntry a, AppEntry b) {
                            return a.label.compareToIgnoreCase(b.label);
                        }
                    });
                } catch (Exception ignored) {
                }
                ui.post(new Runnable() {
                    public void run() {
                        all.clear();
                        all.addAll(out);
                        applyFilter();
                    }
                });
                // 图标后台逐个加载，不阻塞 UI
                for (int i = 0; i < out.size(); i++) {
                    final String pkg = out.get(i).pkg;
                    try {
                        final Drawable d = getPackageManager().getApplicationIcon(pkg);
                        ui.post(new Runnable() {
                            public void run() {
                                icons.put(pkg, d);
                            }
                        });
                    } catch (Exception ignored) {
                    }
                    if (i % 20 == 0) {
                        ui.post(new Runnable() {
                            public void run() {
                                if (adapter != null) adapter.notifyDataSetChanged();
                            }
                        });
                    }
                }
                ui.post(new Runnable() {
                    public void run() {
                        if (adapter != null) adapter.notifyDataSetChanged();
                    }
                });
            }
        }).start();
    }

    private void applyFilter() {
        shown.clear();
        for (int i = 0; i < all.size(); i++) {
            AppEntry a = all.get(i);
            if (keyword.length() == 0
                    || a.label.toLowerCase(Locale.ROOT).contains(keyword)
                    || a.pkg.toLowerCase(Locale.ROOT).contains(keyword)) {
                shown.add(a);
            }
        }
        if (adapter != null) adapter.notifyDataSetChanged();
    }

    private class AppAdapter extends BaseAdapter {

        public int getCount() {
            return shown.size();
        }

        public Object getItem(int position) {
            return shown.get(position);
        }

        public long getItemId(int position) {
            return position;
        }

        public View getView(int position, View convertView, ViewGroup parent) {
            Holder h;
            if (convertView == null) {
                LinearLayout row = new LinearLayout(AppPickerActivity.this);
                row.setOrientation(LinearLayout.HORIZONTAL);
                row.setGravity(Gravity.CENTER_VERTICAL);
                row.setPadding(Ui.dp(AppPickerActivity.this, 14), Ui.dp(AppPickerActivity.this, 10),
                        Ui.dp(AppPickerActivity.this, 14), Ui.dp(AppPickerActivity.this, 10));

                h = new Holder();
                h.icon = new ImageView(AppPickerActivity.this);
                LinearLayout.LayoutParams ilp = new LinearLayout.LayoutParams(
                        Ui.dp(AppPickerActivity.this, 36), Ui.dp(AppPickerActivity.this, 36));
                ilp.rightMargin = Ui.dp(AppPickerActivity.this, 12);
                h.icon.setLayoutParams(ilp);
                row.addView(h.icon);

                LinearLayout mid = new LinearLayout(AppPickerActivity.this);
                mid.setOrientation(LinearLayout.VERTICAL);
                h.name = Ui.text(AppPickerActivity.this, "", 14f, Ui.TEXT, true);
                h.pkg = Ui.text(AppPickerActivity.this, "", 10f, Ui.SUB, false);
                h.pkg.setPadding(0, Ui.dp(AppPickerActivity.this, 2), 0, 0);
                mid.addView(h.name);
                mid.addView(h.pkg);
                row.addView(mid, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

                h.badge = Ui.pill(AppPickerActivity.this, "", Ui.PRIMARY, Ui.PRIMARY_SOFT);
                h.badge.setVisibility(View.GONE);
                row.addView(h.badge);

                convertView = row;
                convertView.setTag(h);
            } else {
                h = (Holder) convertView.getTag();
            }

            AppEntry a = shown.get(position);
            h.name.setText(a.label);
            h.pkg.setText(a.pkg);
            Drawable d = icons.get(a.pkg);
            h.icon.setImageDrawable(d != null ? d : defIcon);
            Integer c = counts.get(a.pkg);
            if (c != null && c.intValue() > 0) {
                h.badge.setVisibility(View.VISIBLE);
                h.badge.setText(c.intValue() + " 条");
            } else {
                h.badge.setVisibility(View.GONE);
            }
            return convertView;
        }
    }
}
