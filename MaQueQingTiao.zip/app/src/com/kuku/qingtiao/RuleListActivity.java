package com.kuku.qingtiao;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.CompoundButton;
import android.widget.LinearLayout;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class RuleListActivity extends Activity {

    private LinearLayout content;
    private String pkg;
    private String label;
    private Switch strictSw;
    private EditText baseInput;
    private EditText tolInput;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Ui.applyTheme(this);
        if (Ui.DARK) setTheme(R.style.AppThemeDark);
        setContentView(R.layout.activity_page);
        Ui.applyPage(this);
        pkg = getIntent().getStringExtra("pkg");
        label = getIntent().getStringExtra("label");
        content = (LinearLayout) findViewById(R.id.content);
        Button bottom = (Button) findViewById(R.id.btnBottom);
        bottom.setText("＋  新建规则");
        bottom.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                RuleStore store = RuleStore.get(RuleListActivity.this);
                Rule r = new Rule();
                r.pkg = pkg;
                r.appLabel = label == null ? "" : label;
                r.name = "规则 " + (store.countFor(pkg) + 1);
                r.type = Rule.TYPE_IN_APP;
                r.mode = store.recordMode();
                r.draft = true;
                store.save(r);
                store.setActiveDraft(r.id);
                Intent i = new Intent(RuleListActivity.this, OverlayService.class);
                i.putExtra("fromEdit", true);
                try {
                    if (Build.VERSION.SDK_INT >= 26) startForegroundService(i);
                    else startService(i);
                } catch (Exception ignored) {
                }
                try {
                    Intent app = getPackageManager().getLaunchIntentForPackage(pkg);
                    if (app != null) {
                        app.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        startActivity(app);
                    }
                } catch (Exception ignored) {
                }
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        render();
    }

    private void render() {
        content.removeAllViews();

        TextView back = Ui.text(this, "‹  返回", 14f, Ui.PRIMARY, true);
        back.setPadding(0, 0, 0, Ui.dp(this, 14));
        back.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                finish();
            }
        });
        content.addView(back);

        String name = label;
        if (name == null || name.length() == 0) {
            try {
                name = getPackageManager().getApplicationLabel(
                        getPackageManager().getApplicationInfo(pkg, 0)).toString();
            } catch (Exception e) {
                name = pkg;
            }
        }
        content.addView(Ui.text(this, name, 24f, Ui.TEXT, true));
        TextView sub = Ui.text(this, pkg, 11f, Ui.SUB, false);
        sub.setPadding(0, Ui.dp(this, 4), 0, Ui.dp(this, 16));
        content.addView(sub);

        content.addView(buildStrictCard());
        content.addView(buildDelayCard());

        RuleStore rs = RuleStore.get(this);
        rs.purgeEmptyDrafts();
        List<Rule> rules = new ArrayList<Rule>();
        List<Rule> raw = rs.forPackage(pkg);
        for (int i = 0; i < raw.size(); i++) {
            if (!raw.get(i).draft) rules.add(raw.get(i));
        }
        if (rules.isEmpty()) {
            LinearLayout empty = Ui.card(this);
            empty.addView(Ui.text(this, "还没有规则", 14.5f, Ui.TEXT, true));
            TextView t = Ui.text(this, "添加规则后，这个应用的开屏广告将由你的规则接管；未添加时由通用引擎自动处理。", 11.5f, Ui.SUB, false);
            t.setPadding(0, Ui.dp(this, 6), 0, 0);
            empty.addView(t);
            content.addView(empty);
            return;
        }

        for (int i = 0; i < rules.size(); i++) {
            final Rule r = rules.get(i);
            LinearLayout card = Ui.card(this);

            LinearLayout head = Ui.row(this);
            LinearLayout left = new LinearLayout(this);
            left.setOrientation(LinearLayout.VERTICAL);
            String title = r.name == null || r.name.length() == 0 ? "未命名规则" : r.name;
            left.addView(Ui.text(this, title, 15f, Ui.TEXT, true));
            LinearLayout meta = Ui.row(this);
            meta.setPadding(0, Ui.dp(this, 6), 0, 0);
            meta.addView(Ui.pill(this, r.typeName(),
                    r.type == Rule.TYPE_FIRST_SCREEN ? Ui.PRIMARY : Ui.WARN,
                    r.type == Rule.TYPE_FIRST_SCREEN ? Ui.PRIMARY_SOFT : Ui.WARN_SOFT));
            TextView sp = Ui.text(this, "  条件 " + r.conditions.size() + " 个", 10.5f, Ui.SUB, false);
            meta.addView(sp);
            left.addView(meta);
            head.addView(left, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

            Switch sw = new Switch(this);
            sw.setChecked(r.enabled);
            sw.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                public void onCheckedChanged(CompoundButton b, boolean checked) {
                    r.enabled = checked;
                    RuleStore.get(RuleListActivity.this).save(r);
                }
            });
            head.addView(sw);
            card.addView(head);

            card.addView(Ui.divider(this));

            String modeTag = r.mode == Rule.MODE_WIDGET ? "点控件"
                    : r.mode == Rule.MODE_ANCHOR ? "动态坐标" : "固定坐标";
            String ptText = r.mode == Rule.MODE_WIDGET
                    ? "点击方式 " + modeTag + "（" + r.targetIds.size() + " 个目标）· 已触发 " + r.hits + " 次"
                    : r.mode == Rule.MODE_ANCHOR
                    ? "点击方式 " + modeTag + "（锚点偏移 " + r.relX + "," + r.relY + "）· 已触发 " + r.hits + " 次"
                    : "点击坐标  (" + r.x + ", " + r.y + ")   ·   已触发 " + r.hits + " 次";
            TextView pt = Ui.text(this, ptText, 11.5f, Ui.SUB, false);
            card.addView(pt);

            LinearLayout acts = Ui.row(this);
            acts.setPadding(0, Ui.dp(this, 12), 0, 0);
            TextView edit = Ui.buttonSmall(this, "编辑");
            edit.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    Intent i = new Intent(RuleListActivity.this, RuleEditActivity.class);
                    i.putExtra("pkg", pkg);
                    i.putExtra("label", label);
                    i.putExtra("ruleId", r.id);
                    startActivity(i);
                }
            });
            acts.addView(edit);
            if (r.mode == Rule.MODE_POINT) {
                acts.addView(Ui.space(this, 8));
                TextView upd = Ui.buttonSmall(this, "更新坐标");
                upd.setOnClickListener(new View.OnClickListener() {
                    public void onClick(View v) {
                        updatePoint(r);
                    }
                });
                acts.addView(upd);
            }
            acts.addView(Ui.space(this, 8));
            TextView del = Ui.buttonSmall(this, "删除");
            del.setTextColor(Ui.DANGER);
            del.setBackground(Ui.ripple(Ui.DANGER_SOFT, this, 10f));
            del.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    confirmDelete(r);
                }
            });
            acts.addView(del);
            card.addView(acts);

            content.addView(card);
        }
    }

    private EditText delayInput;

    private LinearLayout buildDelayCard() {
        final RuleStore store = RuleStore.get(this);
        LinearLayout card = Ui.card(this);
        card.addView(Ui.text(this, "通用引擎延迟", 15f, Ui.TEXT, true));
        TextView d = Ui.text(this, "进入应用后等这么久再开始关键词点击 · 单位毫秒（1 秒 = 1000）· 仅通用引擎", 11f, Ui.SUB, false);
        d.setPadding(0, Ui.dp(this, 3), 0, Ui.dp(this, 8));
        card.addView(d);
        delayInput = numInput("0 = 不延迟", String.valueOf(store.genDelay(pkg)));
        card.addView(delayInput);
        delayInput.addTextChangedListener(new android.text.TextWatcher() {
            public void beforeTextChanged(CharSequence s, int a, int b, int c) {
            }

            public void onTextChanged(CharSequence s, int a, int b, int c) {
                try {
                    long v = Long.parseLong(s.toString().trim());
                    if (v >= 0 && v <= 30000) store.setGenDelay(pkg, v);
                } catch (Exception ignored) {
                }
            }

            public void afterTextChanged(android.text.Editable s) {
            }
        });
        return card;
    }

    private LinearLayout buildStrictCard() {
        final RuleStore store = RuleStore.get(this);
        LinearLayout card = Ui.card(this);

        LinearLayout head = Ui.row(this);
        LinearLayout left = new LinearLayout(this);
        left.setOrientation(LinearLayout.VERTICAL);
        left.addView(Ui.text(this, "严格模式", 15f, Ui.TEXT, true));
        TextView d = Ui.text(this, "只有当前页面控件总数在设定范围内，才执行跳过", 11f, Ui.SUB, false);
        d.setPadding(0, Ui.dp(this, 3), 0, 0);
        left.addView(d);
        head.addView(left, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        strictSw = new Switch(this);
        strictSw.setChecked(store.isStrict(pkg));
        head.addView(strictSw);
        card.addView(head);

        int[] sp = store.strictParams(pkg);
        LinearLayout row = Ui.row(this);
        row.setPadding(0, Ui.dp(this, 10), 0, 0);

        baseInput = numInput("控件数", sp[0] > 0 ? String.valueOf(sp[0]) : "");
        tolInput = numInput("± 容差", sp[1] > 0 ? String.valueOf(sp[1]) : "");

        LinearLayout.LayoutParams lp1 = new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        lp1.rightMargin = Ui.dp(this, 8);
        row.addView(baseInput, lp1);
        row.addView(tolInput, new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        card.addView(row);

        TextView tip = Ui.text(this, "切到目标应用广告页，点悬浮球「① 检视控件」，提示里会显示该页面的节点总数", 10.5f, Ui.SUB, false);
        tip.setPadding(0, Ui.dp(this, 8), 0, 0);
        card.addView(tip);

        strictSw.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton b, boolean checked) {
                saveStrict();
            }
        });
        return card;
    }

    private EditText numInput(String hint, String value) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setText(value);
        e.setTextSize(13f);
        e.setTextColor(Ui.TEXT);
        e.setHintTextColor(0xFFB4B9C6);
        e.setSingleLine(true);
        e.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
        e.setBackground(Ui.bg(Ui.INPUT_BG, this, 10f));
        e.setPadding(Ui.dp(this, 12), Ui.dp(this, 9), Ui.dp(this, 12), Ui.dp(this, 9));
        return e;
    }

    private void saveStrict() {
        if (strictSw == null || baseInput == null || tolInput == null) return;
        int base = 0;
        int tol = 0;
        try {
            String b = baseInput.getText().toString().trim();
            if (b.length() > 0) base = Integer.parseInt(b);
        } catch (Exception ignored) {
        }
        try {
            String t = tolInput.getText().toString().trim();
            if (t.length() > 0) tol = Integer.parseInt(t);
        } catch (Exception ignored) {
        }
        if (base < 0) base = 0;
        if (tol < 0) tol = 0;
        RuleStore.get(this).setStrict(pkg, strictSw.isChecked(), base, tol);
    }

    @Override
    protected void onPause() {
        saveStrict();
        super.onPause();
    }

    private void updatePoint(Rule r) {
        if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "请先授权悬浮窗权限", Toast.LENGTH_SHORT).show();
            try {
                startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:" + getPackageName())));
            } catch (Exception ignored) {
            }
            return;
        }
        Intent i = new Intent(this, OverlayService.class);
        i.putExtra("ruleId", r.id);
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i);
        else startService(i);
        Toast.makeText(this, "准心已出现，拖到「跳过」按钮位置后点「保存坐标」", Toast.LENGTH_LONG).show();
    }

    private void confirmDelete(final Rule r) {
        new AlertDialog.Builder(this)
                .setTitle("删除规则")
                .setMessage("确定删除这条规则吗？")
                .setNegativeButton("取消", null)
                .setPositiveButton("删除", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface d, int w) {
                        RuleStore.get(RuleListActivity.this).remove(r.id);
                        render();
                    }
                })
                .show();
    }
}
