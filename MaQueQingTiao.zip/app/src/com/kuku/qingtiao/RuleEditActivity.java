package com.kuku.qingtiao;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.util.DisplayMetrics;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class RuleEditActivity extends Activity {

    private LinearLayout content;
    private LinearLayout condBox;
    private TextView pointView;
    private TextView pointHint;
    private EditText nameInput;
    private EditText cdInput;
    private RadioGroup typeGroup;
    private RadioButton rbFirst;
    private RadioButton rbInApp;

    private Rule rule;
    private final List<String> conds = new ArrayList<String>();
    private int[] point;
    private long lastStamp = 0L;
    private boolean wasDraft = false;
    private boolean saved = false;

    private String pkg;
    private String label;
    private TextView appSub;
    private LinearLayout followBox;
    private android.widget.Switch followSwitch;
    private RadioButton rbPoint, rbWidget, rbAnchor;
    private LinearLayout modeBox;
    private static final int REQ_APP = 1001;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Ui.applyTheme(this);
        if (Ui.DARK) setTheme(R.style.AppThemeDark);
        setContentView(R.layout.activity_page);
        Ui.applyPage(this);
        content = (LinearLayout) findViewById(R.id.content);
        pkg = getIntent().getStringExtra("pkg");
        label = getIntent().getStringExtra("label");
        String ruleId = getIntent().getStringExtra("ruleId");

        RuleStore store = RuleStore.get(this);
        Rule existing = ruleId == null ? null : store.find(ruleId);
        if (existing != null) {
            rule = existing;
            conds.addAll(existing.conditions);
            if (existing.x >= 0 && existing.y >= 0) {
                point = new int[]{existing.x, existing.y, existing.screenW, existing.screenH};
            }
        } else {
            rule = new Rule();
            if (ruleId != null && ruleId.length() > 0) rule.id = ruleId;
            rule.pkg = pkg == null ? "" : pkg;
            rule.appLabel = label == null ? "" : label;
            rule.draft = true;
        }
        wasDraft = rule.draft;
        store.setActiveDraft(rule.id);

        Button bottom = (Button) findViewById(R.id.btnBottom);
        bottom.setText("保存规则");
        bottom.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                save();
            }
        });

        build();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (wasDraft && !saved && rule != null && rule.id != null) {
            RuleStore s = RuleStore.get(this);
            Rule cur = s.find(rule.id);
            if (cur != null && cur.draft) s.remove(rule.id);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_APP && resultCode == RESULT_OK && data != null) {
            String p = data.getStringExtra("pkg");
            String l = data.getStringExtra("label");
            if (p != null && p.length() > 0) {
                pkg = p;
                label = l == null ? "" : l;
                rule.pkg = pkg;
                rule.appLabel = label;
                if (appSub != null) {
                    appSub.setText((label.length() == 0 ? pkg : label) + "  ·  " + pkg);
                }
            }
        }
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        if (intent == null) return;
        setIntent(intent);
        String rid = intent.getStringExtra("ruleId");
        if (rid == null) return;
        RuleStore s = RuleStore.get(this);
        Rule r = s.find(rid);
        if (r != null) {
            rule = r;
            conds.clear();
            conds.addAll(r.conditions);
            point = (r.x >= 0 && r.y >= 0) ? new int[]{r.x, r.y, r.screenW, r.screenH} : null;
            s.setActiveDraft(r.id);
            lastStamp = 0L;
            build();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (rule == null) return;
        RuleStore s = RuleStore.get(this);
        long stamp = s.draftStamp(rule.id);
        if (stamp != 0L && stamp != lastStamp) {
            lastStamp = stamp;
            List<String> nd = s.draftConditions(rule.id);
            if (!nd.isEmpty()) {
                conds.clear();
                conds.addAll(nd);
            }
            int[] np = s.draftPoint(rule.id);
            if (np != null) point = np;
            renderConds();
            renderPoint();
            syncFollowFromStore();
            return;
        }
        boolean changed = false;
        List<String> d = s.draftConditions(rule.id);
        for (int i = 0; i < d.size(); i++) {
            String c = d.get(i);
            if (!conds.contains(c)) {
                conds.add(c);
                changed = true;
            }
        }
        int[] p = s.draftPoint(rule.id);
        if (p != null) {
            point = p;
            changed = true;
        }
        if (changed) {
            renderConds();
            renderPoint();
        }
        syncFollowFromStore();
    }

    private void syncFollowFromStore() {
        if (rule == null) return;
        Rule fresh = RuleStore.get(this).find(rule.id);
        if (fresh == null) return;
        rule.followOn = fresh.followOn;
        if (followSwitch != null && followSwitch.isChecked() != rule.followOn) {
            followSwitch.setChecked(rule.followOn);
        }
        renderFollow();
    }

    private void build() {
        content.removeAllViews();

        TextView back = Ui.text(this, "‹  返回", 14f, Ui.PRIMARY, true);
        back.setPadding(0, 0, 0, Ui.dp(this, 14));
        back.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                finish();
            }
        });
        content.addView(back);

        boolean editing = rule.name != null && rule.name.length() > 0;
        content.addView(Ui.text(this, editing ? "编辑规则" : "新建规则", 26f, Ui.TEXT, true));

        String appName = label;
        if (appName == null || appName.length() == 0) appName = pkg;
        if (appName == null || appName.length() == 0) appName = "未选择";
        LinearLayout appCard = Ui.card(this);
        appCard.addView(Ui.text(this, "目标应用", 14.5f, Ui.TEXT, true));
        appSub = Ui.text(this, appName + "  ·  " + (pkg == null || pkg.length() == 0 ? "点击选择" : pkg),
                11.5f, Ui.PRIMARY, false);
        appSub.setPadding(0, Ui.dp(this, 4), 0, 0);
        appCard.addView(appSub);
        appCard.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent i = new Intent(RuleEditActivity.this, AppPickerActivity.class);
                i.putExtra("pick", true);
                startActivityForResult(i, REQ_APP);
            }
        });
        LinearLayout.LayoutParams alp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        alp.topMargin = Ui.dp(this, 14);
        content.addView(appCard, alp);

        // 规则名
        LinearLayout c1 = Ui.card(this);
        c1.addView(Ui.text(this, "规则名称", 14.5f, Ui.TEXT, true));
        nameInput = new EditText(this);
        nameInput.setHint("例如：开屏广告 / 首页弹窗");
        nameInput.setTextSize(14f);
        nameInput.setTextColor(Ui.TEXT);
        nameInput.setHintTextColor(0xFFB4B9C6);
        nameInput.setSingleLine(true);
        nameInput.setBackground(Ui.bg(Ui.INPUT_BG, this, 12f));
        nameInput.setPadding(Ui.dp(this, 14), Ui.dp(this, 11), Ui.dp(this, 14), Ui.dp(this, 11));
        if (rule.name != null) nameInput.setText(rule.name);
        LinearLayout.LayoutParams nlp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        nlp.topMargin = Ui.dp(this, 10);
        c1.addView(nameInput, nlp);
        content.addView(c1);

        // 类型
        LinearLayout c2 = Ui.card(this);
        c2.addView(Ui.text(this, "生效范围", 14.5f, Ui.TEXT, true));
        typeGroup = new RadioGroup(this);
        typeGroup.setOrientation(RadioGroup.VERTICAL);
        rbFirst = new RadioButton(this);
        rbFirst.setId(View.generateViewId());
        rbFirst.setText("仅第一屏（启动后 6 秒内）");
        rbFirst.setTextSize(13.5f);
        rbFirst.setTextColor(Ui.TEXT);
        rbInApp = new RadioButton(this);
        rbInApp.setId(View.generateViewId());
        rbInApp.setText("应用内持续监听（弹窗）");
        rbInApp.setTextSize(13.5f);
        rbInApp.setTextColor(Ui.TEXT);
        typeGroup.addView(rbFirst);
        typeGroup.addView(rbInApp);
        if (rule.type == Rule.TYPE_IN_APP) typeGroup.check(rbInApp.getId());
        else typeGroup.check(rbFirst.getId());
        c2.addView(typeGroup);
        content.addView(c2);

        // 条件
        LinearLayout c3 = Ui.card(this);
        c3.addView(Ui.text(this, "条件控件", 14.5f, Ui.TEXT, true));
        TextView h = Ui.text(this, "所有条件同时出现才会点击。建议 2 个以上，只填 1 个也可以，但误触风险更高", 11f, Ui.SUB, false);
        h.setPadding(0, Ui.dp(this, 4), 0, Ui.dp(this, 10));
        c3.addView(h);
        condBox = new LinearLayout(this);
        condBox.setOrientation(LinearLayout.VERTICAL);
        c3.addView(condBox);
        TextView pick = Ui.button(this, "用悬浮窗录制规则", true);
        LinearLayout.LayoutParams plp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        plp.topMargin = Ui.dp(this, 12);
        pick.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                guidePickControls();
            }
        });
        c3.addView(pick, plp);
        content.addView(c3);

        // 坐标
        LinearLayout c4 = Ui.card(this);
        c4.addView(Ui.text(this, rule.mode == Rule.MODE_WIDGET ? "点击方式：控件"
                : rule.mode == Rule.MODE_ANCHOR ? "点击方式：动态坐标" : "点击坐标", 14.5f, Ui.TEXT, true));
        pointView = Ui.text(this, "", 14f, Ui.TEXT, true);
        pointView.setPadding(0, Ui.dp(this, 8), 0, 0);
        c4.addView(pointView);
        pointHint = Ui.text(this, "", 11f, Ui.SUB, false);
        pointHint.setPadding(0, Ui.dp(this, 4), 0, 0);
        c4.addView(pointHint);
        TextView ptTip = Ui.text(this, rule.mode == Rule.MODE_WIDGET
                ? "条件满足时按 id 点击目标控件中心，不依赖坐标"
                : rule.mode == Rule.MODE_ANCHOR
                ? "点击位置按「锚点控件位置 + 偏移」实时计算，不固定同一位置"
                : "坐标在悬浮窗里用「② 准心坐标」定位，点「保存规则」时一并记录", 11f, Ui.SUB, false);
        ptTip.setPadding(0, Ui.dp(this, 8), 0, 0);
        c4.addView(ptTip);
        content.addView(c4);

        // 续点
        LinearLayout c6 = Ui.card(this);
        LinearLayout fRow = Ui.row(this);
        fRow.setGravity(android.view.Gravity.CENTER_VERTICAL);
        fRow.addView(Ui.text(this, "续点", 14.5f, Ui.TEXT, true),
                new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        followSwitch = new android.widget.Switch(this);
        followSwitch.setChecked(rule.followOn);
        followSwitch.setOnCheckedChangeListener(new android.widget.CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(android.widget.CompoundButton b, boolean checked) {
                rule.followOn = checked;
                RuleStore.get(RuleEditActivity.this).setFollowOn(rule.id, checked);
                renderFollow();
            }
        });
        fRow.addView(followSwitch);
        c6.addView(fRow);
        TextView fTip = Ui.text(this, "开启后，主坐标点完会按顺序继续点这些位置。适合「跳过 → 关闭 → 确认」这类多步广告。",
                11f, Ui.SUB, false);
        fTip.setPadding(0, Ui.dp(this, 4), 0, Ui.dp(this, 8));
        c6.addView(fTip);
        followBox = new LinearLayout(this);
        followBox.setOrientation(LinearLayout.VERTICAL);
        c6.addView(followBox);
        content.addView(c6);

        // 冷却
        LinearLayout c5 = Ui.card(this);
        c5.addView(Ui.text(this, "冷却时间（毫秒）", 14.5f, Ui.TEXT, true));
        TextView h2 = Ui.text(this, "触发一次后，该规则在此时间内不再重复点击", 11f, Ui.SUB, false);
        h2.setPadding(0, Ui.dp(this, 4), 0, Ui.dp(this, 10));
        c5.addView(h2);
        cdInput = new EditText(this);
        cdInput.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
        cdInput.setText(String.valueOf(rule.cooldownMs));
        cdInput.setTextSize(14f);
        cdInput.setTextColor(Ui.TEXT);
        cdInput.setSingleLine(true);
        cdInput.setBackground(Ui.bg(Ui.INPUT_BG, this, 12f));
        cdInput.setPadding(Ui.dp(this, 14), Ui.dp(this, 11), Ui.dp(this, 14), Ui.dp(this, 11));
        c5.addView(cdInput);
        content.addView(c5);

        TextView tip = Ui.text(this, "规则只保存在本机；切换设备或修改分辨率后，请重新拾取坐标。", 11f, Ui.SUB, false);
        tip.setPadding(Ui.dp(this, 4), Ui.dp(this, 4), Ui.dp(this, 4), Ui.dp(this, 8));
        content.addView(tip);

        renderConds();
        renderPoint();
        renderFollow();
    }

    private void renderModeExtra() {
        if (modeBox == null) return;
        modeBox.removeAllViews();
        if (rule.mode == Rule.MODE_WIDGET) {
            TextView h = Ui.text(this, "点击目标控件（条件满足时按顺序点这些控件中心）", 11.5f, Ui.TEXT, true);
            h.setPadding(0, Ui.dp(this, 8), 0, Ui.dp(this, 6));
            modeBox.addView(h);
            Rule now = RuleStore.get(this).find(rule.id);
            List<String> ids = now == null ? new ArrayList<String>() : now.targetIds;
            if (ids.isEmpty()) {
                modeBox.addView(Ui.text(this, "还没有点击控件。点下面按钮，用悬浮窗检视后输入序号添加。", 11f, Ui.SUB, false));
            }
            for (int i = 0; i < ids.size(); i++) {
                final int idx = i;
                LinearLayout row = Ui.row(this);
                row.setGravity(android.view.Gravity.CENTER_VERTICAL);
                row.setPadding(0, Ui.dp(this, 4), 0, Ui.dp(this, 4));
                TextView t = Ui.text(this, (i + 1) + ". " + ids.get(i), 11f, Ui.TEXT, false);
                row.addView(t, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
                TextView del = Ui.text(this, "✕", 13f, Ui.WARN, true);
                del.setPadding(Ui.dp(this, 8), 0, Ui.dp(this, 4), 0);
                del.setOnClickListener(new View.OnClickListener() {
                    public void onClick(View v) {
                        Rule rr = RuleStore.get(RuleEditActivity.this).find(rule.id);
                        if (rr != null && idx < rr.targetIds.size()) {
                            rr.targetIds.remove(idx);
                            RuleStore.get(RuleEditActivity.this).save(rr);
                        }
                        renderModeExtra();
                    }
                });
                row.addView(del);
                modeBox.addView(row);
            }
            Button add = new Button(this);
            add.setText("＋ 用悬浮窗添加点击控件");
            add.setTextSize(12.5f);
            add.setAllCaps(false);
            add.setTextColor(Ui.PRIMARY);
            add.setBackground(Ui.bg(Ui.PRIMARY_SOFT, this, 10f));
            LinearLayout.LayoutParams alp2 = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            alp2.topMargin = Ui.dp(this, 8);
            add.setLayoutParams(alp2);
            add.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    pickTargetWidget();
                }
            });
            modeBox.addView(add);
        } else if (rule.mode == Rule.MODE_ANCHOR) {
            TextView h = Ui.text(this, "动态坐标", 11.5f, Ui.TEXT, true);
            h.setPadding(0, Ui.dp(this, 8), 0, Ui.dp(this, 4));
            modeBox.addView(h);
            int[] an = RuleStore.get(this).draftAnchor(rule.id);
            String info = an == null ? "还没有锚点。先在上面录制条件（第一个条件就是锚点），再用准心记录点击位置。"
                    : "锚点 " + an[0] + "," + an[1] + " - " + an[2] + "," + an[3]
                    + "\n偏移 " + rule.relX + ", " + rule.relY;
            TextView t = Ui.text(this, info, 11f, Ui.SUB, false);
            t.setPadding(0, 0, 0, Ui.dp(this, 4));
            modeBox.addView(t);
            modeBox.addView(Ui.text(this, "保存时按「锚点左上角 + 偏移」计算点击位置，锚点缩放会按比例换算。",
                    10.5f, Ui.SUB, false));
            Button re = new Button(this);
            re.setText("＋ 重新录制锚点与点击位置");
            re.setTextSize(12.5f);
            re.setAllCaps(false);
            re.setTextColor(Ui.PRIMARY);
            re.setBackground(Ui.bg(Ui.PRIMARY_SOFT, this, 10f));
            LinearLayout.LayoutParams rlp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            rlp.topMargin = Ui.dp(this, 8);
            re.setLayoutParams(rlp);
            re.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    guidePickPoint();
                }
            });
            modeBox.addView(re);
        }
    }

    private void pickTargetWidget() {
        if (!ensureOverlay()) return;
        RuleStore.get(this).setActiveDraft(rule.id);
        Intent i = new Intent(this, OverlayService.class);
        i.putExtra("ruleId", rule.id);
        i.putExtra("pickTarget", true);
        try {
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(i);
            else startService(i);
        } catch (Exception ignored) {
        }
        Toast.makeText(this, "点「① 检视控件」，再输入要点击的控件序号", Toast.LENGTH_LONG).show();
    }

    private void renderFollow() {
        if (followBox == null) return;
        followBox.removeAllViews();
        if (rule == null || !rule.followOn) {
            followBox.setVisibility(View.GONE);
            return;
        }
        followBox.setVisibility(View.VISIBLE);
        Rule now = RuleStore.get(this).find(rule.id);
        List<int[]> pts = now == null ? new ArrayList<int[]>() : now.followPts;
        if (pts.isEmpty()) {
            TextView e = Ui.text(this, "还没有续点。点下面的按钮，用悬浮窗准心逐个添加。", 11f, Ui.SUB, false);
            e.setPadding(0, Ui.dp(this, 4), 0, Ui.dp(this, 8));
            followBox.addView(e);
        }
        for (int i = 0; i < pts.size(); i++) {
            final int idx = i;
            int[] p = pts.get(i);
            LinearLayout row = Ui.row(this);
            row.setGravity(android.view.Gravity.CENTER_VERTICAL);
            row.setPadding(0, Ui.dp(this, 6), 0, Ui.dp(this, 6));
            row.addView(Ui.text(this, (i + 1) + ".  (" + p[0] + ", " + p[1] + ")", 12.5f, Ui.TEXT, true),
                    new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
            final EditText de = new EditText(this);
            de.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
            de.setText(String.valueOf(p[2]));
            de.setTextSize(12f);
            de.setTextColor(Ui.TEXT);
            de.setSingleLine(true);
            de.setBackground(Ui.bg(Ui.INPUT_BG, this, 8f));
            de.setPadding(Ui.dp(this, 8), Ui.dp(this, 5), Ui.dp(this, 8), Ui.dp(this, 5));
            LinearLayout.LayoutParams dlp = new LinearLayout.LayoutParams(Ui.dp(this, 64),
                    ViewGroup.LayoutParams.WRAP_CONTENT);
            de.setLayoutParams(dlp);
            de.setOnFocusChangeListener(new View.OnFocusChangeListener() {
                public void onFocusChange(View v, boolean has) {
                    if (has) return;
                    try {
                        int d = Integer.parseInt(de.getText().toString().trim());
                        if (d < 100) d = 100;
                        if (d > 10000) d = 10000;
                        RuleStore.get(RuleEditActivity.this).setFollowPointDelay(rule.id, idx, d);
                    } catch (Exception ignored) {
                    }
                }
            });
            row.addView(de);
            TextView unit = Ui.text(this, "ms", 10.5f, Ui.SUB, false);
            unit.setPadding(Ui.dp(this, 4), 0, Ui.dp(this, 10), 0);
            row.addView(unit);
            TextView del = Ui.text(this, "✕", 14f, Ui.WARN, true);
            del.setPadding(Ui.dp(this, 6), 0, Ui.dp(this, 6), 0);
            del.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    RuleStore.get(RuleEditActivity.this).removeFollowPoint(rule.id, idx);
                    renderFollow();
                }
            });
            row.addView(del);
            followBox.addView(row);
        }
        Button add = new Button(this);
        add.setText("＋ 用悬浮窗添加续点");
        add.setTextSize(12.5f);
        add.setAllCaps(false);
        add.setTextColor(Ui.PRIMARY);
        add.setBackground(Ui.bg(Ui.PRIMARY_SOFT, this, 10f));
        add.setPadding(0, Ui.dp(this, 9), 0, Ui.dp(this, 9));
        LinearLayout.LayoutParams alp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        alp.topMargin = Ui.dp(this, 8);
        add.setLayoutParams(alp);
        add.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                guideAddFollow();
            }
        });
        followBox.addView(add);
    }

    private void guideAddFollow() {
        if (!ensureOverlay()) return;
        RuleStore.get(this).setActiveDraft(rule.id);
        Intent i = new Intent(this, OverlayService.class);
        i.putExtra("ruleId", rule.id);
        i.putExtra("followPick", true);
        try {
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(i);
            else startService(i);
        } catch (Exception ignored) {
        }
        Toast.makeText(this, "准心已出现，拖到要点的位置后点「保存坐标」", Toast.LENGTH_LONG).show();
    }

    private String pretty(String cond) {
        if (cond == null) return "";
        if (cond.startsWith("text:")) return "文本：" + cond.substring(5);
        if (cond.startsWith("desc:")) return "描述：" + cond.substring(5);
        int i = cond.lastIndexOf('/');
        return i >= 0 ? cond.substring(i + 1) : cond;
    }

    private void renderConds() {
        if (condBox == null) return;
        condBox.removeAllViews();
        if (conds.isEmpty()) {
            TextView t = Ui.text(this, "尚未拾取任何条件", 12f, Ui.SUB, false);
            t.setPadding(0, Ui.dp(this, 4), 0, Ui.dp(this, 4));
            condBox.addView(t);
            return;
        }
        for (int i = 0; i < conds.size(); i++) {
            final String c = conds.get(i);
            LinearLayout row = Ui.row(this);
            row.setBackground(Ui.bg(Ui.INPUT_BG, this, 10f));
            row.setPadding(Ui.dp(this, 12), Ui.dp(this, 9), Ui.dp(this, 8), Ui.dp(this, 9));
            LinearLayout.LayoutParams rlp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            rlp.topMargin = Ui.dp(this, 6);
            row.setLayoutParams(rlp);

            TextView num = Ui.text(this, String.valueOf(i + 1), 11f, 0xFFFFFFFF, true);
            num.setBackground(Ui.bg(Ui.PRIMARY, this, 20f));
            num.setGravity(android.view.Gravity.CENTER);
            num.setWidth(Ui.dp(this, 18));
            num.setHeight(Ui.dp(this, 18));
            LinearLayout.LayoutParams nlp = new LinearLayout.LayoutParams(Ui.dp(this, 18), Ui.dp(this, 18));
            nlp.rightMargin = Ui.dp(this, 10);
            row.addView(num, nlp);

            TextView t = Ui.text(this, pretty(c), 11.5f, Ui.TEXT, false);
            t.setSingleLine(true);
            t.setEllipsize(android.text.TextUtils.TruncateAt.MIDDLE);
            row.addView(t, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

            TextView del = Ui.text(this, "×", 15f, Ui.SUB, false);
            del.setPadding(Ui.dp(this, 10), 0, Ui.dp(this, 4), Ui.dp(this, 2));
            del.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    conds.remove(c);
                    RuleStore.get(RuleEditActivity.this).removeDraftCondition(rule.id, c);
                    renderConds();
                }
            });
            row.addView(del);
            condBox.addView(row);
        }
    }

    private void renderPoint() {
        if (pointView == null) return;
        if (rule != null && rule.mode == Rule.MODE_WIDGET) {
            pointView.setText("目标控件 " + rule.targetIds.size() + " 个");
            pointView.setTextColor(Ui.TEXT);
            if (pointHint != null) pointHint.setText("条件满足后按 id 点击这些控件");
            return;
        }
        if (rule != null && rule.mode == Rule.MODE_ANCHOR) {
            pointView.setText("锚点偏移 " + rule.relX + ", " + rule.relY);
            pointView.setTextColor(Ui.TEXT);
            if (pointHint != null) {
                String[] cn = {"左上角", "右上角", "左下角", "右下角"};
                String cornerName = cn[Math.max(0, Math.min(3, rule.corner))];
                pointHint.setText("锚点 " + cornerName + " · " + rule.anchorW + "×" + rule.anchorH
                        + "，点击点随锚点移动");
            }
            return;
        }
        if (point == null) {
            pointView.setText("尚未拾取");
            pointView.setTextColor(Ui.SUB);
            if (pointHint != null) pointHint.setText("");
        } else {
            pointView.setText("(" + point[0] + ", " + point[1] + ")");
            pointView.setTextColor(Ui.TEXT);
            if (pointHint != null) {
                DisplayMetrics dm = getResources().getDisplayMetrics();
                int cw = dm.widthPixels;
                int ch = dm.heightPixels;
                if (point[2] > 0 && (Math.abs(point[2] - cw) > 40 || Math.abs(point[3] - ch) > 40)) {
                    pointHint.setText("注意：录制时为 " + point[2] + "×" + point[3]
                            + "，当前为 " + cw + "×" + ch + "，建议重新拾取");
                    pointHint.setTextColor(Ui.WARN);
                } else {
                    pointHint.setText("录制分辨率 " + point[2] + "×" + point[3]);
                    pointHint.setTextColor(Ui.SUB);
                }
            }
        }
    }

    private boolean ensureOverlay() {
        if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "请先授权悬浮窗权限", Toast.LENGTH_SHORT).show();
            try {
                startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:" + getPackageName())));
            } catch (Exception ignored) {
            }
            return false;
        }
        return true;
    }

    private void continueRecording() {
        RuleStore store = RuleStore.get(this);
        Rule r = new Rule();
        r.pkg = rule.pkg;
        r.appLabel = rule.appLabel;
        r.name = "规则 " + (store.countFor(rule.pkg) + 1);
        r.type = Rule.TYPE_IN_APP;
        r.mode = store.recordMode();
        r.draft = true;
        store.save(r);
        store.setActiveDraft(r.id);
        Intent i = new Intent(this, OverlayService.class);
        i.putExtra("fromEdit", true);
        try {
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(i);
            else startService(i);
        } catch (Exception ignored) {
        }
        openTargetApp();
        finish();
    }

    private void openTargetApp() {
        try {
            Intent i = getPackageManager().getLaunchIntentForPackage(rule.pkg);
            if (i != null) {
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(i);
            }
        } catch (Exception ignored) {
        }
    }

    private void startOverlayService() {
        if (OverlayService.alive) return;
        Intent i = new Intent(this, OverlayService.class);
        i.putExtra("fromEdit", true);
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i);
        else startService(i);
    }

    private void guidePickControls() {
        if (!ensureOverlay()) return;
        final RuleStore store = RuleStore.get(this);
        store.setActiveDraft(rule.id);
        startOverlayService();
        if (store.hideRecordTip()) return;

        final CheckBox cb = new CheckBox(this);
        cb.setText("不再提醒");
        cb.setTextSize(13f);
        cb.setTextColor(Ui.SUB);
        cb.setPadding(Ui.dp(this, 22), Ui.dp(this, 6), Ui.dp(this, 22), 0);

        new AlertDialog.Builder(this)
                .setTitle("录制规则")
                .setMessage("1. 悬浮球已开启（可拖动）\n2. 切到目标应用，停在广告页\n3. 点「① 检视控件」，界面上的控件会标上序号\n4. 点「② 准心坐标」，把准心拖到「跳过」按钮上\n5. 点「保存规则」，填控件序号（如 3,7）\n6. 返回本页，条件和坐标会自动填好")
                .setView(cb)
                .setPositiveButton("开始", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface d, int w) {
                        if (cb.isChecked()) store.setHideRecordTip(true);
                        openTargetApp();
                    }
                })
                .show();
    }

    private void guidePickPoint() {
        if (!ensureOverlay()) return;
        RuleStore.get(this).setActiveDraft(rule.id);
        startOverlayService();
        new AlertDialog.Builder(this)
                .setTitle("拾取点击坐标")
                .setMessage("1. 会自动跳到目标应用，停在广告页\n2. 点悬浮球 →「② 准心坐标」\n3. 把准心拖到「跳过 / 关闭」按钮上\n4. 点「记录坐标」，然后返回本页")
                .setPositiveButton("知道了", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface d, int w) {
                        openTargetApp();
                    }
                })
                .show();
    }

    private void save() {
        if (rule.pkg == null || rule.pkg.length() == 0) {
            Toast.makeText(this, "请先选择目标应用", Toast.LENGTH_SHORT).show();
            return;
        }
        String nm = nameInput.getText().toString().trim();
        int type = typeGroup.getCheckedRadioButtonId() == rbInApp.getId() ? Rule.TYPE_IN_APP : Rule.TYPE_FIRST_SCREEN;
        if (nm.length() == 0) nm = type == Rule.TYPE_FIRST_SCREEN ? "开屏规则" : "弹窗规则";
        if (conds.size() < 1) {
            Toast.makeText(this, "请先录制规则：检视控件并填序号", Toast.LENGTH_SHORT).show();
            return;
        }
        RuleStore st0 = RuleStore.get(this);
        Rule freshIds = st0.find(rule.id);
        if (freshIds != null) rule.targetIds = new ArrayList<String>(freshIds.targetIds);
        if (rule.mode == Rule.MODE_POINT && point == null) {
            Toast.makeText(this, "请先用准心拾取点击坐标", Toast.LENGTH_SHORT).show();
            return;
        }
        if (rule.mode == Rule.MODE_WIDGET && rule.targetIds.isEmpty()) {
            Toast.makeText(this, "点控件模式需要先添加点击控件", Toast.LENGTH_SHORT).show();
            return;
        }
        int[] anchorNow = st0.draftAnchor(rule.id);
        if (rule.mode == Rule.MODE_ANCHOR && (anchorNow == null || point == null)) {
            Toast.makeText(this, "动态坐标需要先录条件（锚点）和点击位置", Toast.LENGTH_SHORT).show();
            return;
        }
        long cd = 1000L;
        try {
            cd = Long.parseLong(cdInput.getText().toString().trim());
        } catch (Exception ignored) {
        }
        if (cd < 300L) cd = 300L;
        if (cd > 60000L) cd = 60000L;

        rule.name = nm;
        rule.type = type;
        if (conds.size() == 1) {
            Toast.makeText(this, "只有 1 个条件，误触风险较高", Toast.LENGTH_SHORT).show();
        }
        rule.conditions = new ArrayList<String>(conds);
        if (rule.mode == Rule.MODE_ANCHOR && anchorNow != null && point != null) {
            rule.anchorW = anchorNow[2] - anchorNow[0];
            rule.anchorH = anchorNow[3] - anchorNow[1];
            rule.relX = point[0] - anchorNow[0];
            rule.relY = point[1] - anchorNow[1];
            rule.x = point[0];
            rule.y = point[1];
            rule.screenW = point[2];
            rule.screenH = point[3];
        } else if (point != null) {
            rule.x = point[0];
            rule.y = point[1];
            rule.screenW = point[2];
            rule.screenH = point[3];
        }
        rule.cooldownMs = cd;
        rule.enabled = true;
        rule.draft = false;
        if (followSwitch != null) rule.followOn = followSwitch.isChecked();
        Rule fresh = RuleStore.get(this).find(rule.id);
        if (fresh != null) rule.followPts = new ArrayList<int[]>(fresh.followPts);

        RuleStore s = RuleStore.get(this);
        boolean wasWhitelisted = s.isWhitelisted(rule.pkg);
        s.save(rule);
        if (wasWhitelisted) s.setWhitelisted(rule.pkg, false);
        s.clearDraft(rule.id);
        s.setActiveDraft(null);
        saved = true;
        Toast.makeText(this, wasWhitelisted ? "规则已保存，并已将该应用移出白名单" : "规则已保存",
                Toast.LENGTH_SHORT).show();
        new AlertDialog.Builder(this)
                .setTitle("已保存")
                .setMessage("继续录制下一条规则？")
                .setPositiveButton("继续录制", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface d, int w) {
                        continueRecording();
                    }
                })
                .setNegativeButton("完成", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface d, int w) {
                        try {
                            stopService(new Intent(RuleEditActivity.this, OverlayService.class));
                        } catch (Exception ignored) {
                        }
                        finish();
                    }
                })
                .show();
    }
}
