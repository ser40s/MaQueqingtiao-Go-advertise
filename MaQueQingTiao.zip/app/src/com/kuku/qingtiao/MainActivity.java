package com.kuku.qingtiao;

import android.app.Activity;
import android.app.ActivityManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.database.ContentObserver;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Set;

public class MainActivity extends Activity {

    private LinearLayout content;
    private Button btnBottom;
    private final Handler ui = new Handler(Looper.getMainLooper());

    private final ContentObserver accObserver = new ContentObserver(new Handler(Looper.getMainLooper())) {
        public void onChange(boolean selfChange) {
            render();
        }
    };

    private final Runnable delayedRefresh = new Runnable() {
        public void run() {
            render();
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Ui.applyTheme(this);
        if (Ui.DARK) setTheme(R.style.AppThemeDark);
        setContentView(R.layout.activity_page);
        Ui.applyPage(this);
        content = (LinearLayout) findViewById(R.id.content);
        btnBottom = (Button) findViewById(R.id.btnBottom);
        btnBottom.setText("＋  为应用添加规则");
        btnBottom.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, AppPickerActivity.class));
            }
        });
        applyRecents();
        initWhitelistOnce();
        // 自身默认加入白名单，只加一次；之后用户可自行取消
        if (!RuleStore.get(this).isSelfWlDone()) {
            RuleStore.get(this).setWhitelisted(getPackageName(), true);
            RuleStore.get(this).markSelfWlDone();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        try {
            getContentResolver().registerContentObserver(
                    Settings.Secure.getUriFor(Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES),
                    false, accObserver);
        } catch (Exception ignored) {
        }
        render();
        updateA11yNotify();
        ui.postDelayed(new Runnable() {
            public void run() {
                applyRecents();
            }
        }, 500L);
        ui.removeCallbacks(delayedRefresh);
        ui.postDelayed(delayedRefresh, 600);
    }

    @Override
    protected void onPause() {
        ui.removeCallbacks(delayedRefresh);
        try {
            getContentResolver().unregisterContentObserver(accObserver);
        } catch (Exception ignored) {
        }
        super.onPause();
    }

    private boolean isAccEnabled() {
        try {
            String enabled = Settings.Secure.getString(getContentResolver(),
                    Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
            if (enabled == null || enabled.length() == 0) return SkipService.isRunning();
            String full = getPackageName() + "/" + SkipService.class.getName();
            String shortName = getPackageName() + "/.SkipService";
            return enabled.contains(full) || enabled.contains(shortName);
        } catch (Exception e) {
            return SkipService.isRunning();
        }
    }

    private void initWhitelistOnce() {
        final RuleStore store = RuleStore.get(this);
        store.migrateWhitelistDisplay();
        store.migrateLaunchersToWhitelist();
        if (store.isWhitelistInit()) return;
        new Thread(new Runnable() {
            public void run() {
                try {
                    store.ensureSystemWhitelist();
                    ui.post(delayedRefresh);
                } catch (Exception ignored) {
                }
            }
        }).start();
    }

    private boolean canOverlay() {
        if (Build.VERSION.SDK_INT >= 23) return Settings.canDrawOverlays(this);
        return true;
    }

    private boolean appsExpanded = false;

    private void updateA11yNotify() {
        try {
            NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            if (nm == null) return;
            if (!RuleStore.get(this).keepNotify() || isAccEnabled()) {
                nm.cancel(1002);
                return;
            }
            if (Build.VERSION.SDK_INT >= 26) {
                NotificationChannel ch = new NotificationChannel("qt_a11y", "无障碍状态",
                        NotificationManager.IMPORTANCE_LOW);
                ch.setShowBadge(false);
                nm.createNotificationChannel(ch);
            }
            Intent i = new Intent(this, MainActivity.class);
            i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
            int pf = PendingIntent.FLAG_UPDATE_CURRENT;
            if (Build.VERSION.SDK_INT >= 23) pf |= PendingIntent.FLAG_IMMUTABLE;
            PendingIntent pi = PendingIntent.getActivity(this, 1, i, pf);
            Notification.Builder b = Build.VERSION.SDK_INT >= 26
                    ? new Notification.Builder(this, "qt_a11y")
                    : new Notification.Builder(this);
            b.setSmallIcon(android.R.drawable.ic_menu_view)
                    .setContentTitle("麻雀轻跳")
                    .setContentText("无障碍已关闭，点击重新开启")
                    .setOngoing(true)
                    .setContentIntent(pi);
            nm.notify(1002, b.build());
        } catch (Exception ignored) {
        }
    }

    private void applyRecents() {
        // 无障碍未连接时保留后台卡片，方便用户切回开启
        boolean hide = RuleStore.get(this).hideRecents() && SkipService.isRunning();
        try {
            ActivityManager am = (ActivityManager) getSystemService(ACTIVITY_SERVICE);
            if (am == null) return;
            java.util.List<ActivityManager.AppTask> tasks = am.getAppTasks();
            if (tasks != null) {
                for (int i = 0; i < tasks.size(); i++) {
                    try {
                        tasks.get(i).setExcludeFromRecents(hide);
                    } catch (Exception ignored) {
                    }
                }
            }
        } catch (Exception ignored) {
        }
    }

    private void render() {
        content.removeAllViews();

        LinearLayout titleRow = Ui.row(this);
        titleRow.addView(Ui.text(this, "轻跳", 30f, Ui.TEXT, true));
        titleRow.addView(Ui.flex(this));
        TextView themeBtn = Ui.text(this, Ui.DARK ? "☀" : "☾", 20f, Ui.SUB, false);
        themeBtn.setPadding(Ui.dp(this, 12), Ui.dp(this, 4), Ui.dp(this, 4), Ui.dp(this, 4));
        themeBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                RuleStore.get(MainActivity.this).setDark(!Ui.DARK);
                recreate();
            }
        });
        titleRow.addView(themeBtn);
        content.addView(titleRow);
        TextView sub = Ui.text(this, "自动跳过开屏广告 · 规则只存在本机，不联网", 12.5f, Ui.SUB, false);
        sub.setPadding(0, Ui.dp(this, 5), 0, Ui.dp(this, 18));
        content.addView(sub);

        // 状态
        LinearLayout status = Ui.card(this);
        boolean acc = isAccEnabled();
        status.addView(statusRow("无障碍服务", acc ? "已开启 · 正在生效" : "未开启", acc,
                acc ? "设置" : "去开启", new View.OnClickListener() {
                    public void onClick(View v) {
                        try {
                            startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
                        } catch (Exception e) {
                        }
                    }
                }));
        status.addView(Ui.divider(this));
        boolean ov = canOverlay();
        status.addView(statusRow("悬浮窗权限", ov ? "已授权" : "未授权", ov,
                ov ? "设置" : "去授权", new View.OnClickListener() {
                    public void onClick(View v) {
                        try {
                            Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                    Uri.parse("package:" + getPackageName()));
                            startActivity(i);
                        } catch (Exception e) {
                        }
                    }
                }));
        content.addView(status);

        // 引擎开关
        LinearLayout engine = Ui.card(this);
        LinearLayout er = Ui.row(this);
        LinearLayout el = new LinearLayout(this);
        el.setOrientation(LinearLayout.VERTICAL);
        el.addView(Ui.text(this, "通用引擎", 15.5f, Ui.TEXT, true));
        TextView ed = Ui.text(this, "识别「跳过 / Skip」等按钮并自动点击", 11.5f, Ui.SUB, false);
        ed.setPadding(0, Ui.dp(this, 3), 0, 0);
        el.addView(ed);
        er.addView(el, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        Switch sw = new Switch(this);
        sw.setChecked(RuleStore.get(this).isEngineOn());
        sw.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton b, boolean checked) {
                RuleStore.get(MainActivity.this).setEngineOn(checked);
            }
        });
        er.addView(sw);
        engine.addView(er);
        content.addView(engine);

        // 统计
        LinearLayout stat = Ui.card(this);
        LinearLayout sr = Ui.row(this);
        sr.addView(statCell("今日跳过", String.valueOf(RuleStore.get(this).hitsToday())));
        sr.addView(statCell("累计跳过", String.valueOf(RuleStore.get(this).hitsTotal())));
        sr.addView(statCell("规则数", String.valueOf(RuleStore.get(this).all().size())));
        stat.addView(sr);
        TextView statTip = Ui.text(this, "长按可清空跳过记录", 10.5f, Ui.SUB, false);
        statTip.setGravity(Gravity.CENTER);
        statTip.setPadding(0, Ui.dp(this, 6), 0, 0);
        stat.addView(statTip);
        stat.setOnLongClickListener(new View.OnLongClickListener() {
            public boolean onLongClick(View v) {
                confirmResetHits();
                return true;
            }
        });
        content.addView(stat);

        // 悬浮窗工具
        LinearLayout tools = Ui.card(this);
        tools.addView(Ui.text(this, "录制工具", 15.5f, Ui.TEXT, true));
        TextView td = Ui.text(this, "切到目标应用：①检视控件 → ②准心定位 → 保存规则。\n"
                + "· 填「目标控件序号」：识别到前置控件存在后，点目标控件中心\n"
                + "· 勾「动态坐标」：按控件相对位置实时计算点击点，可选左上/右上/左下/右下角作锚点\n"
                + "· 都留空：按固定坐标点击\n"
                + "页面正在滑动或触摸时不会点击，点击位置超出屏幕也不点。\n"
                + "开启「小圆点」后，点面板左上角「轻跳」可收成小圆点（自动贴左右边），点小圆点展开并居中。", 11.5f, Ui.SUB, false);
        td.setPadding(0, Ui.dp(this, 3), 0, Ui.dp(this, 10));
        tools.addView(td);
        TextView btnTool = Ui.button(this, OverlayService.alive ? "悬浮球运行中 · 点击关闭" : "打开悬浮球", true);
        btnTool.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if (OverlayService.alive) {
                    stopService(new Intent(MainActivity.this, OverlayService.class));
                } else {
                    if (!canOverlay()) {
                        android.widget.Toast.makeText(MainActivity.this, "请先授权悬浮窗权限", android.widget.Toast.LENGTH_SHORT).show();
                        return;
                    }
                    RuleStore.get(MainActivity.this).setActiveDraft(null);
                    Intent i = new Intent(MainActivity.this, OverlayService.class);
                    if (Build.VERSION.SDK_INT >= 26) startForegroundService(i);
                    else startService(i);
                    android.widget.Toast.makeText(MainActivity.this, "悬浮球已开启，可切到目标应用", android.widget.Toast.LENGTH_SHORT).show();
                }
            }
        });
        tools.addView(btnTool);
        content.addView(tools);

        // 应用白名单
        LinearLayout wlCard = Ui.card(this);
        LinearLayout wlRow = Ui.row(this);
        LinearLayout wlLeft = new LinearLayout(this);
        wlLeft.setOrientation(LinearLayout.VERTICAL);
        wlLeft.addView(Ui.text(this, "应用白名单", 15.5f, Ui.TEXT, true));
        int wlCount = RuleStore.get(this).whitelist().size();
        TextView wlSub = Ui.text(this, wlCount + " 个应用不会被自动点击 · 系统应用默认在内", 11.5f, Ui.SUB, false);
        wlSub.setPadding(0, Ui.dp(this, 3), 0, 0);
        wlLeft.addView(wlSub);
        wlRow.addView(wlLeft, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        wlRow.addView(Ui.pill(this, "›", Ui.PRIMARY, Ui.PRIMARY_SOFT));
        wlCard.addView(wlRow);
        wlCard.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, WhitelistActivity.class));
            }
        });
        content.addView(wlCard);

        // 备份与恢复
        LinearLayout bkCard = Ui.card(this);
        bkCard.addView(Ui.text(this, "备份与恢复", 15.5f, Ui.TEXT, true));
        TextView bkSub = Ui.text(this, "导出规则、严格模式、关键词（不含白名单）", 11.5f, Ui.SUB, false);
        bkSub.setPadding(0, Ui.dp(this, 3), 0, Ui.dp(this, 10));
        bkCard.addView(bkSub);
        LinearLayout bkRow = Ui.row(this);
        TextView expBtn = Ui.buttonSmall(this, "导出到剪贴板");
        expBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                doExport();
            }
        });
        TextView impBtn = Ui.buttonSmall(this, "从剪贴板导入");
        impBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                doImport();
            }
        });
        bkRow.addView(expBtn);
        bkRow.addView(Ui.space(this, 10));
        bkRow.addView(impBtn);
        bkCard.addView(bkRow);
        content.addView(bkCard);

        // 跳过关键词
        LinearLayout kwCard = Ui.card(this);
        LinearLayout kwRow = Ui.row(this);
        LinearLayout kwLeft = new LinearLayout(this);
        kwLeft.setOrientation(LinearLayout.VERTICAL);
        kwLeft.addView(Ui.text(this, "跳过关键词", 15.5f, Ui.TEXT, true));
        int customCount = RuleStore.get(this).customKeywords().size();
        TextView kwSub = Ui.text(this, "内置「跳过 / Skip / 关闭广告」 · 自定义 " + customCount + " 个", 11.5f, Ui.SUB, false);
        kwSub.setPadding(0, Ui.dp(this, 3), 0, 0);
        kwLeft.addView(kwSub);
        kwRow.addView(kwLeft, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        kwRow.addView(Ui.pill(this, "›", Ui.PRIMARY, Ui.PRIMARY_SOFT));
        kwCard.addView(kwRow);
        kwCard.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                showKeywordDialog();
            }
        });
        content.addView(kwCard);

        // 通用引擎严格模式
        final RuleStore gsStore = RuleStore.get(this);
        LinearLayout gsCard = Ui.card(this);
        LinearLayout gsRow = Ui.row(this);
        LinearLayout gsLeft = new LinearLayout(this);
        gsLeft.setOrientation(LinearLayout.VERTICAL);
        gsLeft.addView(Ui.text(this, "通用引擎严格模式", 15.5f, Ui.TEXT, true));
        TextView gsSub = Ui.text(this, "首屏文本过多时不执行关键词点击 · 默认关闭", 11.5f, Ui.SUB, false);
        gsSub.setPadding(0, Ui.dp(this, 3), 0, 0);
        gsLeft.addView(gsSub);
        gsRow.addView(gsLeft, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        Switch gsSw = new Switch(this);
        gsSw.setChecked(gsStore.genericStrict());
        gsSw.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton b, boolean checked) {
                gsStore.setGenericStrict(checked);
            }
        });
        gsRow.addView(gsSw);
        gsCard.addView(gsRow);

        LinearLayout maxRow = Ui.row(this);
        maxRow.setPadding(0, Ui.dp(this, 10), 0, 0);
        maxRow.addView(Ui.text(this, "首屏文本数上限", 12.5f, Ui.TEXT, false),
                new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        final EditText maxIn = new EditText(this);
        maxIn.setText(String.valueOf(gsStore.genericStrictMax()));
        maxIn.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
        maxIn.setTextSize(13f);
        maxIn.setTextColor(Ui.TEXT);
        maxIn.setGravity(Gravity.CENTER);
        maxIn.setSingleLine(true);
        maxIn.setBackground(Ui.bg(Ui.INPUT_BG, this, 9f));
        maxIn.setPadding(Ui.dp(this, 8), Ui.dp(this, 5), Ui.dp(this, 8), Ui.dp(this, 5));
        maxIn.addTextChangedListener(new android.text.TextWatcher() {
            public void beforeTextChanged(CharSequence s, int a, int b, int c) {
            }

            public void onTextChanged(CharSequence s, int a, int b, int c) {
                try {
                    int v = Integer.parseInt(s.toString().trim());
                    if (v >= 5 && v <= 500) gsStore.setGenericStrictMax(v);
                } catch (Exception ignored) {
                }
            }

            public void afterTextChanged(android.text.Editable s) {
            }
        });
        LinearLayout.LayoutParams mlp = new LinearLayout.LayoutParams(Ui.dp(this, 78),
                ViewGroup.LayoutParams.WRAP_CONTENT);
        maxRow.addView(maxIn, mlp);
        gsCard.addView(maxRow);

        LinearLayout gdRow = Ui.row(this);
        gdRow.setPadding(0, Ui.dp(this, 8), 0, 0);
        gdRow.addView(Ui.text(this, "全局延迟（毫秒）", 12.5f, Ui.TEXT, false),
                new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        final EditText gdIn = new EditText(this);
        gdIn.setText(String.valueOf(gsStore.genDelayGlobal()));
        gdIn.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
        gdIn.setTextSize(13f);
        gdIn.setTextColor(Ui.TEXT);
        gdIn.setGravity(Gravity.CENTER);
        gdIn.setSingleLine(true);
        gdIn.setBackground(Ui.bg(Ui.INPUT_BG, this, 9f));
        gdIn.setPadding(Ui.dp(this, 8), Ui.dp(this, 5), Ui.dp(this, 8), Ui.dp(this, 5));
        gdIn.addTextChangedListener(new android.text.TextWatcher() {
            public void beforeTextChanged(CharSequence s, int a, int b, int c) {
            }

            public void onTextChanged(CharSequence s, int a, int b, int c) {
                try {
                    long v = Long.parseLong(s.toString().trim());
                    if (v >= 0 && v <= 30000) gsStore.setGenDelayGlobal(v);
                } catch (Exception ignored) {
                }
            }

            public void afterTextChanged(android.text.Editable s) {
            }
        });
        gdRow.addView(gdIn, new LinearLayout.LayoutParams(Ui.dp(this, 78),
                ViewGroup.LayoutParams.WRAP_CONTENT));
        gsCard.addView(gdRow);

        TextView gdTip = Ui.text(this, "单应用设置的延迟优先于全局", 10.5f, Ui.SUB, false);
        gdTip.setPadding(0, Ui.dp(this, 6), 0, 0);
        gsCard.addView(gdTip);
        content.addView(gsCard);

        // 通知与后台
        LinearLayout miscCard = Ui.card(this);
        miscCard.addView(Ui.text(this, "通知与后台", 15.5f, Ui.TEXT, true));

        LinearLayout nRow = Ui.row(this);
        nRow.setPadding(0, Ui.dp(this, 10), 0, 0);
        nRow.addView(Ui.text(this, "常驻通知", 13f, Ui.TEXT, false),
                new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        Switch nSw = new Switch(this);
        nSw.setChecked(gsStore.keepNotify());
        nSw.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton b, boolean c) {
                RuleStore.get(MainActivity.this).setKeepNotify(c);
                if (c) {
                    if (Build.VERSION.SDK_INT >= 33) {
                        try {
                            if (checkSelfPermission("android.permission.POST_NOTIFICATIONS")
                                    != PackageManager.PERMISSION_GRANTED) {
                                requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 3001);
                            }
                        } catch (Exception ignored) {
                        }
                    }
                    SkipService svc = SkipService.get();
                    if (svc == null) {
                        android.widget.Toast.makeText(MainActivity.this,
                                "无障碍服务未连接，通知需要无障碍开启后才能显示",
                                android.widget.Toast.LENGTH_LONG).show();
                    } else {
                        svc.updateKeepNotify();
                    }
                } else {
                    SkipService svc = SkipService.get();
                    if (svc != null) svc.updateKeepNotify();
                }
            }
        });
        nRow.addView(nSw);
        miscCard.addView(nRow);

        LinearLayout rRow = Ui.row(this);
        rRow.setPadding(0, Ui.dp(this, 8), 0, 0);
        rRow.addView(Ui.text(this, "去除后台卡片", 13f, Ui.TEXT, false),
                new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        Switch rSw = new Switch(this);
        rSw.setChecked(gsStore.hideRecents());
        rSw.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton b, boolean c) {
                RuleStore.get(MainActivity.this).setHideRecents(c);
                ui.postDelayed(new Runnable() {
                    public void run() {
                        applyRecents();
                    }
                }, 300L);
            }
        });
        rRow.addView(rSw);
        miscCard.addView(rRow);

        LinearLayout sRow = Ui.row(this);
        sRow.setPadding(0, Ui.dp(this, 8), 0, 0);
        LinearLayout sMid = new LinearLayout(this);
        sMid.setOrientation(LinearLayout.VERTICAL);
        sMid.addView(Ui.text(this, "小圆点", 13f, Ui.TEXT, false));
        TextView sSub = Ui.text(this, "开启后点「轻跳」可收成小圆点，点圆点展开", 10.5f, Ui.SUB, false);
        sSub.setPadding(0, Ui.dp(this, 2), 0, 0);
        sMid.addView(sSub);
        sRow.addView(sMid, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        Switch sSw = new Switch(this);
        sSw.setChecked(gsStore.edgeSnap());
        sSw.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton b, boolean c) {
                RuleStore.get(MainActivity.this).setEdgeSnap(c);
            }
        });
        sRow.addView(sSw);
        miscCard.addView(sRow);
        content.addView(miscCard);

        // 已配置应用
        TextView section = Ui.text(this, "已配置的应用", 15.5f, Ui.TEXT, true);
        section.setPadding(Ui.dp(this, 4), Ui.dp(this, 6), 0, Ui.dp(this, 10));
        content.addView(section);

        RuleStore.get(this).purgeInvalid();
        List<Rule> all = RuleStore.get(this).all();
        LinkedHashMap<String, Integer> map = new LinkedHashMap<String, Integer>();
        for (int i = 0; i < all.size(); i++) {
            Rule r = all.get(i);
            if (r.draft) continue;
            Integer c = map.get(r.pkg);
            map.put(r.pkg, Integer.valueOf(c == null ? 1 : c.intValue() + 1));
        }
        if (map.isEmpty()) {
            LinearLayout empty = Ui.card(this);
            empty.setGravity(Gravity.CENTER);
            TextView e1 = Ui.text(this, "还没有脚本规则", 14f, Ui.TEXT, true);
            e1.setGravity(Gravity.CENTER);
            empty.addView(e1);
            TextView e2 = Ui.text(this, "通用引擎已经在工作；遇到跳不掉的广告，再给该应用加规则", 11.5f, Ui.SUB, false);
            e2.setGravity(Gravity.CENTER);
            e2.setPadding(0, Ui.dp(this, 6), 0, Ui.dp(this, 2));
            empty.addView(e2);
            content.addView(empty);
        } else {
            LinearLayout list = Ui.card(this);
            list.setPadding(Ui.dp(this, 12), Ui.dp(this, 6), Ui.dp(this, 12), Ui.dp(this, 6));
            final List<String> pkgs = new ArrayList<String>(map.keySet());
            int limit = appsExpanded ? pkgs.size() : Math.min(10, pkgs.size());
            for (int i = 0; i < limit; i++) {
                final String pkg = pkgs.get(i);
                int n = map.get(pkg).intValue();
                list.addView(appRow(pkg, n));
                if (i < limit - 1) {
                    View d = new View(this);
                    d.setBackgroundColor(Ui.LINE);
                    LinearLayout.LayoutParams dlp = new LinearLayout.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT, Math.max(1, Ui.dp(this, 0.7f)));
                    d.setLayoutParams(dlp);
                    list.addView(d);
                }
            }
            if (pkgs.size() > 10) {
                TextView more = Ui.text(this,
                        appsExpanded ? "收起" : "展开全部 " + pkgs.size() + " 个应用",
                        12f, Ui.PRIMARY, false);
                more.setGravity(Gravity.CENTER);
                more.setPadding(0, Ui.dp(this, 12), 0, Ui.dp(this, 6));
                more.setOnClickListener(new View.OnClickListener() {
                    public void onClick(View v) {
                        appsExpanded = !appsExpanded;
                        render();
                    }
                });
                list.addView(more);
            }
            content.addView(list);
        }

        TextView tip = Ui.text(this, "提示：Android 系统会限制后台服务，建议在系统设置里允许本应用后台运行，跳广告更稳定。", 11f, Ui.SUB, false);
        tip.setPadding(Ui.dp(this, 4), Ui.dp(this, 8), Ui.dp(this, 4), Ui.dp(this, 8));
        content.addView(tip);
    }

    private void doExport() {
        try {
            String json = RuleStore.get(this).exportJson();
            ClipboardManager cm = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
            if (cm == null) return;
            cm.setPrimaryClip(ClipData.newPlainText("qingtiao-backup", json));
            int n = RuleStore.get(this).all().size();
            android.widget.Toast.makeText(this,
                    "已导出 " + n + " 条规则到剪贴板，粘贴到备忘录保存", android.widget.Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            android.widget.Toast.makeText(this, "导出失败", android.widget.Toast.LENGTH_SHORT).show();
        }
    }

    private void doImport() {
        try {
            ClipboardManager cm = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
            if (cm == null || cm.getPrimaryClip() == null || cm.getPrimaryClip().getItemCount() == 0) {
                android.widget.Toast.makeText(this, "剪贴板是空的", android.widget.Toast.LENGTH_SHORT).show();
                return;
            }
            CharSequence cs = cm.getPrimaryClip().getItemAt(0).coerceToText(this);
            String text = cs == null ? "" : cs.toString();
            int n = RuleStore.get(this).importJson(text);
            if (n < 0) {
                android.widget.Toast.makeText(this, "剪贴板内容不是有效的备份", android.widget.Toast.LENGTH_SHORT).show();
                return;
            }
            render();
            android.widget.Toast.makeText(this, "已导入 " + n + " 条规则", android.widget.Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            android.widget.Toast.makeText(this, "导入失败", android.widget.Toast.LENGTH_SHORT).show();
        }
    }

    private void showKeywordDialog() {
        final RuleStore store = RuleStore.get(this);
        LinearLayout wrap = new LinearLayout(this);
        wrap.setOrientation(LinearLayout.VERTICAL);
        wrap.setPadding(Ui.dp(this, 20), Ui.dp(this, 6), Ui.dp(this, 20), 0);

        TextView tip = Ui.text(this, "每行一个，追加到内置关键词；匹配时忽略大小写和空格。", 11.5f, Ui.SUB, false);
        wrap.addView(tip);

        final EditText et = new EditText(this);
        et.setText(store.customKeywordsRaw());
        et.setHint("例如：\n关闭\nskip now\n跳过广告");
        et.setTextSize(13f);
        et.setTextColor(Ui.TEXT);
        et.setHintTextColor(0xFFB4B9C6);
        et.setMinLines(5);
        et.setGravity(Gravity.TOP | Gravity.START);
        et.setBackground(Ui.bg(Ui.INPUT_BG, this, 10f));
        et.setPadding(Ui.dp(this, 10), Ui.dp(this, 8), Ui.dp(this, 10), Ui.dp(this, 8));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.topMargin = Ui.dp(this, 8);
        wrap.addView(et, lp);

        new AlertDialog.Builder(this)
                .setTitle("自定义跳过关键词")
                .setView(wrap)
                .setPositiveButton("保存", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface d, int w) {
                        store.setCustomKeywordsRaw(et.getText().toString());
                        render();
                        android.widget.Toast.makeText(MainActivity.this, "关键词已保存", android.widget.Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("取消", null)
                .show();
    }

    private LinearLayout statusRow(String name, String state, boolean ok, String actionText, View.OnClickListener l) {
        LinearLayout row = Ui.row(this);
        LinearLayout left = new LinearLayout(this);
        left.setOrientation(LinearLayout.VERTICAL);
        left.addView(Ui.text(this, name, 15f, Ui.TEXT, true));
        TextView s = Ui.text(this, state, 11.5f, ok ? Ui.OK : Ui.WARN, false);
        s.setPadding(0, Ui.dp(this, 3), 0, 0);
        left.addView(s);
        row.addView(left, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        if (actionText != null && l != null) {
            TextView btn = Ui.buttonSmall(this, actionText);
            btn.setOnClickListener(l);
            row.addView(btn);
        } else {
            TextView pill = Ui.pill(this, "OK", Ui.OK, Ui.OK_SOFT);
            row.addView(pill);
        }
        return row;
    }

    private void confirmResetHits() {
        new AlertDialog.Builder(this)
                .setTitle("清空跳过记录")
                .setMessage("今日跳过和累计跳过都会归零，已配置的规则不受影响。")
                .setPositiveButton("清空", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface d, int w) {
                        RuleStore.get(MainActivity.this).resetHits();
                        render();
                        Toast.makeText(MainActivity.this, "已清空", Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("取消", null)
                .show();
    }

    private LinearLayout statCell(String label, String value) {
        LinearLayout v = new LinearLayout(this);
        v.setOrientation(LinearLayout.VERTICAL);
        v.setGravity(Gravity.CENTER);
        v.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        TextView num = Ui.text(this, value, 22f, Ui.TEXT, true);
        num.setGravity(Gravity.CENTER);
        v.addView(num);
        TextView lb = Ui.text(this, label, 11f, Ui.SUB, false);
        lb.setGravity(Gravity.CENTER);
        lb.setPadding(0, Ui.dp(this, 2), 0, 0);
        v.addView(lb);
        return v;
    }

    private LinearLayout appRow(final String pkg, int count) {
        LinearLayout row = Ui.row(this);
        row.setPadding(0, Ui.dp(this, 10), 0, Ui.dp(this, 10));
        ImageView icon = new ImageView(this);
        Drawable d = null;
        try {
            d = getPackageManager().getApplicationIcon(pkg);
        } catch (Exception ignored) {
        }
        if (d == null) d = getPackageManager().getDefaultActivityIcon();
        icon.setImageDrawable(d);
        LinearLayout.LayoutParams ilp = new LinearLayout.LayoutParams(Ui.dp(this, 38), Ui.dp(this, 38));
        ilp.rightMargin = Ui.dp(this, 12);
        icon.setLayoutParams(ilp);
        row.addView(icon);

        LinearLayout mid = new LinearLayout(this);
        mid.setOrientation(LinearLayout.VERTICAL);
        String label = pkg;
        try {
            label = getPackageManager().getApplicationLabel(
                    getPackageManager().getApplicationInfo(pkg, 0)).toString();
        } catch (Exception ignored) {
        }
        final String appLabel = label;
        mid.addView(Ui.text(this, label, 14.5f, Ui.TEXT, true));
        TextView sub = Ui.text(this, pkg + " · " + count + " 条规则", 10.5f, Ui.SUB, false);
        sub.setPadding(0, Ui.dp(this, 2), 0, 0);
        mid.addView(sub);
        row.addView(mid, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        row.addView(Ui.pill(this, "›", Ui.PRIMARY, Ui.PRIMARY_SOFT));
        row.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent i = new Intent(MainActivity.this, RuleListActivity.class);
                i.putExtra("pkg", pkg);
                startActivity(i);
            }
        });
        row.setOnLongClickListener(new View.OnLongClickListener() {
            public boolean onLongClick(View v) {
                showAppMenu(pkg, appLabel);
                return true;
            }
        });
        row.setBackgroundColor(0x00000000);
        return row;
    }

    private void showAppMenu(final String pkg, final String label) {
        final RuleStore store = RuleStore.get(this);
        final int n = store.countFor(pkg);
        boolean anyOn = false;
        List<Rule> rs = store.forPackage(pkg);
        for (int i = 0; i < rs.size(); i++) {
            if (rs.get(i).enabled) {
                anyOn = true;
                break;
            }
        }
        final boolean turnOff = anyOn;
        String[] items = {turnOff ? "关闭所有规则（" + n + " 条）" : "开启所有规则（" + n + " 条）",
                "删除所有规则（" + n + " 条）"};
        new AlertDialog.Builder(this)
                .setTitle(label)
                .setItems(items, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface d, int w) {
                        if (w == 0) {
                            int c = store.setEnabledAll(pkg, !turnOff);
                            Toast.makeText(MainActivity.this,
                                    (turnOff ? "已关闭 " : "已开启 ") + c + " 条规则",
                                    Toast.LENGTH_SHORT).show();
                            render();
                        } else {
                            confirmRemoveAll(pkg, label, n);
                        }
                    }
                })
                .show();
    }

    private void confirmRemoveAll(final String pkg, final String label, int n) {
        new AlertDialog.Builder(this)
                .setTitle("删除所有规则")
                .setMessage("删除「" + label + "」的 " + n + " 条规则？删除后该应用会从列表移除。")
                .setPositiveButton("删除", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface d, int w) {
                        int c = RuleStore.get(MainActivity.this).removeAll(pkg);
                        render();
                        Toast.makeText(MainActivity.this, "已删除 " + c + " 条规则",
                                Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("取消", null)
                .show();
    }
}
