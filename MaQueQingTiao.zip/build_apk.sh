#!/bin/bash
set -e
ROOT=$(cd "$(dirname "$0")" && pwd)
export JAVA_HOME=$ROOT/.toolchain/jdk17
export PATH=$JAVA_HOME/bin:$PATH
BT=$ROOT/.toolchain/android-sdk/build-tools/34.0.0
PLATFORM=$ROOT/.toolchain/android-sdk/platforms/android-34/android.jar
OUT=${1:-outputs/QingTiao-1.0.56.apk}
cd app

rm -rf build gen
mkdir -p build/classes build/dex gen

echo "[1/6] compile resources"
$BT/aapt2 compile --dir res -o build/res.zip

echo "[2/6] link resources"
$BT/aapt2 link -o build/base.apk -I $PLATFORM --manifest AndroidManifest.xml \
  --java gen --min-sdk-version 24 --target-sdk-version 34 \
  --version-code 57 --version-name 1.0.56 build/res.zip

echo "[3/6] javac"
find src gen -name "*.java" > build/sources.txt
javac -source 8 -target 8 -bootclasspath $PLATFORM -encoding UTF-8 -nowarn \
  -d build/classes @build/sources.txt

echo "[4/6] d8"
find build/classes -name "*.class" > build/classes.txt
$BT/d8 --release --min-api 24 --lib $PLATFORM --output build/dex @build/classes.txt

echo "[5/6] package"
python3 - <<'PY'
import zipfile, shutil
shutil.copy('build/base.apk', 'build/unsigned.apk')
with zipfile.ZipFile('build/unsigned.apk', 'a', zipfile.ZIP_DEFLATED) as z:
    z.write('build/dex/classes.dex', 'classes.dex')
print('  classes.dex merged')
PY
$BT/zipalign -f -p 4 build/unsigned.apk build/aligned.apk

echo "[6/6] sign"
KS=qingtiao-release.jks
if [ ! -f "$KS" ]; then   # 签名固定放在 app/ 下，不随 build 目录清空而丢失
  keytool -genkeypair -keystore "$KS" -alias qingtiao -keyalg RSA -keysize 2048 \
    -validity 10950 -storepass qingtiao2024 -keypass qingtiao2024 \
    -dname "CN=QingTiao, OU=App, O=Kuku, L=Beijing, ST=Beijing, C=CN" >/dev/null 2>&1
fi
mkdir -p ../outputs
$BT/apksigner sign --ks "$KS" --ks-pass pass:qingtiao2024 --key-pass pass:qingtiao2024 \
  --v1-signing-enabled true --v2-signing-enabled true --v3-signing-enabled true \
  --out "../$OUT" build/aligned.apk
$BT/apksigner verify --print-certs "../$OUT" | head -8
ls -lh "../$OUT"
