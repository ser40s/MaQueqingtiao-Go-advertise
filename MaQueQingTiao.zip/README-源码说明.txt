麻雀轻跳 1.0.56 源码
==================

构建环境：
- JDK 17
- Android SDK build-tools 34.0.0 / platform android-34
- 不用 Gradle，脚本直接调 aapt2 → javac → d8 → zipalign → apksigner

构建：
  bash build_apk.sh
产物默认写到 outputs/QingTiao-<版本>.apk

签名：
需自备 keystore，修改脚本里的 KEYS / storepass / keypass / alias。
本包不含签名密钥。

目录：
  app/src/com/kuku/qingtiao/   全部 Java 源码
  app/res/                     资源与图标
  app/AndroidManifest.xml      清单
  build_apk.sh                 构建脚本

关键文件：
  SkipService.java      无障碍服务、规则执行、通用引擎、点击前稳定性检查
  OverlayService.java   悬浮窗录制（检视/准心/续点/拾取控件/小圆点）
  RuleEditActivity.java 规则编辑
  RuleStore.java        规则存储、白名单、设置
  Rule.java             规则数据模型（坐标/点控件/动态坐标/续点）
